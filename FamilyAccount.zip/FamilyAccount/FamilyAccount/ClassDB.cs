﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Drawing;
using System.Text.RegularExpressions;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    class ClassDB
    {
        PersianDate pd;
        public static int Column=0, Row=0;
        Rijndael RJ = Rijndael.Create();
        MD5CryptoServiceProvider MD = new MD5CryptoServiceProvider();
        
        SqlCommand cmd = new SqlCommand();
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.AccountConnectionString);

        #region TotalOperation
        public void SetFarsiLanguage()
        {
            InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(CultureInfo.CreateSpecificCulture("fa-IR"));
        }

        public void SetEnglishLanguage()
        {
            InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(CultureInfo.CreateSpecificCulture("en-EN"));
        }

        internal class NativeMethods
        {
            public const int HWND_BROADCAST = 0xffff;
            public static readonly int WM_SHOWME = RegisterWindowMessage("WM_SHOWME");
            [DllImport("user32")]
            public static extern bool PostMessage(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);
            [DllImport("user32")]
            public static extern int RegisterWindowMessage(string message);
        }

        public string EncryptText(string TextToEncrypt)
        {
            RJ.Key = MD.ComputeHash(ASCIIEncoding.Default.GetBytes(Properties.Settings.Default.SecureKey));
            RJ.Mode = CipherMode.ECB;
            byte[] ToEncrypt = Encoding.Default.GetBytes(TextToEncrypt);
            return Convert.ToBase64String(RJ.CreateEncryptor().TransformFinalBlock(ToEncrypt, 0, ToEncrypt.Length));
        }

        public string DecryptText(string EncryptedText)
        {
            try
            {
                RJ.Key = MD.ComputeHash(ASCIIEncoding.Default.GetBytes(Properties.Settings.Default.SecureKey));
                RJ.Mode = CipherMode.ECB;
                byte[] ToDecrypt = Convert.FromBase64String(EncryptedText);
                return ASCIIEncoding.Default.GetString(RJ.CreateDecryptor().TransformFinalBlock(ToDecrypt, 0, ToDecrypt.Length));
            }
            catch
            {
                return null;
            }
        }

        public byte[] ImageToByte(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
            return ms.ToArray();
        }

        public Image ByteToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
        #endregion

        #region Backup AND Restore
        public bool Backup(string strFileName)
        {
            try
            {
                //cnn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=" + Application.StartupPath + "\\Account.mdf;Integrated Security=True;User Instance=True";
                cmd.CommandText = @"BACKUP DATABASE [" + Application.StartupPath + "\\Account.mdf] TO  DISK = N'" + strFileName + "' WITH NOFORMAT, NOINIT,  NAME = N'Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10";
                if (cnn.State != ConnectionState.Open)
                    cnn.Open();
                cmd.Connection = cnn;
                cmd.ExecuteNonQuery();
                cnn.Close();
                MessageBox.Show("فایل پشتیبان با موفقیت ساخته شد", "تهیه نسخه پشتیبان", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return true;
            }
            catch (Exception)
            {
                MessageBox.Show("اجازه دسترسی به پوشه مورد نظر داده نشده است", "اخطار", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return false;
            }
        }

        public bool Restore(string strFileName)
        {
            try
            {
                string Query1 = "ALTER DATABASE [" + Application.StartupPath + "\\Account.mdf] SET OFFLINE WITH ROLLBACK IMMEDIATE";
                string Query2 = "ALTER DATABASE [" + Application.StartupPath + "\\Account.mdf] SET MULTI_USER";
                string Query3 = @"RESTORE DATABASE [" + Application.StartupPath + "\\Account.mdf] FROM  DISK = N'" + strFileName + "' WITH RECOVERY, REPLACE";
                if (cnn.State != ConnectionState.Open)
                    cnn.Open();
                cmd.Connection = cnn;

                cmd.CommandText = Query1;
                cmd.ExecuteNonQuery();

                cmd.CommandText = Query2;
                cmd.ExecuteNonQuery();

                cmd.CommandText = Query3;
                cmd.ExecuteNonQuery();
                cnn.Close();
                MessageBox.Show("عملیات بازیابی نسخه پشتیبان با موفقیت انجام شد", "بازیابی نسخه پشتیبان", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return true;
            }
            catch (Exception)
            {
                MessageBox.Show("انجام دستور مورد نظر در حال حاضر امکان پذیر نمی باشد", "اخطار", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return false;
            }
        }
        #endregion

        #region Validate
        public void ClearControl(Control controlName)
        {
            foreach (Klik.Windows.Forms.v1.Common.KControlBase item in controlName.Controls)
            {
                if (item is Klik.Windows.Forms.v1.EntryLib.ELEntryBox)
                    ((Klik.Windows.Forms.v1.EntryLib.ELEntryBox)(item)).Text = "";
                if (item is Klik.Windows.Forms.v1.EntryLib.ELComboBox)
                    ((Klik.Windows.Forms.v1.EntryLib.ELComboBox)(item)).Text = "";
            }
        }

        public string ExtractNumbers(string Expression)
        {
            string result = null;
            char Letter;
            for (int i = 0; i < Expression.Length; i++)
            {
                Letter = Convert.ToChar(Expression.Substring(i, 1));
                if (Char.IsNumber(Letter))
                {
                    result += Letter.ToString();
                }
            }
            return result;
        }

        public bool ValidateControl(Control controlName)
        {
            bool flag = false;
            string mes = "لطفا";
            foreach (Klik.Windows.Forms.v1.Common.KControlBase item in controlName.Controls)
            {
                if (item.Tag.ToString() == "1")
                {
                    if (item is Klik.Windows.Forms.v1.EntryLib.ELEntryBox && (((Klik.Windows.Forms.v1.EntryLib.ELEntryBox)(item)).Text == "" || ((Klik.Windows.Forms.v1.EntryLib.ELEntryBox)(item)).Value.ToString() == "0" || ((Klik.Windows.Forms.v1.EntryLib.ELEntryBox)(item)).Text == "0"))
                    {
                        mes += "  " + ((Klik.Windows.Forms.v1.EntryLib.ELEntryBox)(item)).CaptionText + " ,";
                        flag = true;
                    }
                    if (item is Klik.Windows.Forms.v1.EntryLib.ELComboBox && ((Klik.Windows.Forms.v1.EntryLib.ELComboBox)(item)).Text == "")
                    {
                        mes += "  " + ((Klik.Windows.Forms.v1.EntryLib.ELComboBox)(item)).CaptionText + " ,";
                        flag = true;
                    }
                }
            }
            mes = mes.Substring(0, mes.Length - 1);
            mes += " را وارد نمائید";
            if(flag)
                if (MessageBox.Show(mes, "عدم درج اطلاعات کافی", MessageBoxButtons.OK, MessageBoxIcon.Warning,MessageBoxDefaultButton.Button1,MessageBoxOptions.RtlReading) == DialogResult.OK)
                    return true;
            return false;
        }

        public void DateValidation(Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtBox)
        {
            if (txtBox.Text != "")
            {
                try
                {
                    FarsiLibrary.Utils.PersianCalendar pd = new FarsiLibrary.Utils.PersianCalendar();
                    if (Regex.IsMatch(txtBox.Text, @"(13|14)\d\d[/]([1-9]|0[1-9]|1[012])[/]([1-9]|0[1-9]|[12][0-9]|3[01])"))
                    {
                        string[] datePart = new string[3];
                        datePart = txtBox.Text.Split(new char[] { '/' });
                        int year = Convert.ToInt32(datePart[0]);
                        int month = Convert.ToInt32(datePart[1]);
                        int day = Convert.ToInt32(datePart[2]);
                        DateTime GregorianDate = pd.ToDateTime(year, month, day, 0, 0, 0, 0);
                        string tempString = string.Format("{0:D2}",pd.GetYear(GregorianDate)) + "/" + string.Format("{0:D2}",pd.GetMonth(GregorianDate)) + "/" + string.Format("{0:D2}",pd.GetDayOfMonth(GregorianDate));
                        txtBox.Text = tempString;
                    }
                    else
                        throw new Exception();
                }
                catch (Exception)
                {
                    txtBox.Text = "تاریخ نامعتبر";
                    txtBox.Focus();
                }
            }
        }

        public string IncDate(string OldDate,int number,int space)
        {
            pd = new PersianDate(OldDate);
            FarsiLibrary.Utils.PersianCalendar pds = new FarsiLibrary.Utils.PersianCalendar();
            string tempString = pds.AddMonths(pd.ToDateTime(), number * space).ToPersianDate().ToString("d");
            string[] datePart = new string[3];
            datePart = tempString.Split(new char[] { '/' });
            int year = Convert.ToInt32(datePart[0]);
            int month = Convert.ToInt32(datePart[1]);
            int day = Convert.ToInt32(datePart[2]);
            DateTime GregorianDate = pds.ToDateTime(year, month, day, 0, 0, 0, 0);
            return string.Format("{0:D2}",pds.GetYear(GregorianDate)) + "/" + string.Format("{0:D2}",pds.GetMonth(GregorianDate)) + "/" + string.Format("{0:D2}",pds.GetDayOfMonth(GregorianDate));
        }

        public int DateDiff(string ExmDate, string CurDate)
        {
            string[] datePart = new string[3];
            datePart = ExmDate.Split(new char[] { '/' });
            int year = Convert.ToInt32(datePart[0]);
            int month = Convert.ToInt32(datePart[1]);
            int day = Convert.ToInt32(datePart[2]);
            DateTime date1 = new DateTime(year, month, day, 0, 0, 0, 0);

            datePart = CurDate.Split(new char[] { '/' });
            year = Convert.ToInt32(datePart[0]);
            month = Convert.ToInt32(datePart[1]);
            day = Convert.ToInt32(datePart[2]);
            DateTime date2 = new DateTime(year, month, day, 0, 0, 0, 0);

            TimeSpan tp = date2.Subtract(date1);
            return tp.Days;
        }
        #endregion

        public bool dbConnected()
        {
            try
            {
                cnn.Open();
                cnn.Close();
                return true;
            }
            catch (Exception err)
            {
                MessageBox.Show("برنامه قادر به برقراری ارتباط با بانک اطلاعاتی نمی باشد", "خطا در اتصال", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return false;
            }
        }

        public bool insert(SqlCommand cmd, CommandType InsertType, string InsertCommand)
        {
            try
            {
                cmd.CommandText = InsertCommand;
                cmd.CommandType = InsertType;
                cmd.Connection = cnn;
                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();
                cmd.Parameters.Clear();
                MessageBox.Show("اطلاعات موردنظر با موفقیت ثبت گردید", "ثبت اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return true;
            }
            catch (Exception err)
            {
                MessageBox.Show("عملیات درج اطلاعات با مشکل مواجه شده است ، لطفا مجددا سعی نمائید", "خطای درج اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                cnn.Close();
                return false;
            }
        }

        public bool update(SqlCommand cmd, CommandType InsertType, string UpdateCommand)
        {
            try
            {
                cmd.CommandText = UpdateCommand;
                cmd.CommandType = InsertType;
                cmd.Connection = cnn;
                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();
                cmd.Parameters.Clear();
                MessageBox.Show("اطلاعات موردنظر با موفقیت تصحیح گردید", "ویرایش اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return true;
            }
            catch (Exception err)
            {
                MessageBox.Show("عملیات ویرایش اطلاعات با مشکل مواجه شده است ، لطفا مجددا سعی نمائید", "خطای ویرایش اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                cnn.Close();
                return true;
            }
        }

        public bool delete(SqlCommand cmd, CommandType InsertType, string DeleteCommand)
        {
            try
            {
                cmd.CommandText = DeleteCommand;
                cmd.CommandType = InsertType;
                cmd.Connection = cnn;
                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();
                cmd.Parameters.Clear();
                MessageBox.Show("اطلاعات موردنظر با موفقیت حذف گردید", "حذف اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return true;
            }
            catch (Exception err)
            {
                MessageBox.Show("عملیات حذف اطلاعات با مشکل مواجه شده است ، لطفا مجددا سعی نمائید", "خطای حذف اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                cnn.Close();
                return false;
            }
        }

        public DataSet select(string SelectCommand)
        {
            SqlDataAdapter da = new SqlDataAdapter(SelectCommand, cnn);
            DataSet ds = new DataSet();
            cnn.Open();
            da.Fill(ds);
            cnn.Close();
            return ds;
        }

        public void SearchGrid(Klik.Windows.Forms.v1.EntryLib.ELDataGridView datagrid, string strValue)
        {
            int maxSearches = datagrid.Rows.Count * datagrid.Columns.Count + 1;
            int idx = 1;
            bool isFound = false;
            if (Convert.ToBoolean(strValue.Length))
            {
                while ((!isFound) & (idx < maxSearches))
                {
                    
                    if (datagrid.Columns[Column].Visible)
                    {
                        if (datagrid[Column, Row].Value.ToString().ToUpper().Contains(strValue))
                        {
                            datagrid.ClearSelection();
                            datagrid.FirstDisplayedScrollingRowIndex = Row;
                            datagrid[Column, Row].Selected = true;
                            isFound = true;
                        }
                    }
                    Column++;
                    if (Column == datagrid.Columns.Count)
                    {
                        Column = 0;
                        Row++;
                        if (Row == datagrid.Rows.Count)
                            Row = 0;
                    }
                    idx++;
                }
                if (!isFound)
                    MessageBox.Show("عبارت موردنظر یافت نشد");
            }
        }
    }
}
