﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;

namespace FamilyAccount
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 
        public static FrmSplash splashForm = null;
        static Mutex mutex = new Mutex(true, "{39d5e2c9-8791-4f77-a1f4-d0e81f1b1681}");
        [STAThread]
        static void Main()
        {
            if (mutex.WaitOne(TimeSpan.Zero, true))
            {
                Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fa-IR");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);

                splashForm = new FrmSplash();
                splashForm.Show();
                FrmMain mainForm = new FrmMain();
                splashForm.Refresh();

                Application.Run(mainForm);
                mutex.ReleaseMutex();
            }
            else
            {
                FamilyAccount.ClassDB.NativeMethods.PostMessage((IntPtr)FamilyAccount.ClassDB.NativeMethods.HWND_BROADCAST,
                                                                FamilyAccount.ClassDB.NativeMethods.WM_SHOWME,
                                                                IntPtr.Zero, IntPtr.Zero);
            }
        }

        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            //e.Exception.Message
            MessageBox.Show("در روند اجرای برنامه خطایی رخ داده است ، لطفا برنامه را مجددا اجرا نمائید", "خطای اجرای برنامه", MessageBoxButtons.OK, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            Application.ExitThread();
        }
    }
}
