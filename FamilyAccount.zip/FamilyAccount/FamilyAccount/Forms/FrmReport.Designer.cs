﻿namespace FamilyAccount
{
    partial class FrmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmReport aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmReport));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle3 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle4 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle5 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle6 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem5 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem6 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem7 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem8 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem9 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem10 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem11 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem12 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem13 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem14 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem15 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle7 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle8 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle9 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle10 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnPrint = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClear = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnCreateRep = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elGroupBox2 = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.rdo12 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo11 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo10 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo9 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo8 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo7 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo6 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo5 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo4 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo3 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo2 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdo1 = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.grpDate = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.btncurday = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btncuryear = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.btncurmonth = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton3 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.btncurweek = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.tabBase = new Klik.Windows.Forms.v1.EntryLib.ELTab();
            this.Tab0 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.rdoTrans = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdoAcccard = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdoCheq = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.lblstoremax = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblstoremin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtstoremax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstoremin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnInsmemid = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnInsBankid = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnInsbaid = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtbankid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbaid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccidA = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab1 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.rdopayment = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.lblloanqmax = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblloanqmin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtloanqmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtloanqmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cboloanbacktype = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.btnIncAcc = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtloanP = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab2 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.rdochdate = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdochExpo = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.btnInscsid = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnchAcc = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.lblquanmax = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblquanmin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtcheqquanmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtinmode = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcheqquanmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cbocheqstate = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.cbocheqtype = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtcsid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab3 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.txtnamePH = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cborelation = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.Tab4 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.lblSalmax = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblSalmin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtsalmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnInsSal = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtbsid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsalnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsalmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab5 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.lblCostmax = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblCostmin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.btnInsMem = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtcostmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcostmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnInsCost = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtmemidC = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbcid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcostnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.repDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCreateRep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox2)).BeginInit();
            this.elGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdo12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpDate)).BeginInit();
            this.grpDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncurday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncuryear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btncurmonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncurweek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabBase)).BeginInit();
            this.tabBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tab0)).BeginInit();
            this.Tab0.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTrans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoAcccard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoCheq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblstoremax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblstoremin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsBankid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsbaid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab1)).BeginInit();
            this.Tab1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdopayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblloanqmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblloanqmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanqmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanqmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloanbacktype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIncAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab2)).BeginInit();
            this.Tab2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdochdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochExpo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInscsid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnchAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblquanmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblquanmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqtype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab3)).BeginInit();
            this.Tab3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamePH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cborelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab4)).BeginInit();
            this.Tab4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lblSalmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSalmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsSal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbsid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab5)).BeginInit();
            this.Tab5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lblCostmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCostmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsMem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbcid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.repDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnPrint);
            this.elContainer1.Controls.Add(this.btnClear);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnCreateRep);
            this.elContainer1.Controls.Add(this.elGroupBox2);
            this.elContainer1.Controls.Add(this.grpDate);
            this.elContainer1.Controls.Add(this.tabBase);
            this.elContainer1.Location = new System.Drawing.Point(6, 4);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(800, 283);
            this.elContainer1.TabIndex = 0;
            // 
            // btnPrint
            // 
            this.btnPrint.BackgroundImageStyle.Alpha = 100;
            this.btnPrint.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnPrint.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 20);
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnPrint.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnPrint.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPrint.Location = new System.Drawing.Point(74, 73);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnPrint.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnPrint.Size = new System.Drawing.Size(96, 29);
            this.btnPrint.TabIndex = 13;
            this.btnPrint.Tag = "True";
            this.btnPrint.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.TextStyle.Text = "چاپ گزارش";
            this.btnPrint.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImageStyle.Alpha = 100;
            this.btnClear.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClear.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClear.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClear.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClear.Location = new System.Drawing.Point(74, 13);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnClear.Size = new System.Drawing.Size(96, 28);
            this.btnClear.TabIndex = 11;
            this.btnClear.Tag = "0";
            this.btnClear.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.TextStyle.Text = "پاک کردن";
            this.btnClear.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(6, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnClose.Size = new System.Drawing.Size(62, 89);
            this.btnClose.TabIndex = 4;
            this.btnClose.Tag = "True";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCreateRep
            // 
            this.btnCreateRep.BackgroundImageStyle.Alpha = 100;
            this.btnCreateRep.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnCreateRep.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreateRep.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 20);
            this.btnCreateRep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreateRep.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnCreateRep.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnCreateRep.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCreateRep.Location = new System.Drawing.Point(74, 43);
            this.btnCreateRep.Name = "btnCreateRep";
            this.btnCreateRep.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnCreateRep.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnCreateRep.Size = new System.Drawing.Size(96, 29);
            this.btnCreateRep.TabIndex = 2;
            this.btnCreateRep.Tag = "True";
            this.btnCreateRep.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateRep.TextStyle.Text = "تهیه گزارش";
            this.btnCreateRep.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCreateRep.Click += new System.EventHandler(this.btnCreateRep_Click);
            // 
            // elGroupBox2
            // 
            this.elGroupBox2.BackgroundStyle.GradientAngle = 45F;
            this.elGroupBox2.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox2.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.elGroupBox2.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox2.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox2.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox2.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elGroupBox2.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.elGroupBox2.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elGroupBox2.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elGroupBox2.CaptionStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.elGroupBox2.CaptionStyle.PositionIndent = new System.Drawing.Point(10, 0);
            this.elGroupBox2.CaptionStyle.Size = new System.Drawing.Size(80, 18);
            this.elGroupBox2.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.elGroupBox2.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elGroupBox2.CaptionStyle.TextStyle.Text = "سال جاری";
            this.elGroupBox2.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elGroupBox2.Controls.Add(this.rdo12);
            this.elGroupBox2.Controls.Add(this.rdo11);
            this.elGroupBox2.Controls.Add(this.rdo10);
            this.elGroupBox2.Controls.Add(this.rdo9);
            this.elGroupBox2.Controls.Add(this.rdo8);
            this.elGroupBox2.Controls.Add(this.rdo7);
            this.elGroupBox2.Controls.Add(this.rdo6);
            this.elGroupBox2.Controls.Add(this.rdo5);
            this.elGroupBox2.Controls.Add(this.rdo4);
            this.elGroupBox2.Controls.Add(this.rdo3);
            this.elGroupBox2.Controls.Add(this.rdo2);
            this.elGroupBox2.Controls.Add(this.rdo1);
            this.elGroupBox2.Location = new System.Drawing.Point(175, 5);
            this.elGroupBox2.Name = "elGroupBox2";
            this.elGroupBox2.Padding = new System.Windows.Forms.Padding(4, 21, 4, 3);
            this.elGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elGroupBox2.Size = new System.Drawing.Size(364, 97);
            this.elGroupBox2.TabIndex = 1;
            // 
            // rdo12
            // 
            this.rdo12.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo12.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo12.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo12.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo12.Location = new System.Drawing.Point(8, 72);
            this.rdo12.Name = "rdo12";
            this.rdo12.Size = new System.Drawing.Size(80, 19);
            this.rdo12.TabIndex = 11;
            this.rdo12.TabStop = false;
            this.rdo12.Tag = "12";
            this.rdo12.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo12.TextStyle.Text = "اسفند";
            this.rdo12.Value = false;
            this.rdo12.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo11
            // 
            this.rdo11.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo11.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo11.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo11.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo11.Location = new System.Drawing.Point(8, 46);
            this.rdo11.Name = "rdo11";
            this.rdo11.Size = new System.Drawing.Size(80, 19);
            this.rdo11.TabIndex = 10;
            this.rdo11.TabStop = false;
            this.rdo11.Tag = "11";
            this.rdo11.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo11.TextStyle.Text = "بهمن";
            this.rdo11.Value = false;
            this.rdo11.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo10
            // 
            this.rdo10.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo10.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo10.Cursor = System.Windows.Forms.Cursors.Default;
            this.rdo10.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo10.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo10.Location = new System.Drawing.Point(8, 20);
            this.rdo10.Name = "rdo10";
            this.rdo10.Size = new System.Drawing.Size(80, 19);
            this.rdo10.TabIndex = 9;
            this.rdo10.Tag = "10";
            this.rdo10.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo10.TextStyle.Text = "دی";
            this.rdo10.Value = false;
            this.rdo10.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo9
            // 
            this.rdo9.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo9.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo9.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo9.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo9.Location = new System.Drawing.Point(97, 72);
            this.rdo9.Name = "rdo9";
            this.rdo9.Size = new System.Drawing.Size(80, 19);
            this.rdo9.TabIndex = 8;
            this.rdo9.TabStop = false;
            this.rdo9.Tag = "9";
            this.rdo9.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo9.TextStyle.Text = "آذر";
            this.rdo9.Value = false;
            this.rdo9.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo8
            // 
            this.rdo8.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo8.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo8.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo8.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo8.Location = new System.Drawing.Point(97, 46);
            this.rdo8.Name = "rdo8";
            this.rdo8.Size = new System.Drawing.Size(80, 19);
            this.rdo8.TabIndex = 7;
            this.rdo8.TabStop = false;
            this.rdo8.Tag = "8";
            this.rdo8.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo8.TextStyle.Text = "آبان";
            this.rdo8.Value = false;
            this.rdo8.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo7
            // 
            this.rdo7.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo7.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo7.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo7.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo7.Location = new System.Drawing.Point(97, 20);
            this.rdo7.Name = "rdo7";
            this.rdo7.Size = new System.Drawing.Size(80, 19);
            this.rdo7.TabIndex = 6;
            this.rdo7.TabStop = false;
            this.rdo7.Tag = "7";
            this.rdo7.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo7.TextStyle.Text = "مهر";
            this.rdo7.Value = false;
            this.rdo7.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo6
            // 
            this.rdo6.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo6.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo6.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo6.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo6.Location = new System.Drawing.Point(186, 72);
            this.rdo6.Name = "rdo6";
            this.rdo6.Size = new System.Drawing.Size(80, 19);
            this.rdo6.TabIndex = 5;
            this.rdo6.TabStop = false;
            this.rdo6.Tag = "6";
            this.rdo6.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo6.TextStyle.Text = "شهریور";
            this.rdo6.Value = false;
            this.rdo6.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo5
            // 
            this.rdo5.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo5.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo5.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo5.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo5.Location = new System.Drawing.Point(186, 46);
            this.rdo5.Name = "rdo5";
            this.rdo5.Size = new System.Drawing.Size(80, 19);
            this.rdo5.TabIndex = 4;
            this.rdo5.TabStop = false;
            this.rdo5.Tag = "5";
            this.rdo5.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo5.TextStyle.Text = "مرداد";
            this.rdo5.Value = false;
            this.rdo5.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo4
            // 
            this.rdo4.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo4.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo4.Cursor = System.Windows.Forms.Cursors.Default;
            this.rdo4.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo4.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo4.Location = new System.Drawing.Point(186, 20);
            this.rdo4.Name = "rdo4";
            this.rdo4.Size = new System.Drawing.Size(80, 19);
            this.rdo4.TabIndex = 3;
            this.rdo4.TabStop = false;
            this.rdo4.Tag = "4";
            this.rdo4.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo4.TextStyle.Text = "تیر";
            this.rdo4.Value = false;
            this.rdo4.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo3
            // 
            this.rdo3.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo3.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo3.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo3.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo3.Location = new System.Drawing.Point(275, 72);
            this.rdo3.Name = "rdo3";
            this.rdo3.Size = new System.Drawing.Size(80, 19);
            this.rdo3.TabIndex = 2;
            this.rdo3.TabStop = false;
            this.rdo3.Tag = "3";
            this.rdo3.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo3.TextStyle.Text = "خرداد";
            this.rdo3.Value = false;
            this.rdo3.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo2
            // 
            this.rdo2.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo2.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo2.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo2.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo2.Location = new System.Drawing.Point(275, 46);
            this.rdo2.Name = "rdo2";
            this.rdo2.Size = new System.Drawing.Size(80, 19);
            this.rdo2.TabIndex = 1;
            this.rdo2.TabStop = false;
            this.rdo2.Tag = "2";
            this.rdo2.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo2.TextStyle.Text = "اردیبهشت";
            this.rdo2.Value = false;
            this.rdo2.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // rdo1
            // 
            this.rdo1.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo1.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdo1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdo1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdo1.Location = new System.Drawing.Point(275, 20);
            this.rdo1.Name = "rdo1";
            this.rdo1.Size = new System.Drawing.Size(80, 19);
            this.rdo1.TabIndex = 0;
            this.rdo1.TabStop = false;
            this.rdo1.Tag = "1";
            this.rdo1.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo1.TextStyle.Text = "فروردین";
            this.rdo1.Value = false;
            this.rdo1.CheckedChanged += new System.EventHandler(this.rdo1_CheckedChanged);
            // 
            // grpDate
            // 
            this.grpDate.BackgroundStyle.GradientAngle = 45F;
            this.grpDate.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpDate.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpDate.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.grpDate.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.grpDate.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.grpDate.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.grpDate.CaptionStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.grpDate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpDate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpDate.CaptionStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.grpDate.CaptionStyle.PositionIndent = new System.Drawing.Point(10, 0);
            this.grpDate.CaptionStyle.Size = new System.Drawing.Size(110, 18);
            this.grpDate.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpDate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDate.CaptionStyle.TextStyle.Text = "محدوده تاریخی";
            this.grpDate.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grpDate.Controls.Add(this.btncurday);
            this.grpDate.Controls.Add(this.btncuryear);
            this.grpDate.Controls.Add(this.txtstartdate);
            this.grpDate.Controls.Add(this.btncurmonth);
            this.grpDate.Controls.Add(this.txtenddate);
            this.grpDate.Controls.Add(this.btncurweek);
            this.grpDate.Location = new System.Drawing.Point(545, 5);
            this.grpDate.Name = "grpDate";
            this.grpDate.Padding = new System.Windows.Forms.Padding(4, 21, 4, 3);
            this.grpDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.grpDate.Size = new System.Drawing.Size(249, 97);
            this.grpDate.TabIndex = 0;
            this.grpDate.Tag = "0";
            // 
            // btncurday
            // 
            this.btncurday.BackgroundImageStyle.Alpha = 100;
            this.btncurday.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurday.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btncurday.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncurday.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btncurday.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btncurday.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurday.Location = new System.Drawing.Point(7, 20);
            this.btncurday.Name = "btncurday";
            this.btncurday.Size = new System.Drawing.Size(65, 17);
            this.btncurday.TabIndex = 2;
            this.btncurday.Tag = "0";
            this.btncurday.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncurday.TextStyle.Text = "امروز";
            this.btncurday.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurday.Click += new System.EventHandler(this.btncurday_Click);
            // 
            // btncuryear
            // 
            this.btncuryear.BackgroundImageStyle.Alpha = 100;
            this.btncuryear.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncuryear.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btncuryear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncuryear.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btncuryear.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btncuryear.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncuryear.Location = new System.Drawing.Point(7, 74);
            this.btncuryear.Name = "btncuryear";
            this.btncuryear.Size = new System.Drawing.Size(65, 17);
            this.btncuryear.TabIndex = 5;
            this.btncuryear.Tag = "0";
            this.btncuryear.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncuryear.TextStyle.Text = "سال جاری";
            this.btncuryear.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncuryear.Click += new System.EventHandler(this.btncuryear_Click);
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.CaptionSize = 70;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(74, 20);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(170, 27);
            this.txtstartdate.TabIndex = 0;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextDate";
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // btncurmonth
            // 
            this.btncurmonth.BackgroundImageStyle.Alpha = 100;
            this.btncurmonth.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurmonth.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btncurmonth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncurmonth.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btncurmonth.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btncurmonth.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurmonth.Location = new System.Drawing.Point(7, 57);
            this.btncurmonth.Name = "btncurmonth";
            this.btncurmonth.Size = new System.Drawing.Size(65, 17);
            this.btncurmonth.TabIndex = 4;
            this.btncurmonth.Tag = "0";
            this.btncurmonth.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncurmonth.TextStyle.Text = "ماه جاری";
            this.btncurmonth.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurmonth.Click += new System.EventHandler(this.btncurmonth_Click);
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton3);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.CaptionSize = 70;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(74, 64);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(170, 27);
            this.txtenddate.TabIndex = 1;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            // 
            // elEntryBoxButton3
            // 
            this.elEntryBoxButton3.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton3.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton3.DropDownContextMenuStrip = this.contextDate;
            // 
            // btncurweek
            // 
            this.btncurweek.BackgroundImageStyle.Alpha = 100;
            this.btncurweek.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurweek.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btncurweek.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncurweek.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btncurweek.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btncurweek.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurweek.Location = new System.Drawing.Point(7, 39);
            this.btncurweek.Name = "btncurweek";
            this.btncurweek.Size = new System.Drawing.Size(65, 17);
            this.btncurweek.TabIndex = 3;
            this.btncurweek.Tag = "0";
            this.btncurweek.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncurweek.TextStyle.Text = "هفته جاری";
            this.btncurweek.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncurweek.Click += new System.EventHandler(this.btncurweek_Click);
            // 
            // tabBase
            // 
            this.tabBase.Location = new System.Drawing.Point(6, 108);
            this.tabBase.Name = "tabBase";
            this.tabBase.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.tabBase.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabBase.Size = new System.Drawing.Size(788, 171);
            this.tabBase.TabCaptionStyle.BorderStyle = Klik.Windows.Forms.v1.EntryLib.TabCaptionBorderStyles.Chrome;
            this.tabBase.TabCaptionStyle.CaptionAlignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.BackgroundPaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.BackgroundSolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabBase.TabIndex = 2;
            this.tabBase.TabPages.Add(this.Tab0);
            this.tabBase.TabPages.Add(this.Tab1);
            this.tabBase.TabPages.Add(this.Tab2);
            this.tabBase.TabPages.Add(this.Tab3);
            this.tabBase.TabPages.Add(this.Tab4);
            this.tabBase.TabPages.Add(this.Tab5);
            this.tabBase.SelectedTabPageChanged += new System.EventHandler(this.tabBase_SelectedTabPageChanged);
            // 
            // Tab0
            // 
            this.Tab0.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab0.CaptionTextStyle.Text = "حسابهای بانکی";
            this.Tab0.Controls.Add(this.rdoTrans);
            this.Tab0.Controls.Add(this.rdoAcccard);
            this.Tab0.Controls.Add(this.rdoCheq);
            this.Tab0.Controls.Add(this.lblstoremax);
            this.Tab0.Controls.Add(this.lblstoremin);
            this.Tab0.Controls.Add(this.txtstoremax);
            this.Tab0.Controls.Add(this.txtstoremin);
            this.Tab0.Controls.Add(this.btnInsmemid);
            this.Tab0.Controls.Add(this.btnInsBankid);
            this.Tab0.Controls.Add(this.btnInsbaid);
            this.Tab0.Controls.Add(this.txtbankid);
            this.Tab0.Controls.Add(this.txtbaid);
            this.Tab0.Controls.Add(this.txtaccidA);
            this.Tab0.Controls.Add(this.txtaccmemid);
            this.Tab0.Location = new System.Drawing.Point(1, 1);
            this.Tab0.Name = "Tab0";
            this.Tab0.Size = new System.Drawing.Size(786, 148);
            // 
            // rdoTrans
            // 
            this.rdoTrans.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoTrans.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoTrans.Location = new System.Drawing.Point(5, 31);
            this.rdoTrans.Name = "rdoTrans";
            this.rdoTrans.Size = new System.Drawing.Size(122, 25);
            this.rdoTrans.TabIndex = 7;
            this.rdoTrans.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoTrans.TextStyle.Text = "تراکنشهای بانکی";
            this.rdoTrans.Value = false;
            this.rdoTrans.CheckedChanged += new System.EventHandler(this.rdoTrans_CheckedChanged);
            // 
            // rdoAcccard
            // 
            this.rdoAcccard.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoAcccard.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoAcccard.Location = new System.Drawing.Point(135, 31);
            this.rdoAcccard.Name = "rdoAcccard";
            this.rdoAcccard.Size = new System.Drawing.Size(122, 25);
            this.rdoAcccard.TabIndex = 6;
            this.rdoAcccard.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoAcccard.TextStyle.Text = "کارت های اعتباری";
            this.rdoAcccard.Value = false;
            this.rdoAcccard.CheckedChanged += new System.EventHandler(this.rdoAcccard_CheckedChanged);
            // 
            // rdoCheq
            // 
            this.rdoCheq.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoCheq.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoCheq.Location = new System.Drawing.Point(263, 31);
            this.rdoCheq.Name = "rdoCheq";
            this.rdoCheq.Size = new System.Drawing.Size(122, 25);
            this.rdoCheq.TabIndex = 5;
            this.rdoCheq.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoCheq.TextStyle.Text = "دسته چکها";
            this.rdoCheq.Value = false;
            this.rdoCheq.CheckedChanged += new System.EventHandler(this.rdoCheq_CheckedChanged);
            // 
            // lblstoremax
            // 
            this.lblstoremax.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblstoremax.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblstoremax.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblstoremax.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblstoremax.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblstoremax.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.Transparent;
            this.lblstoremax.FlashStyle = paintStyle1;
            this.lblstoremax.Location = new System.Drawing.Point(11, 115);
            this.lblstoremax.Name = "lblstoremax";
            this.lblstoremax.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblstoremax.Size = new System.Drawing.Size(521, 25);
            this.lblstoremax.TabIndex = 30;
            this.lblstoremax.TabStop = false;
            this.lblstoremax.Tag = "0";
            this.lblstoremax.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblstoremax.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstoremax.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblstoremax.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblstoremax.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblstoremin
            // 
            this.lblstoremin.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblstoremin.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblstoremin.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblstoremin.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblstoremin.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblstoremin.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.Transparent;
            this.lblstoremin.FlashStyle = paintStyle2;
            this.lblstoremin.Location = new System.Drawing.Point(11, 87);
            this.lblstoremin.Name = "lblstoremin";
            this.lblstoremin.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblstoremin.Size = new System.Drawing.Size(521, 25);
            this.lblstoremin.TabIndex = 29;
            this.lblstoremin.TabStop = false;
            this.lblstoremin.Tag = "0";
            this.lblstoremin.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblstoremin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstoremin.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblstoremin.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblstoremin.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtstoremax
            // 
            this.txtstoremax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstoremax.CaptionStyle.CaptionSize = 105;
            this.txtstoremax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstoremax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstoremax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremax.CaptionStyle.TextStyle.Text = "موجودی حداکثر";
            this.txtstoremax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstoremax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstoremax.Location = new System.Drawing.Point(538, 115);
            this.txtstoremax.Name = "txtstoremax";
            this.txtstoremax.Size = new System.Drawing.Size(244, 27);
            this.txtstoremax.TabIndex = 11;
            this.txtstoremax.Tag = "1";
            this.txtstoremax.ValidationStyle.AcceptsTab = true;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtstoremax.ValidationStyle.PasswordChar = '\0';
            this.txtstoremax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtstoremax.Value = 0;
            // 
            // txtstoremin
            // 
            this.txtstoremin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstoremin.CaptionStyle.CaptionSize = 105;
            this.txtstoremin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstoremin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstoremin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremin.CaptionStyle.TextStyle.Text = "موجودی حداقل";
            this.txtstoremin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstoremin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstoremin.Location = new System.Drawing.Point(538, 87);
            this.txtstoremin.Name = "txtstoremin";
            this.txtstoremin.Size = new System.Drawing.Size(244, 27);
            this.txtstoremin.TabIndex = 10;
            this.txtstoremin.Tag = "1";
            this.txtstoremin.ValidationStyle.AcceptsTab = true;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtstoremin.ValidationStyle.PasswordChar = '\0';
            this.txtstoremin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtstoremin.Value = 0;
            // 
            // btnInsmemid
            // 
            this.btnInsmemid.BackgroundImageStyle.Alpha = 100;
            this.btnInsmemid.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnInsmemid.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsmemid.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsmemid.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsmemid.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsmemid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsmemid.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsmemid.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsmemid.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsmemid.Location = new System.Drawing.Point(469, 3);
            this.btnInsmemid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsmemid.Name = "btnInsmemid";
            this.btnInsmemid.Size = new System.Drawing.Size(28, 27);
            this.btnInsmemid.TabIndex = 1;
            this.btnInsmemid.Tag = "0";
            this.btnInsmemid.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsmemid.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsmemid.Click += new System.EventHandler(this.btnInsMem_Click);
            // 
            // btnInsBankid
            // 
            this.btnInsBankid.BackgroundImageStyle.Alpha = 100;
            this.btnInsBankid.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnInsBankid.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsBankid.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsBankid.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsBankid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsBankid.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsBankid.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsBankid.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.Location = new System.Drawing.Point(419, 31);
            this.btnInsBankid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsBankid.Name = "btnInsBankid";
            this.btnInsBankid.Size = new System.Drawing.Size(28, 27);
            this.btnInsBankid.TabIndex = 4;
            this.btnInsBankid.Tag = "0";
            this.btnInsBankid.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsBankid.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.Click += new System.EventHandler(this.btnInsBankid_Click);
            // 
            // btnInsbaid
            // 
            this.btnInsbaid.BackgroundImageStyle.Alpha = 100;
            this.btnInsbaid.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnInsbaid.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsbaid.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsbaid.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsbaid.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsbaid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsbaid.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsbaid.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsbaid.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsbaid.Location = new System.Drawing.Point(538, 59);
            this.btnInsbaid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsbaid.Name = "btnInsbaid";
            this.btnInsbaid.Size = new System.Drawing.Size(28, 27);
            this.btnInsbaid.TabIndex = 9;
            this.btnInsbaid.Tag = "0";
            this.btnInsbaid.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsbaid.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsbaid.Click += new System.EventHandler(this.btnInsbaid_Click);
            // 
            // txtbankid
            // 
            this.txtbankid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbankid.CaptionStyle.CaptionSize = 100;
            this.txtbankid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbankid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbankid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbankid.CaptionStyle.TextStyle.Text = "مشخصات بانک";
            this.txtbankid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbankid.Location = new System.Drawing.Point(448, 31);
            this.txtbankid.Name = "txtbankid";
            this.txtbankid.Size = new System.Drawing.Size(334, 27);
            this.txtbankid.TabIndex = 3;
            this.txtbankid.Tag = "1";
            this.txtbankid.ValidationStyle.AcceptsTab = true;
            this.txtbankid.ValidationStyle.PasswordChar = '\0';
            this.txtbankid.ValidationStyle.ReadOnly = true;
            this.txtbankid.Value = "";
            this.txtbankid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // txtbaid
            // 
            this.txtbaid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbaid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbaid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbaid.CaptionStyle.CaptionSize = 100;
            this.txtbaid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbaid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbaid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbaid.CaptionStyle.TextStyle.Text = "نوع حساب";
            this.txtbaid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbaid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbaid.Location = new System.Drawing.Point(567, 59);
            this.txtbaid.Name = "txtbaid";
            this.txtbaid.Size = new System.Drawing.Size(215, 27);
            this.txtbaid.TabIndex = 8;
            this.txtbaid.Tag = "1";
            this.txtbaid.ValidationStyle.AcceptsTab = true;
            this.txtbaid.ValidationStyle.PasswordChar = '\0';
            this.txtbaid.ValidationStyle.ReadOnly = true;
            this.txtbaid.Value = "";
            this.txtbaid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // txtaccidA
            // 
            this.txtaccidA.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccidA.CaptionStyle.CaptionSize = 125;
            this.txtaccidA.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccidA.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccidA.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidA.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccidA.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidA.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccidA.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccidA.Location = new System.Drawing.Point(133, 3);
            this.txtaccidA.Name = "txtaccidA";
            this.txtaccidA.Size = new System.Drawing.Size(252, 27);
            this.txtaccidA.TabIndex = 2;
            this.txtaccidA.Tag = "1";
            this.txtaccidA.ValidationStyle.AcceptsTab = true;
            this.txtaccidA.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccidA.ValidationStyle.PasswordChar = '\0';
            this.txtaccidA.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtaccidA.Value = 0;
            // 
            // txtaccmemid
            // 
            this.txtaccmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccmemid.CaptionStyle.CaptionSize = 100;
            this.txtaccmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtaccmemid.CaptionStyle.TextStyle.Text = "نام صاحب حساب";
            this.txtaccmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccmemid.Location = new System.Drawing.Point(498, 3);
            this.txtaccmemid.Name = "txtaccmemid";
            this.txtaccmemid.Size = new System.Drawing.Size(284, 27);
            this.txtaccmemid.TabIndex = 0;
            this.txtaccmemid.Tag = "1";
            this.txtaccmemid.ValidationStyle.AcceptsTab = true;
            this.txtaccmemid.ValidationStyle.PasswordChar = '\0';
            this.txtaccmemid.ValidationStyle.ReadOnly = true;
            this.txtaccmemid.Value = "";
            this.txtaccmemid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // Tab1
            // 
            this.Tab1.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab1.CaptionTextStyle.Text = "تسهیلات بانکی";
            this.Tab1.Controls.Add(this.rdopayment);
            this.Tab1.Controls.Add(this.lblloanqmax);
            this.Tab1.Controls.Add(this.lblloanqmin);
            this.Tab1.Controls.Add(this.txtloanqmax);
            this.Tab1.Controls.Add(this.txtloanqmin);
            this.Tab1.Controls.Add(this.cboloanbacktype);
            this.Tab1.Controls.Add(this.btnIncAcc);
            this.Tab1.Controls.Add(this.txtloanP);
            this.Tab1.Location = new System.Drawing.Point(1, 1);
            this.Tab1.Name = "Tab1";
            this.Tab1.Size = new System.Drawing.Size(786, 148);
            // 
            // rdopayment
            // 
            this.rdopayment.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdopayment.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdopayment.Location = new System.Drawing.Point(260, 3);
            this.rdopayment.Name = "rdopayment";
            this.rdopayment.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdopayment.Size = new System.Drawing.Size(111, 27);
            this.rdopayment.TabIndex = 7;
            this.rdopayment.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdopayment.TextStyle.Text = "اقساط تسهیلات";
            this.rdopayment.Value = false;
            this.rdopayment.CheckedChanged += new System.EventHandler(this.rdopayment_CheckedChanged);
            // 
            // lblloanqmax
            // 
            this.lblloanqmax.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle3.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle3.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle3.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle3.SolidColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.FlashStyle = paintStyle3;
            this.lblloanqmax.Location = new System.Drawing.Point(5, 87);
            this.lblloanqmax.Name = "lblloanqmax";
            this.lblloanqmax.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblloanqmax.Size = new System.Drawing.Size(492, 27);
            this.lblloanqmax.TabIndex = 29;
            this.lblloanqmax.TabStop = false;
            this.lblloanqmax.Tag = "0";
            this.lblloanqmax.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloanqmax.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblloanqmax.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblloanqmax.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblloanqmin
            // 
            this.lblloanqmin.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle4.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle4.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle4.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle4.SolidColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.FlashStyle = paintStyle4;
            this.lblloanqmin.Location = new System.Drawing.Point(5, 59);
            this.lblloanqmin.Name = "lblloanqmin";
            this.lblloanqmin.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblloanqmin.Size = new System.Drawing.Size(492, 27);
            this.lblloanqmin.TabIndex = 28;
            this.lblloanqmin.TabStop = false;
            this.lblloanqmin.Tag = "0";
            this.lblloanqmin.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloanqmin.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblloanqmin.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblloanqmin.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtloanqmax
            // 
            this.txtloanqmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanqmax.CaptionStyle.CaptionSize = 130;
            this.txtloanqmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanqmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanqmax.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanqmax.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanqmax.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanqmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanqmax.CaptionStyle.TextStyle.Text = "حداکثر مبلغ تسهیلات";
            this.txtloanqmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanqmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanqmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanqmax.Location = new System.Drawing.Point(508, 87);
            this.txtloanqmax.Name = "txtloanqmax";
            this.txtloanqmax.Size = new System.Drawing.Size(274, 27);
            this.txtloanqmax.TabIndex = 6;
            this.txtloanqmax.Tag = "1";
            this.txtloanqmax.ValidationStyle.AcceptsTab = true;
            this.txtloanqmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanqmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtloanqmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanqmax.ValidationStyle.PasswordChar = '\0';
            this.txtloanqmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanqmax.Value = 0;
            this.txtloanqmax.TextChanged += new System.EventHandler(this.txtloanqmax_TextChanged);
            this.txtloanqmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtloanqmin
            // 
            this.txtloanqmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanqmin.CaptionStyle.CaptionSize = 130;
            this.txtloanqmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanqmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanqmin.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanqmin.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanqmin.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanqmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanqmin.CaptionStyle.TextStyle.Text = "حداقل مبلغ تسهیلات";
            this.txtloanqmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanqmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanqmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanqmin.Location = new System.Drawing.Point(508, 59);
            this.txtloanqmin.Name = "txtloanqmin";
            this.txtloanqmin.Size = new System.Drawing.Size(274, 27);
            this.txtloanqmin.TabIndex = 5;
            this.txtloanqmin.Tag = "1";
            this.txtloanqmin.ValidationStyle.AcceptsTab = true;
            this.txtloanqmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanqmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtloanqmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanqmin.ValidationStyle.PasswordChar = '\0';
            this.txtloanqmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanqmin.Value = 0;
            this.txtloanqmin.TextChanged += new System.EventHandler(this.txtloanqmin_TextChanged);
            this.txtloanqmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // cboloanbacktype
            // 
            // 
            // 
            // 
            this.cboloanbacktype.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cboloanbacktype.CaptionStyle.CaptionSize = 130;
            this.cboloanbacktype.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloanbacktype.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cboloanbacktype.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloanbacktype.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboloanbacktype.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloanbacktype.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloanbacktype.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloanbacktype.CaptionStyle.TextStyle.Text = "نوع بازپرداخت";
            this.cboloanbacktype.CheckedDisplaySeparator = ',';
            this.cboloanbacktype.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloanbacktype.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cboloanbacktype.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloanbacktype.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cboloanbacktype.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cboloanbacktype.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cboloanbacktype.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloanbacktype.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cboloanbacktype.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = ((byte)(0));
            elListBoxItem1.Value = "راس مدت";
            elListBoxItem2.Key = ((byte)(1));
            elListBoxItem2.Value = "اقساط";
            this.cboloanbacktype.Items.Add(elListBoxItem1);
            this.cboloanbacktype.Items.Add(elListBoxItem2);
            this.cboloanbacktype.Location = new System.Drawing.Point(547, 3);
            this.cboloanbacktype.Name = "cboloanbacktype";
            this.cboloanbacktype.Size = new System.Drawing.Size(235, 27);
            this.cboloanbacktype.TabIndex = 0;
            this.cboloanbacktype.Tag = "1";
            this.cboloanbacktype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cborelation_KeyPress);
            // 
            // btnIncAcc
            // 
            this.btnIncAcc.BackgroundImageStyle.Alpha = 100;
            this.btnIncAcc.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnIncAcc.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIncAcc.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIncAcc.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIncAcc.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIncAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIncAcc.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIncAcc.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIncAcc.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIncAcc.Location = new System.Drawing.Point(5, 31);
            this.btnIncAcc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIncAcc.Name = "btnIncAcc";
            this.btnIncAcc.Size = new System.Drawing.Size(28, 27);
            this.btnIncAcc.TabIndex = 4;
            this.btnIncAcc.Tag = "0";
            this.btnIncAcc.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIncAcc.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIncAcc.Click += new System.EventHandler(this.btnIncAcc_Click);
            // 
            // txtloanP
            // 
            this.txtloanP.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtloanP.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtloanP.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanP.CaptionStyle.CaptionSize = 125;
            this.txtloanP.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanP.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanP.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanP.CaptionStyle.TextStyle.Text = "مشخصات تسهیلات";
            this.txtloanP.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanP.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanP.Location = new System.Drawing.Point(34, 31);
            this.txtloanP.Name = "txtloanP";
            this.txtloanP.Size = new System.Drawing.Size(748, 27);
            this.txtloanP.TabIndex = 3;
            this.txtloanP.Tag = "1";
            this.txtloanP.ValidationStyle.AcceptsTab = true;
            this.txtloanP.ValidationStyle.PasswordChar = '\0';
            this.txtloanP.ValidationStyle.ReadOnly = true;
            this.txtloanP.Value = "";
            this.txtloanP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // Tab2
            // 
            this.Tab2.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab2.CaptionTextStyle.Text = "چک های بانکی";
            this.Tab2.Controls.Add(this.rdochdate);
            this.Tab2.Controls.Add(this.rdochExpo);
            this.Tab2.Controls.Add(this.btnInscsid);
            this.Tab2.Controls.Add(this.btnchAcc);
            this.Tab2.Controls.Add(this.lblquanmax);
            this.Tab2.Controls.Add(this.lblquanmin);
            this.Tab2.Controls.Add(this.txtcheqquanmax);
            this.Tab2.Controls.Add(this.txtinmode);
            this.Tab2.Controls.Add(this.txtcheqquanmin);
            this.Tab2.Controls.Add(this.cbocheqstate);
            this.Tab2.Controls.Add(this.cbocheqtype);
            this.Tab2.Controls.Add(this.txtcsid);
            this.Tab2.Controls.Add(this.txtaccid);
            this.Tab2.Location = new System.Drawing.Point(1, 1);
            this.Tab2.Name = "Tab2";
            this.Tab2.Size = new System.Drawing.Size(786, 148);
            // 
            // rdochdate
            // 
            this.rdochdate.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdochdate.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdochdate.Location = new System.Drawing.Point(124, 3);
            this.rdochdate.Name = "rdochdate";
            this.rdochdate.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdochdate.Size = new System.Drawing.Size(111, 25);
            this.rdochdate.TabIndex = 21;
            this.rdochdate.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdochdate.TextStyle.Text = "تاریخ سررسید";
            this.rdochdate.Value = false;
            // 
            // rdochExpo
            // 
            this.rdochExpo.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdochExpo.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdochExpo.Location = new System.Drawing.Point(260, 3);
            this.rdochExpo.Name = "rdochExpo";
            this.rdochExpo.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdochExpo.Size = new System.Drawing.Size(111, 25);
            this.rdochExpo.TabIndex = 20;
            this.rdochExpo.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdochExpo.TextStyle.Text = "تاریخ صدور";
            this.rdochExpo.Value = false;
            // 
            // btnInscsid
            // 
            this.btnInscsid.BackgroundImageStyle.Alpha = 100;
            this.btnInscsid.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnInscsid.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInscsid.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInscsid.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInscsid.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInscsid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInscsid.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInscsid.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInscsid.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInscsid.Location = new System.Drawing.Point(5, 31);
            this.btnInscsid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInscsid.Name = "btnInscsid";
            this.btnInscsid.Size = new System.Drawing.Size(28, 27);
            this.btnInscsid.TabIndex = 19;
            this.btnInscsid.Tag = "0";
            this.btnInscsid.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInscsid.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInscsid.Click += new System.EventHandler(this.btnInscsid_Click);
            // 
            // btnchAcc
            // 
            this.btnchAcc.BackgroundImageStyle.Alpha = 100;
            this.btnchAcc.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            this.btnchAcc.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnchAcc.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnchAcc.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnchAcc.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnchAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnchAcc.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnchAcc.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnchAcc.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnchAcc.Location = new System.Drawing.Point(384, 31);
            this.btnchAcc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnchAcc.Name = "btnchAcc";
            this.btnchAcc.Size = new System.Drawing.Size(28, 27);
            this.btnchAcc.TabIndex = 18;
            this.btnchAcc.Tag = "0";
            this.btnchAcc.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchAcc.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnchAcc.Click += new System.EventHandler(this.btnchAcc_Click);
            // 
            // lblquanmax
            // 
            this.lblquanmax.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblquanmax.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblquanmax.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblquanmax.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblquanmax.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblquanmax.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle5.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle5.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle5.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle5.SolidColor = System.Drawing.Color.Transparent;
            this.lblquanmax.FlashStyle = paintStyle5;
            this.lblquanmax.Location = new System.Drawing.Point(11, 115);
            this.lblquanmax.Name = "lblquanmax";
            this.lblquanmax.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblquanmax.Size = new System.Drawing.Size(521, 25);
            this.lblquanmax.TabIndex = 17;
            this.lblquanmax.TabStop = false;
            this.lblquanmax.Tag = "0";
            this.lblquanmax.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblquanmax.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquanmax.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblquanmax.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblquanmax.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblquanmin
            // 
            this.lblquanmin.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblquanmin.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblquanmin.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblquanmin.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblquanmin.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblquanmin.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle6.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle6.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle6.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle6.SolidColor = System.Drawing.Color.Transparent;
            this.lblquanmin.FlashStyle = paintStyle6;
            this.lblquanmin.Location = new System.Drawing.Point(11, 87);
            this.lblquanmin.Name = "lblquanmin";
            this.lblquanmin.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblquanmin.Size = new System.Drawing.Size(521, 25);
            this.lblquanmin.TabIndex = 16;
            this.lblquanmin.TabStop = false;
            this.lblquanmin.Tag = "0";
            this.lblquanmin.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblquanmin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquanmin.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblquanmin.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblquanmin.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtcheqquanmax
            // 
            this.txtcheqquanmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqquanmax.CaptionStyle.CaptionSize = 100;
            this.txtcheqquanmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqquanmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqquanmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmax.CaptionStyle.TextStyle.Text = "مبلغ چک حداکثر";
            this.txtcheqquanmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqquanmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqquanmax.Location = new System.Drawing.Point(538, 115);
            this.txtcheqquanmax.Name = "txtcheqquanmax";
            this.txtcheqquanmax.Size = new System.Drawing.Size(244, 27);
            this.txtcheqquanmax.TabIndex = 6;
            this.txtcheqquanmax.Tag = "1";
            this.txtcheqquanmax.ValidationStyle.AcceptsTab = true;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqquanmax.ValidationStyle.PasswordChar = '\0';
            this.txtcheqquanmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqquanmax.Value = 0;
            this.txtcheqquanmax.TextChanged += new System.EventHandler(this.txtcheqquanmax_TextChanged);
            this.txtcheqquanmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtinmode
            // 
            this.txtinmode.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtinmode.CaptionStyle.CaptionSize = 100;
            this.txtinmode.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtinmode.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtinmode.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmode.CaptionStyle.TextStyle.Text = "در وجه";
            this.txtinmode.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmode.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtinmode.Location = new System.Drawing.Point(508, 59);
            this.txtinmode.Name = "txtinmode";
            this.txtinmode.Size = new System.Drawing.Size(274, 27);
            this.txtinmode.TabIndex = 3;
            this.txtinmode.Tag = "1";
            this.txtinmode.ValidationStyle.AcceptsTab = true;
            this.txtinmode.ValidationStyle.PasswordChar = '\0';
            this.txtinmode.Value = "";
            this.txtinmode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtcheqquanmin
            // 
            this.txtcheqquanmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqquanmin.CaptionStyle.CaptionSize = 100;
            this.txtcheqquanmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqquanmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqquanmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmin.CaptionStyle.TextStyle.Text = "مبلغ چک حداقل";
            this.txtcheqquanmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqquanmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqquanmin.Location = new System.Drawing.Point(538, 87);
            this.txtcheqquanmin.Name = "txtcheqquanmin";
            this.txtcheqquanmin.Size = new System.Drawing.Size(244, 27);
            this.txtcheqquanmin.TabIndex = 5;
            this.txtcheqquanmin.Tag = "1";
            this.txtcheqquanmin.ValidationStyle.AcceptsTab = true;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqquanmin.ValidationStyle.PasswordChar = '\0';
            this.txtcheqquanmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqquanmin.Value = 0;
            this.txtcheqquanmin.TextChanged += new System.EventHandler(this.txtcheqquanmin_TextChanged);
            this.txtcheqquanmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // cbocheqstate
            // 
            // 
            // 
            // 
            this.cbocheqstate.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbocheqstate.CaptionStyle.CaptionSize = 100;
            this.cbocheqstate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqstate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbocheqstate.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqstate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqstate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqstate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.CaptionStyle.TextStyle.Text = "وضعیت چک";
            this.cbocheqstate.CheckedDisplaySeparator = ',';
            this.cbocheqstate.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqstate.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbocheqstate.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqstate.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbocheqstate.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles2.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles2.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbocheqstate.DropDownItemSelectionStyle = elListBoxSelectionStyles2;
            this.cbocheqstate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbocheqstate.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem3.Key = ((byte)(0));
            elListBoxItem3.Value = "انتظار";
            elListBoxItem4.Key = ((byte)(1));
            elListBoxItem4.Value = "ضمانت";
            elListBoxItem5.Key = ((byte)(2));
            elListBoxItem5.Value = "وصول";
            elListBoxItem6.Key = ((byte)(3));
            elListBoxItem6.Value = "برگشتی";
            elListBoxItem7.Key = ((byte)(4));
            elListBoxItem7.Value = "باطل";
            this.cbocheqstate.Items.Add(elListBoxItem3);
            this.cbocheqstate.Items.Add(elListBoxItem4);
            this.cbocheqstate.Items.Add(elListBoxItem5);
            this.cbocheqstate.Items.Add(elListBoxItem6);
            this.cbocheqstate.Items.Add(elListBoxItem7);
            this.cbocheqstate.Location = new System.Drawing.Point(144, 59);
            this.cbocheqstate.Name = "cbocheqstate";
            this.cbocheqstate.Size = new System.Drawing.Size(227, 27);
            this.cbocheqstate.TabIndex = 4;
            this.cbocheqstate.Tag = "1";
            this.cbocheqstate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cborelation_KeyPress);
            // 
            // cbocheqtype
            // 
            // 
            // 
            // 
            this.cbocheqtype.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbocheqtype.CaptionStyle.CaptionSize = 100;
            this.cbocheqtype.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqtype.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbocheqtype.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqtype.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqtype.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqtype.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.CaptionStyle.TextStyle.Text = "نوع چک";
            this.cbocheqtype.CheckedDisplaySeparator = ',';
            this.cbocheqtype.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqtype.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbocheqtype.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqtype.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbocheqtype.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles3.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles3.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbocheqtype.DropDownItemSelectionStyle = elListBoxSelectionStyles3;
            this.cbocheqtype.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbocheqtype.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            elListBoxItem8.Key = ((byte)(0));
            elListBoxItem8.Value = "صادره";
            elListBoxItem9.Key = ((byte)(1));
            elListBoxItem9.Value = "دریافتی";
            this.cbocheqtype.Items.Add(elListBoxItem8);
            this.cbocheqtype.Items.Add(elListBoxItem9);
            this.cbocheqtype.Location = new System.Drawing.Point(572, 3);
            this.cbocheqtype.Name = "cbocheqtype";
            this.cbocheqtype.Size = new System.Drawing.Size(210, 27);
            this.cbocheqtype.TabIndex = 0;
            this.cbocheqtype.Tag = "1";
            this.cbocheqtype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cborelation_KeyPress);
            // 
            // txtcsid
            // 
            this.txtcsid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsid.CaptionStyle.CaptionSize = 95;
            this.txtcsid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsid.CaptionStyle.TextStyle.Text = "دسته چک";
            this.txtcsid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsid.Location = new System.Drawing.Point(34, 31);
            this.txtcsid.Name = "txtcsid";
            this.txtcsid.Size = new System.Drawing.Size(337, 27);
            this.txtcsid.TabIndex = 2;
            this.txtcsid.Tag = "0";
            this.txtcsid.ValidationStyle.AcceptsTab = true;
            this.txtcsid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtcsid.ValidationStyle.PasswordChar = '\0';
            this.txtcsid.ValidationStyle.ReadOnly = true;
            this.txtcsid.Value = "";
            this.txtcsid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 95;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.Location = new System.Drawing.Point(413, 31);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(369, 27);
            this.txtaccid.TabIndex = 1;
            this.txtaccid.Tag = "1";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.Value = "0";
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // Tab3
            // 
            this.Tab3.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab3.CaptionTextStyle.Text = "دفتر تلفن";
            this.Tab3.Controls.Add(this.txtnamePH);
            this.Tab3.Controls.Add(this.cborelation);
            this.Tab3.Location = new System.Drawing.Point(1, 1);
            this.Tab3.Name = "Tab3";
            this.Tab3.Size = new System.Drawing.Size(786, 148);
            // 
            // txtnamePH
            // 
            this.txtnamePH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtnamePH.CaptionStyle.CaptionSize = 110;
            this.txtnamePH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtnamePH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtnamePH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtnamePH.CaptionStyle.TextStyle.Text = "نام و نام خانوادگی";
            this.txtnamePH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnamePH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtnamePH.Location = new System.Drawing.Point(514, 3);
            this.txtnamePH.Name = "txtnamePH";
            this.txtnamePH.Size = new System.Drawing.Size(268, 27);
            this.txtnamePH.TabIndex = 0;
            this.txtnamePH.Tag = "0";
            this.txtnamePH.ValidationStyle.AcceptsTab = true;
            this.txtnamePH.ValidationStyle.PasswordChar = '\0';
            this.txtnamePH.Value = "";
            this.txtnamePH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // cborelation
            // 
            // 
            // 
            // 
            this.cborelation.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cborelation.CaptionStyle.CaptionSize = 110;
            this.cborelation.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cborelation.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cborelation.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cborelation.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cborelation.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cborelation.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cborelation.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cborelation.CaptionStyle.TextStyle.Text = "نسبت فامیلی";
            this.cborelation.CheckedDisplaySeparator = ',';
            this.cborelation.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cborelation.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cborelation.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cborelation.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles4.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles4.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cborelation.DropDownItemSelectionStyle = elListBoxSelectionStyles4;
            this.cborelation.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cborelation.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cborelation.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            elListBoxItem10.Key = "0";
            elListBoxItem10.Value = "همسر";
            elListBoxItem11.Key = "1";
            elListBoxItem11.Value = "فرزند";
            elListBoxItem12.Key = "2";
            elListBoxItem12.Value = "آشنا/فامیل";
            elListBoxItem13.Key = "3";
            elListBoxItem13.Value = "دوست";
            elListBoxItem14.Key = "4";
            elListBoxItem14.Value = "همکار";
            elListBoxItem15.Key = "5";
            elListBoxItem15.Value = "سایر";
            this.cborelation.Items.Add(elListBoxItem10);
            this.cborelation.Items.Add(elListBoxItem11);
            this.cborelation.Items.Add(elListBoxItem12);
            this.cborelation.Items.Add(elListBoxItem13);
            this.cborelation.Items.Add(elListBoxItem14);
            this.cborelation.Items.Add(elListBoxItem15);
            this.cborelation.Location = new System.Drawing.Point(571, 31);
            this.cborelation.Name = "cborelation";
            this.cborelation.Size = new System.Drawing.Size(211, 27);
            this.cborelation.TabIndex = 1;
            this.cborelation.Tag = "0";
            this.cborelation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cborelation_KeyPress);
            // 
            // Tab4
            // 
            this.Tab4.BackgroundStyle.GradientAngle = 45F;
            this.Tab4.CaptionImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Tab4.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab4.CaptionTextStyle.Text = "درآمدها";
            this.Tab4.Controls.Add(this.lblSalmax);
            this.Tab4.Controls.Add(this.lblSalmin);
            this.Tab4.Controls.Add(this.txtsalmax);
            this.Tab4.Controls.Add(this.btnInsSal);
            this.Tab4.Controls.Add(this.txtbsid);
            this.Tab4.Controls.Add(this.txtsalnote);
            this.Tab4.Controls.Add(this.txtsalmin);
            this.Tab4.Location = new System.Drawing.Point(1, 1);
            this.Tab4.Name = "Tab4";
            this.Tab4.Size = new System.Drawing.Size(786, 148);
            // 
            // lblSalmax
            // 
            this.lblSalmax.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSalmax.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSalmax.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblSalmax.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSalmax.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSalmax.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle7.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle7.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle7.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle7.SolidColor = System.Drawing.Color.Transparent;
            this.lblSalmax.FlashStyle = paintStyle7;
            this.lblSalmax.Location = new System.Drawing.Point(11, 87);
            this.lblSalmax.Name = "lblSalmax";
            this.lblSalmax.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblSalmax.Size = new System.Drawing.Size(528, 25);
            this.lblSalmax.TabIndex = 14;
            this.lblSalmax.TabStop = false;
            this.lblSalmax.Tag = "0";
            this.lblSalmax.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSalmax.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalmax.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblSalmax.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSalmax.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblSalmin
            // 
            this.lblSalmin.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSalmin.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSalmin.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblSalmin.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSalmin.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSalmin.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle8.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle8.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle8.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle8.SolidColor = System.Drawing.Color.Transparent;
            this.lblSalmin.FlashStyle = paintStyle8;
            this.lblSalmin.Location = new System.Drawing.Point(11, 59);
            this.lblSalmin.Name = "lblSalmin";
            this.lblSalmin.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblSalmin.Size = new System.Drawing.Size(528, 25);
            this.lblSalmin.TabIndex = 13;
            this.lblSalmin.TabStop = false;
            this.lblSalmin.Tag = "0";
            this.lblSalmin.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSalmin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalmin.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblSalmin.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSalmin.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtsalmax
            // 
            this.txtsalmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalmax.CaptionStyle.CaptionSize = 105;
            this.txtsalmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalmax.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsalmax.CaptionStyle.TextStyle.Text = "مبلغ درامد حداکثر";
            this.txtsalmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsalmax.Location = new System.Drawing.Point(545, 87);
            this.txtsalmax.Name = "txtsalmax";
            this.txtsalmax.Size = new System.Drawing.Size(237, 27);
            this.txtsalmax.TabIndex = 3;
            this.txtsalmax.Tag = "1";
            this.txtsalmax.ValidationStyle.AcceptsTab = true;
            this.txtsalmax.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtsalmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsalmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsalmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsalmax.ValidationStyle.PasswordChar = '\0';
            this.txtsalmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsalmax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtsalmax.TextChanged += new System.EventHandler(this.txtsalmax_TextChanged);
            this.txtsalmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // btnInsSal
            // 
            this.btnInsSal.BackgroundImageStyle.Alpha = 100;
            this.btnInsSal.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image10")));
            this.btnInsSal.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsSal.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsSal.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsSal.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsSal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsSal.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsSal.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsSal.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsSal.Location = new System.Drawing.Point(503, 3);
            this.btnInsSal.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsSal.Name = "btnInsSal";
            this.btnInsSal.Size = new System.Drawing.Size(28, 27);
            this.btnInsSal.TabIndex = 1;
            this.btnInsSal.Tag = "0";
            this.btnInsSal.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsSal.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsSal.Click += new System.EventHandler(this.btnInsSal_Click);
            // 
            // txtbsid
            // 
            this.txtbsid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbsid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbsid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbsid.CaptionStyle.CaptionSize = 100;
            this.txtbsid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbsid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbsid.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbsid.CaptionStyle.TextStyle.Text = "نوع درآمد";
            this.txtbsid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbsid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbsid.Location = new System.Drawing.Point(532, 3);
            this.txtbsid.Name = "txtbsid";
            this.txtbsid.Size = new System.Drawing.Size(250, 27);
            this.txtbsid.TabIndex = 0;
            this.txtbsid.Tag = "1";
            this.txtbsid.ValidationStyle.AcceptsTab = true;
            this.txtbsid.ValidationStyle.PasswordChar = '\0';
            this.txtbsid.ValidationStyle.ReadOnly = true;
            this.txtbsid.Value = "";
            this.txtbsid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            this.txtbsid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // txtsalnote
            // 
            this.txtsalnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalnote.CaptionStyle.CaptionSize = 105;
            this.txtsalnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalnote.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsalnote.CaptionStyle.TextStyle.Text = "شرح درآمد";
            this.txtsalnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalnote.Location = new System.Drawing.Point(133, 31);
            this.txtsalnote.Name = "txtsalnote";
            this.txtsalnote.Size = new System.Drawing.Size(649, 27);
            this.txtsalnote.TabIndex = 1;
            this.txtsalnote.Tag = "1";
            this.txtsalnote.ValidationStyle.AcceptsTab = true;
            this.txtsalnote.ValidationStyle.PasswordChar = '\0';
            this.txtsalnote.Value = "";
            this.txtsalnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtsalmin
            // 
            this.txtsalmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalmin.CaptionStyle.CaptionSize = 105;
            this.txtsalmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalmin.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsalmin.CaptionStyle.TextStyle.Text = "مبلغ درآمد حداقل";
            this.txtsalmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsalmin.Location = new System.Drawing.Point(545, 59);
            this.txtsalmin.Name = "txtsalmin";
            this.txtsalmin.Size = new System.Drawing.Size(237, 27);
            this.txtsalmin.TabIndex = 2;
            this.txtsalmin.Tag = "1";
            this.txtsalmin.ValidationStyle.AcceptsTab = true;
            this.txtsalmin.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtsalmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsalmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsalmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsalmin.ValidationStyle.PasswordChar = '\0';
            this.txtsalmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsalmin.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtsalmin.TextChanged += new System.EventHandler(this.txtsalmin_TextChanged);
            this.txtsalmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // Tab5
            // 
            this.Tab5.BackgroundStyle.GradientAngle = 45F;
            this.Tab5.CaptionImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Tab5.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab5.CaptionTextStyle.Text = "هزینه ها";
            this.Tab5.Controls.Add(this.lblCostmax);
            this.Tab5.Controls.Add(this.lblCostmin);
            this.Tab5.Controls.Add(this.btnInsMem);
            this.Tab5.Controls.Add(this.txtcostmax);
            this.Tab5.Controls.Add(this.txtcostmin);
            this.Tab5.Controls.Add(this.btnInsCost);
            this.Tab5.Controls.Add(this.txtmemidC);
            this.Tab5.Controls.Add(this.txtbcid);
            this.Tab5.Controls.Add(this.txtcostnote);
            this.Tab5.Location = new System.Drawing.Point(1, 1);
            this.Tab5.Name = "Tab5";
            this.Tab5.Size = new System.Drawing.Size(786, 148);
            // 
            // lblCostmax
            // 
            this.lblCostmax.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblCostmax.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblCostmax.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblCostmax.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblCostmax.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblCostmax.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle9.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle9.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle9.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle9.SolidColor = System.Drawing.Color.Transparent;
            this.lblCostmax.FlashStyle = paintStyle9;
            this.lblCostmax.Location = new System.Drawing.Point(11, 87);
            this.lblCostmax.Name = "lblCostmax";
            this.lblCostmax.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblCostmax.Size = new System.Drawing.Size(528, 25);
            this.lblCostmax.TabIndex = 16;
            this.lblCostmax.TabStop = false;
            this.lblCostmax.Tag = "0";
            this.lblCostmax.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblCostmax.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostmax.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblCostmax.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblCostmax.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblCostmin
            // 
            this.lblCostmin.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblCostmin.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblCostmin.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblCostmin.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblCostmin.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblCostmin.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle10.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle10.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle10.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle10.SolidColor = System.Drawing.Color.Transparent;
            this.lblCostmin.FlashStyle = paintStyle10;
            this.lblCostmin.Location = new System.Drawing.Point(11, 59);
            this.lblCostmin.Name = "lblCostmin";
            this.lblCostmin.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblCostmin.Size = new System.Drawing.Size(528, 25);
            this.lblCostmin.TabIndex = 15;
            this.lblCostmin.TabStop = false;
            this.lblCostmin.Tag = "0";
            this.lblCostmin.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblCostmin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostmin.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblCostmin.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblCostmin.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnInsMem
            // 
            this.btnInsMem.BackgroundImageStyle.Alpha = 100;
            this.btnInsMem.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image11")));
            this.btnInsMem.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsMem.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsMem.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsMem.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsMem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsMem.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsMem.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsMem.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsMem.Location = new System.Drawing.Point(133, 3);
            this.btnInsMem.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsMem.Name = "btnInsMem";
            this.btnInsMem.Size = new System.Drawing.Size(28, 27);
            this.btnInsMem.TabIndex = 3;
            this.btnInsMem.Tag = "0";
            this.btnInsMem.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsMem.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsMem.Click += new System.EventHandler(this.btnInsMem_Click);
            // 
            // txtcostmax
            // 
            this.txtcostmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcostmax.CaptionStyle.CaptionSize = 105;
            this.txtcostmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcostmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcostmax.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmax.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmax.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcostmax.CaptionStyle.TextStyle.Text = "مبلغ هزینه حداکثر";
            this.txtcostmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcostmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcostmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcostmax.Location = new System.Drawing.Point(545, 87);
            this.txtcostmax.Name = "txtcostmax";
            this.txtcostmax.Size = new System.Drawing.Size(237, 27);
            this.txtcostmax.TabIndex = 6;
            this.txtcostmax.Tag = "1";
            this.txtcostmax.ValidationStyle.AcceptsTab = true;
            this.txtcostmax.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtcostmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcostmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcostmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtcostmax.ValidationStyle.PasswordChar = '\0';
            this.txtcostmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcostmax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtcostmax.TextChanged += new System.EventHandler(this.txtcostmax_TextChanged);
            this.txtcostmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // txtcostmin
            // 
            this.txtcostmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcostmin.CaptionStyle.CaptionSize = 105;
            this.txtcostmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcostmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcostmin.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmin.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmin.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtcostmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcostmin.CaptionStyle.TextStyle.Text = "مبلغ هزینه حداقل";
            this.txtcostmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcostmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcostmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcostmin.Location = new System.Drawing.Point(545, 59);
            this.txtcostmin.Name = "txtcostmin";
            this.txtcostmin.Size = new System.Drawing.Size(237, 27);
            this.txtcostmin.TabIndex = 5;
            this.txtcostmin.Tag = "1";
            this.txtcostmin.ValidationStyle.AcceptsTab = true;
            this.txtcostmin.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtcostmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcostmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcostmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtcostmin.ValidationStyle.PasswordChar = '\0';
            this.txtcostmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcostmin.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtcostmin.TextChanged += new System.EventHandler(this.txtcostmin_TextChanged);
            this.txtcostmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // btnInsCost
            // 
            this.btnInsCost.BackgroundImageStyle.Alpha = 100;
            this.btnInsCost.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image12")));
            this.btnInsCost.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCost.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsCost.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsCost.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsCost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsCost.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsCost.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsCost.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCost.Location = new System.Drawing.Point(499, 3);
            this.btnInsCost.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsCost.Name = "btnInsCost";
            this.btnInsCost.Size = new System.Drawing.Size(28, 27);
            this.btnInsCost.TabIndex = 1;
            this.btnInsCost.Tag = "0";
            this.btnInsCost.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsCost.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCost.Click += new System.EventHandler(this.btnInsCost_Click);
            // 
            // txtmemidC
            // 
            this.txtmemidC.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemidC.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemidC.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemidC.CaptionStyle.CaptionSize = 100;
            this.txtmemidC.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemidC.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemidC.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemidC.CaptionStyle.TextStyle.Text = "هزینه کننده";
            this.txtmemidC.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemidC.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemidC.Location = new System.Drawing.Point(162, 3);
            this.txtmemidC.Name = "txtmemidC";
            this.txtmemidC.Size = new System.Drawing.Size(244, 27);
            this.txtmemidC.TabIndex = 2;
            this.txtmemidC.Tag = "1";
            this.txtmemidC.ValidationStyle.AcceptsTab = true;
            this.txtmemidC.ValidationStyle.PasswordChar = '\0';
            this.txtmemidC.ValidationStyle.ReadOnly = true;
            this.txtmemidC.Value = "";
            this.txtmemidC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            this.txtmemidC.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // txtbcid
            // 
            this.txtbcid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbcid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbcid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbcid.CaptionStyle.CaptionSize = 100;
            this.txtbcid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbcid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbcid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbcid.CaptionStyle.TextStyle.Text = "نوع هزینه";
            this.txtbcid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbcid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbcid.Location = new System.Drawing.Point(528, 3);
            this.txtbcid.Name = "txtbcid";
            this.txtbcid.Size = new System.Drawing.Size(254, 27);
            this.txtbcid.TabIndex = 0;
            this.txtbcid.Tag = "1";
            this.txtbcid.ValidationStyle.AcceptsTab = true;
            this.txtbcid.ValidationStyle.PasswordChar = '\0';
            this.txtbcid.ValidationStyle.ReadOnly = true;
            this.txtbcid.Value = "";
            this.txtbcid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            this.txtbcid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // txtcostnote
            // 
            this.txtcostnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcostnote.CaptionStyle.CaptionSize = 105;
            this.txtcostnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcostnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcostnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcostnote.CaptionStyle.TextStyle.Text = "شرح هزینه";
            this.txtcostnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcostnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcostnote.Location = new System.Drawing.Point(133, 31);
            this.txtcostnote.Name = "txtcostnote";
            this.txtcostnote.Size = new System.Drawing.Size(649, 27);
            this.txtcostnote.TabIndex = 4;
            this.txtcostnote.Tag = "1";
            this.txtcostnote.ValidationStyle.AcceptsTab = true;
            this.txtcostnote.ValidationStyle.PasswordChar = '\0';
            this.txtcostnote.Value = "";
            this.txtcostnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnamePH_KeyPress);
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.repDataGrid);
            this.elContainer2.Location = new System.Drawing.Point(5, 290);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernBlack;
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(801, 323);
            this.elContainer2.TabIndex = 1;
            // 
            // repDataGrid
            // 
            this.repDataGrid.AllowUserToAddRows = false;
            this.repDataGrid.AllowUserToDeleteRows = false;
            this.repDataGrid.AllowUserToResizeColumns = false;
            this.repDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.repDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.repDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.repDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.repDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.repDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.repDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.repDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.repDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.repDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.repDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.repDataGrid.Location = new System.Drawing.Point(4, 3);
            this.repDataGrid.MultiSelect = false;
            this.repDataGrid.Name = "repDataGrid";
            this.repDataGrid.ReadOnly = true;
            this.repDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.repDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.repDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.repDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.repDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.repDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.repDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.repDataGrid.ShowCellErrors = false;
            this.repDataGrid.ShowCellToolTips = false;
            this.repDataGrid.ShowEditingIcon = false;
            this.repDataGrid.ShowRowErrors = false;
            this.repDataGrid.Size = new System.Drawing.Size(793, 317);
            this.repDataGrid.TabIndex = 2;
            this.repDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            // 
            // FrmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 618);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer2);
            this.Controls.Add(this.elContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmReport";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "گزارشات سیستم";
            this.Load += new System.EventHandler(this.FrmReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCreateRep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elGroupBox2)).EndInit();
            this.elGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdo12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpDate)).EndInit();
            this.grpDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btncurday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncuryear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btncurmonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btncurweek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabBase)).EndInit();
            this.tabBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Tab0)).EndInit();
            this.Tab0.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoTrans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoAcccard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoCheq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblstoremax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblstoremin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsBankid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsbaid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab1)).EndInit();
            this.Tab1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdopayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblloanqmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblloanqmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanqmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanqmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloanbacktype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIncAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab2)).EndInit();
            this.Tab2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdochdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochExpo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInscsid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnchAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblquanmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblquanmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqtype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab3)).EndInit();
            this.Tab3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtnamePH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cborelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab4)).EndInit();
            this.Tab4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lblSalmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSalmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsSal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbsid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab5)).EndInit();
            this.Tab5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lblCostmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCostmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsMem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbcid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.repDataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private Klik.Windows.Forms.v1.EntryLib.ELTab tabBase;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab0;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab2;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab1;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab3;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btncurday;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpDate;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btncuryear;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btncurmonth;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btncurweek;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox elGroupBox2;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo3;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo2;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo1;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo12;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo11;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo10;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo9;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo8;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo7;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo6;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo5;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdo4;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnCreateRep;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView repDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab4;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab5;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtnamePH;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cborelation;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsSal;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbsid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalnote;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalmin;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalmax;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnClear;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcostmax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcostmin;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsCost;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemidC;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbcid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcostnote;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsMem;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblSalmin;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblSalmax;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblCostmax;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblCostmin;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnPrint;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbocheqtype;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtinmode;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqquanmin;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbocheqstate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqquanmax;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInscsid;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnchAcc;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblquanmax;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblquanmin;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdochdate;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdochExpo;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccidA;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsBankid;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsbaid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbankid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbaid;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoAcccard;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoCheq;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblstoremax;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblstoremin;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstoremax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstoremin;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIncAcc;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanP;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoTrans;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblloanqmax;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblloanqmin;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanqmax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanqmin;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cboloanbacktype;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdopayment;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
    }
}