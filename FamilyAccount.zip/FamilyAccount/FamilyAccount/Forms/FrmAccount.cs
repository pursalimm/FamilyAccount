﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmAccount : Form
    {
        string selectedkeymem = string.Empty;
        string selectedkeybaid = string.Empty;
        string selectedkeybankid = string.Empty;
        int Row = 0;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmAccount()
        {
            InitializeComponent();
        }

        public static FrmAccount Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmAccount();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheque_Click(object sender, EventArgs e)
        {
            if (txtbaid.Text.Equals("جاری"))
            {
                FrmSetcheq fsr = new FrmSetcheq(txtaccid.Text);
                fsr.ShowDialog();
            }
            else
                MessageBox.Show("دسته چک به حسابهای از نوع جاری تعلق می گیرد", "نوع حساب", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void btnAccCard_Click(object sender, EventArgs e)
        {
            FrmAcccard fsr = new FrmAcccard(txtaccid.Text);
            fsr.ShowDialog();
        }

        private void btnOptbank_Click(object sender, EventArgs e)
        {
            FrmOptbank fsr = new FrmOptbank(txtaccid.Text, txtstore.Value.ToString());
            fsr.ShowDialog();
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnAbort_Click(sender, e);
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            ado.ClearControl(grpAccInternet);
            txtmemid.Focus();
        }

        private void txtaccid_Leave(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from account where accid='" + txtaccid.Text + "'");
            if (ds.Tables[0].Rows.Count != 0)
            {
                MessageBox.Show("شماره حساب وارد شده نامعتبر و قبلا ثبت شده است", "شماره حساب", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                txtaccid.Text = "";
                txtaccid.Focus();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@custid", SqlDbType.NVarChar).Value = txtcustid.Text;
            cmd.Parameters.Add("@accdate", SqlDbType.NVarChar).Value = txtaccdate.Text;
            cmd.Parameters.Add("@bankid", SqlDbType.Int).Value = selectedkeybankid;
            cmd.Parameters.Add("@store", SqlDbType.Money).Value = txtstore.Value.ToString();
            cmd.Parameters.Add("@baid", SqlDbType.Int).Value = selectedkeybaid;
            cmd.Parameters.Add("@accnote", SqlDbType.NVarChar).Value = txtaccnote.Text;
            cmd.Parameters.Add("@availrate", SqlDbType.Float).Value = txtavailrate.Value.ToString();
            cmd.Parameters.Add("@accuser", SqlDbType.NVarChar).Value = ado.EncryptText(txtaccuser.Text);
            cmd.Parameters.Add("@accpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtaccpass.Text);
            cmd.Parameters.Add("@secureid", SqlDbType.NVarChar).Value = ado.EncryptText(txtsecureid.Text);
            if(ado.insert(cmd, CommandType.StoredProcedure, "spInsertAccount"))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update account set memid=@memid,custid=@custid,accdate=@accdate,bankid=@bankid,store=@store,baid=@baid,accnote=@accnote,availrate=@availrate,accuser=@accuser,accpass=@accpass,secureid=@secureid where accid=@accid";
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@custid", SqlDbType.NVarChar).Value = txtcustid.Text;
            cmd.Parameters.Add("@accdate", SqlDbType.NVarChar).Value = txtaccdate.Text;
            cmd.Parameters.Add("@bankid", SqlDbType.Int).Value = selectedkeybankid;
            cmd.Parameters.Add("@store", SqlDbType.Money).Value = txtstore.Value.ToString();
            cmd.Parameters.Add("@baid", SqlDbType.Int).Value = selectedkeybaid;
            cmd.Parameters.Add("@accnote", SqlDbType.NVarChar).Value = txtaccnote.Text;
            cmd.Parameters.Add("@availrate", SqlDbType.Float).Value = txtavailrate.Value.ToString();
            cmd.Parameters.Add("@accuser", SqlDbType.NVarChar).Value = ado.EncryptText(txtaccuser.Text);
            cmd.Parameters.Add("@accpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtaccpass.Text);
            cmd.Parameters.Add("@secureid", SqlDbType.NVarChar).Value = ado.EncryptText(txtsecureid.Text);
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from account where accid=@accid";
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmAccount_Load(object sender, EventArgs e)
        {
            familyTableAdapter.Fill(accountDataSet.family);
            baseaccTableAdapter.Fill(accountDataSet.baseacc);
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from account");
            accDataGrid.DataSource = ds.Tables[0];
            if (accDataGrid.RowCount > 0)
            {
                double sum = 0;
                foreach (DataGridViewRow row in accDataGrid.Rows)
                    sum += Convert.ToDouble(row.Cells["store"].Value);
                lblsum.Text = sum.ToString("C0");
            }
        }

        private void cbomemid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void accDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (accDataGrid.RowCount > 0)
            {
                if (accDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;

                    btnCheque.Enabled = true;
                    btnAccCard.Enabled = true;
                    btnOptbank.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;

                    btnCheque.Enabled = true;
                    btnAccCard.Enabled = true;
                    btnOptbank.Enabled = true;
                    backContainer.Enabled = false;
                }
            }
        }

        private void SelectedAcc()
        {
            selectedkeymem = accDataGrid["memid", accDataGrid.CurrentRow.Index].Value.ToString();
            txtmemid.Text = accDataGrid["memid", accDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtaccid.Text = accDataGrid["accid", accDataGrid.CurrentRow.Index].Value.ToString();
            txtcustid.Text = accDataGrid["custid", accDataGrid.CurrentRow.Index].Value.ToString();
            txtaccdate.Text = accDataGrid["accdate", accDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybankid = accDataGrid["bankid", accDataGrid.CurrentRow.Index].Value.ToString();
            DataSet ds = ado.select("SELECT b.bankid, b.branchid, k.bankname, b.branchname FROM banks AS b INNER JOIN basebank AS k ON b.bbid = k.bbid");
            txtbankid.Text = ds.Tables[0].Rows[0][1].ToString() + "-" + ds.Tables[0].Rows[0][2].ToString() + " شعبه " + ds.Tables[0].Rows[0][3].ToString();
            txtstore.Value = accDataGrid["store", accDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybaid = accDataGrid["baid", accDataGrid.CurrentRow.Index].Value.ToString();
            txtbaid.Text = accDataGrid["baid", accDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtaccnote.Text = accDataGrid["accnote", accDataGrid.CurrentRow.Index].Value.ToString();
            txtavailrate.Value = accDataGrid["availrate", accDataGrid.CurrentRow.Index].Value.ToString();
            txtaccuser.Text = ado.DecryptText(accDataGrid["accuser", accDataGrid.CurrentRow.Index].Value.ToString());
            txtaccpass.Text = ado.DecryptText(accDataGrid["accpass", accDataGrid.CurrentRow.Index].Value.ToString());
            txtsecureid.Text = ado.DecryptText(accDataGrid["secureid", accDataGrid.CurrentRow.Index].Value.ToString());
        }

        private void accDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && accDataGrid.RowCount > 0)
            {
                SelectedAcc();
                if (accDataGrid.CurrentRow.Index == 0)
                    accDataGrid[0, 0].Selected = true;
                else
                    accDataGrid[0, accDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void accDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && accDataGrid.RowCount > 0)
                SelectedAcc();
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            btnCheque.Enabled = false;
            btnAccCard.Enabled = false;
            btnOptbank.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void txtaccuser_Enter(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

        private void txtaccuser_Leave(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

        private void txtaccdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtaccdate);
        }

        private void txtstore_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void txtstore_TextChanged(object sender, EventArgs e)
        {
            if (txtstore.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtstore.Text) == null) return;
                if (ado.ExtractNumbers(txtstore.Text).Length == 13) ProcessTabKey(true);
                lblStore.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtstore.Text))) + " ریال";
            }
            else
                lblStore.Text = "";
        }

        private void btnIns1_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymem = dgvr.Cells[0].Value.ToString();
                txtmemid.Text = dgvr.Cells[1].Value.ToString();
                txtmemidS.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnIns2_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT b.bankid, b.branchid, k.bankname, b.branchname FROM banks AS b INNER JOIN basebank AS k ON b.bbid = k.bbid");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT b.bankid, b.branchid, k.bankname, b.branchname FROM banks AS b INNER JOIN basebank AS k ON b.bbid = k.bbid");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybankid = dgvr.Cells[0].Value.ToString();
                txtbankid.Text = dgvr.Cells[1].Value.ToString() + "-" + dgvr.Cells[2].Value.ToString() + " شعبه " + dgvr.Cells[3].Value.ToString();
                txtbankS.Text = dgvr.Cells[1].Value.ToString() + "-" + dgvr.Cells[2].Value.ToString() + " شعبه " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnIns3_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from baseacc");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from baseacc");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybaid = dgvr.Cells[0].Value.ToString();
                txtbaid.Text = dgvr.Cells[1].Value.ToString();
                txtbaidS.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtmemid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT ac.memid, ac.accid, ac.custid, ac.accdate, ac.bankid, ac.store, ac.baid, ac.accnote, ac.availrate, ac.accuser, ac.accpass, ac.secureid "
                    + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                    + "banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid ";
            if (txtmemidS.Text.Trim().Length != 0)
                query += "AND fa.name like (N'%" + txtmemidS.Text + "%')";
            if (txtaccidS.Text.Trim().Length != 0)
                query += "AND ac.accid='" + txtaccidS.Text + "'";
            if (txtbankS.Text.Trim().Length != 0)
                query += "AND ac.bankid=" + selectedkeybankid;
            if (txtbaidS.Text.Trim().Length != 0)
                query += "AND ba.accname like (N'%" + txtbaidS.Text + "%')";

            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND ac.accdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND ac.accdate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND ac.accdate < '" + txtenddate.Text + "'";


            if (txtstoremin.Value.ToString() != "0" && txtstoremax.Value.ToString() != "0")
                query += "AND store between " + txtstoremin.Value.ToString() + " and " + txtstoremax.Value.ToString();
            else if (txtstoremin.Value.ToString() != "0")
                query += "AND store > " + txtstoremin.Value.ToString();
            else if (txtstoremax.Value.ToString() != "0")
                query += "AND store < " + txtstoremax.Value.ToString();

            DataSet ds = ado.select(query);
            accDataGrid.DataSource = ds.Tables[0];
            selectedkeybankid = string.Empty;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT ac.memid, ac.accid, ac.custid, ac.accdate, ac.bankid, ac.store, ac.baid, ac.accnote, ac.availrate, ac.accuser, ac.accpass, ac.secureid "
                    + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                    + "banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid ");
            accDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }
    }
}
