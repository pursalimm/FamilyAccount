﻿namespace FamilyAccount
{
    partial class FrmBaseInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmBaseInfo aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBaseInfo));
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.tabBase = new Klik.Windows.Forms.v1.EntryLib.ELTab();
            this.Tab0 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.elRichPanel5 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.bbankDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectB = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bbid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bankname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtbankname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab1 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.elRichPanel4 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.baccDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectA = new System.Windows.Forms.DataGridViewButtonColumn();
            this.baid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtaccname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab2 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.elRichPanel3 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.bsalDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectS = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bsid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtsalname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab3 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.bcostDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectC = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bcid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtcostname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.Tab4 = new Klik.Windows.Forms.v1.EntryLib.ELTabPage();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.bactDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectAC = new System.Windows.Forms.DataGridViewButtonColumn();
            this.baida = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.actname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtactname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabBase)).BeginInit();
            this.tabBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tab0)).BeginInit();
            this.Tab0.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel5)).BeginInit();
            this.elRichPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bbankDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab1)).BeginInit();
            this.Tab1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel4)).BeginInit();
            this.elRichPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.baccDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab2)).BeginInit();
            this.Tab2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel3)).BeginInit();
            this.elRichPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsalDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab3)).BeginInit();
            this.Tab3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bcostDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab4)).BeginInit();
            this.Tab4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bactDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtactname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.tabBase);
            this.backContainer.Location = new System.Drawing.Point(7, 6);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(574, 416);
            this.backContainer.TabIndex = 0;
            this.backContainer.Tag = "0";
            // 
            // tabBase
            // 
            this.tabBase.Location = new System.Drawing.Point(9, 7);
            this.tabBase.Name = "tabBase";
            this.tabBase.Size = new System.Drawing.Size(554, 400);
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.BackgroundPaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.BackgroundSolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabBase.TabCaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tabBase.TabIndex = 0;
            this.tabBase.TabPages.Add(this.Tab0);
            this.tabBase.TabPages.Add(this.Tab1);
            this.tabBase.TabPages.Add(this.Tab2);
            this.tabBase.TabPages.Add(this.Tab3);
            this.tabBase.TabPages.Add(this.Tab4);
            this.tabBase.SelectedTabPageChanged += new System.EventHandler(this.tabBase_SelectedTabPageChanged);
            // 
            // Tab0
            // 
            this.Tab0.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab0.CaptionTextStyle.Text = "بانکها و موسسات مالی";
            this.Tab0.Controls.Add(this.elRichPanel5);
            this.Tab0.Controls.Add(this.txtbankname);
            this.Tab0.Location = new System.Drawing.Point(1, 23);
            this.Tab0.Name = "Tab0";
            this.Tab0.Size = new System.Drawing.Size(552, 376);
            // 
            // elRichPanel5
            // 
            this.elRichPanel5.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel5.Controls.Add(this.bbankDataGrid);
            this.elRichPanel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.elRichPanel5.Expanded = true;
            this.elRichPanel5.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel5.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel5.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel5.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel5.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel5.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel5.Location = new System.Drawing.Point(0, 0);
            this.elRichPanel5.Name = "elRichPanel5";
            this.elRichPanel5.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel5.Size = new System.Drawing.Size(286, 376);
            this.elRichPanel5.TabIndex = 1;
            this.elRichPanel5.Tag = "0";
            // 
            // bbankDataGrid
            // 
            this.bbankDataGrid.AllowUserToAddRows = false;
            this.bbankDataGrid.AllowUserToDeleteRows = false;
            this.bbankDataGrid.AllowUserToResizeColumns = false;
            this.bbankDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.bbankDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.bbankDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bbankDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.bbankDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.bbankDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bbankDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.bbankDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.bbankDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectB,
            this.bbid,
            this.bankname});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bbankDataGrid.DefaultCellStyle = dataGridViewCellStyle28;
            this.bbankDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bbankDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.bbankDataGrid.Location = new System.Drawing.Point(1, 16);
            this.bbankDataGrid.MultiSelect = false;
            this.bbankDataGrid.Name = "bbankDataGrid";
            this.bbankDataGrid.ReadOnly = true;
            this.bbankDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bbankDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.bbankDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bbankDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.bbankDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.bbankDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bbankDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bbankDataGrid.ShowCellErrors = false;
            this.bbankDataGrid.ShowCellToolTips = false;
            this.bbankDataGrid.ShowEditingIcon = false;
            this.bbankDataGrid.ShowRowErrors = false;
            this.bbankDataGrid.Size = new System.Drawing.Size(284, 344);
            this.bbankDataGrid.TabIndex = 0;
            this.bbankDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.bbankDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bbankDataGrid_MouseClick);
            this.bbankDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bbankDataGrid_CellClick);
            this.bbankDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bbankDataGrid_KeyDown);
            // 
            // SelectB
            // 
            this.SelectB.HeaderText = "";
            this.SelectB.Name = "SelectB";
            this.SelectB.ReadOnly = true;
            this.SelectB.Text = "انتخاب";
            this.SelectB.UseColumnTextForButtonValue = true;
            // 
            // bbid
            // 
            this.bbid.DataPropertyName = "bbid";
            this.bbid.HeaderText = "کد";
            this.bbid.Name = "bbid";
            this.bbid.ReadOnly = true;
            this.bbid.Visible = false;
            // 
            // bankname
            // 
            this.bankname.DataPropertyName = "bankname";
            this.bankname.HeaderText = "عنوان بانک";
            this.bankname.Name = "bankname";
            this.bankname.ReadOnly = true;
            // 
            // txtbankname
            // 
            this.txtbankname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbankname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbankname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbankname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankname.CaptionStyle.TextStyle.Text = "عنوان بانک";
            this.txtbankname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbankname.Location = new System.Drawing.Point(296, 6);
            this.txtbankname.Name = "txtbankname";
            this.txtbankname.Size = new System.Drawing.Size(247, 27);
            this.txtbankname.TabIndex = 0;
            this.txtbankname.Tag = "1";
            this.txtbankname.ValidationStyle.AcceptsTab = true;
            this.txtbankname.ValidationStyle.PasswordChar = '\0';
            this.txtbankname.Value = "";
            this.txtbankname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpid_KeyPress);
            // 
            // Tab1
            // 
            this.Tab1.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab1.CaptionTextStyle.Text = "حسابهای بانکی";
            this.Tab1.Controls.Add(this.elRichPanel4);
            this.Tab1.Controls.Add(this.txtaccname);
            this.Tab1.Location = new System.Drawing.Point(1, 23);
            this.Tab1.Name = "Tab1";
            this.Tab1.Size = new System.Drawing.Size(552, 376);
            // 
            // elRichPanel4
            // 
            this.elRichPanel4.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel4.Controls.Add(this.baccDataGrid);
            this.elRichPanel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.elRichPanel4.Expanded = true;
            this.elRichPanel4.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel4.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel4.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel4.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel4.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel4.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel4.Location = new System.Drawing.Point(0, 0);
            this.elRichPanel4.Name = "elRichPanel4";
            this.elRichPanel4.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel4.Size = new System.Drawing.Size(286, 376);
            this.elRichPanel4.TabIndex = 1;
            this.elRichPanel4.Tag = "0";
            // 
            // baccDataGrid
            // 
            this.baccDataGrid.AllowUserToAddRows = false;
            this.baccDataGrid.AllowUserToDeleteRows = false;
            this.baccDataGrid.AllowUserToResizeColumns = false;
            this.baccDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.baccDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.baccDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.baccDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.baccDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.baccDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.baccDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.baccDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.baccDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectA,
            this.baid,
            this.accname});
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.baccDataGrid.DefaultCellStyle = dataGridViewCellStyle33;
            this.baccDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.baccDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.baccDataGrid.Location = new System.Drawing.Point(1, 16);
            this.baccDataGrid.MultiSelect = false;
            this.baccDataGrid.Name = "baccDataGrid";
            this.baccDataGrid.ReadOnly = true;
            this.baccDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.baccDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.baccDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.baccDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle35;
            this.baccDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.baccDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.baccDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.baccDataGrid.ShowCellErrors = false;
            this.baccDataGrid.ShowCellToolTips = false;
            this.baccDataGrid.ShowEditingIcon = false;
            this.baccDataGrid.ShowRowErrors = false;
            this.baccDataGrid.Size = new System.Drawing.Size(284, 344);
            this.baccDataGrid.TabIndex = 0;
            this.baccDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.baccDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.baccDataGrid_MouseClick);
            this.baccDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.baccDataGrid_CellClick);
            this.baccDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.baccDataGrid_KeyDown);
            // 
            // SelectA
            // 
            this.SelectA.HeaderText = "";
            this.SelectA.Name = "SelectA";
            this.SelectA.ReadOnly = true;
            this.SelectA.Text = "انتخاب";
            this.SelectA.UseColumnTextForButtonValue = true;
            // 
            // baid
            // 
            this.baid.DataPropertyName = "baid";
            this.baid.HeaderText = "کد";
            this.baid.Name = "baid";
            this.baid.ReadOnly = true;
            this.baid.Visible = false;
            // 
            // accname
            // 
            this.accname.DataPropertyName = "accname";
            this.accname.HeaderText = "عنوان حساب";
            this.accname.Name = "accname";
            this.accname.ReadOnly = true;
            // 
            // txtaccname
            // 
            this.txtaccname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccname.CaptionStyle.TextStyle.Text = "عنوان حساب ";
            this.txtaccname.EditBoxStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.txtaccname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccname.Location = new System.Drawing.Point(296, 6);
            this.txtaccname.Name = "txtaccname";
            this.txtaccname.Size = new System.Drawing.Size(247, 27);
            this.txtaccname.TabIndex = 0;
            this.txtaccname.Tag = "1";
            this.txtaccname.ValidationStyle.AcceptsTab = true;
            this.txtaccname.ValidationStyle.PasswordChar = '\0';
            this.txtaccname.Value = "";
            this.txtaccname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpid_KeyPress);
            // 
            // Tab2
            // 
            this.Tab2.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab2.CaptionTextStyle.Text = "درآمدها";
            this.Tab2.Controls.Add(this.elRichPanel3);
            this.Tab2.Controls.Add(this.txtsalname);
            this.Tab2.Location = new System.Drawing.Point(1, 23);
            this.Tab2.Name = "Tab2";
            this.Tab2.Size = new System.Drawing.Size(552, 376);
            // 
            // elRichPanel3
            // 
            this.elRichPanel3.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel3.Controls.Add(this.bsalDataGrid);
            this.elRichPanel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.elRichPanel3.Expanded = true;
            this.elRichPanel3.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel3.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel3.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel3.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel3.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel3.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel3.Location = new System.Drawing.Point(0, 0);
            this.elRichPanel3.Name = "elRichPanel3";
            this.elRichPanel3.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel3.Size = new System.Drawing.Size(286, 376);
            this.elRichPanel3.TabIndex = 1;
            this.elRichPanel3.Tag = "0";
            // 
            // bsalDataGrid
            // 
            this.bsalDataGrid.AllowUserToAddRows = false;
            this.bsalDataGrid.AllowUserToDeleteRows = false;
            this.bsalDataGrid.AllowUserToResizeColumns = false;
            this.bsalDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.bsalDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle36;
            this.bsalDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bsalDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.bsalDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.bsalDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bsalDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.bsalDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.bsalDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectS,
            this.bsid,
            this.salname});
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bsalDataGrid.DefaultCellStyle = dataGridViewCellStyle38;
            this.bsalDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bsalDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.bsalDataGrid.Location = new System.Drawing.Point(1, 16);
            this.bsalDataGrid.MultiSelect = false;
            this.bsalDataGrid.Name = "bsalDataGrid";
            this.bsalDataGrid.ReadOnly = true;
            this.bsalDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bsalDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.bsalDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bsalDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.bsalDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.bsalDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bsalDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bsalDataGrid.ShowCellErrors = false;
            this.bsalDataGrid.ShowCellToolTips = false;
            this.bsalDataGrid.ShowEditingIcon = false;
            this.bsalDataGrid.ShowRowErrors = false;
            this.bsalDataGrid.Size = new System.Drawing.Size(284, 344);
            this.bsalDataGrid.TabIndex = 0;
            this.bsalDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.bsalDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bsalDataGrid_MouseClick);
            this.bsalDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bsalDataGrid_CellClick);
            this.bsalDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bsalDataGrid_KeyDown);
            // 
            // SelectS
            // 
            this.SelectS.HeaderText = "";
            this.SelectS.Name = "SelectS";
            this.SelectS.ReadOnly = true;
            this.SelectS.Text = "انتخاب";
            this.SelectS.UseColumnTextForButtonValue = true;
            // 
            // bsid
            // 
            this.bsid.DataPropertyName = "bsid";
            this.bsid.HeaderText = "کد";
            this.bsid.Name = "bsid";
            this.bsid.ReadOnly = true;
            this.bsid.Visible = false;
            // 
            // salname
            // 
            this.salname.DataPropertyName = "salname";
            this.salname.HeaderText = "عنوان درآمد";
            this.salname.Name = "salname";
            this.salname.ReadOnly = true;
            // 
            // txtsalname
            // 
            this.txtsalname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalname.CaptionStyle.TextStyle.Text = "عنوان درآمد";
            this.txtsalname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalname.Location = new System.Drawing.Point(296, 6);
            this.txtsalname.Name = "txtsalname";
            this.txtsalname.Size = new System.Drawing.Size(247, 27);
            this.txtsalname.TabIndex = 0;
            this.txtsalname.Tag = "1";
            this.txtsalname.ValidationStyle.AcceptsTab = true;
            this.txtsalname.ValidationStyle.PasswordChar = '\0';
            this.txtsalname.Value = "";
            this.txtsalname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpid_KeyPress);
            // 
            // Tab3
            // 
            this.Tab3.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab3.CaptionTextStyle.Text = "هزینه ها";
            this.Tab3.Controls.Add(this.elRichPanel2);
            this.Tab3.Controls.Add(this.txtcostname);
            this.Tab3.Location = new System.Drawing.Point(1, 23);
            this.Tab3.Name = "Tab3";
            this.Tab3.Size = new System.Drawing.Size(552, 376);
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.Controls.Add(this.bcostDataGrid);
            this.elRichPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.Location = new System.Drawing.Point(0, 0);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel2.Size = new System.Drawing.Size(286, 376);
            this.elRichPanel2.TabIndex = 1;
            this.elRichPanel2.Tag = "0";
            // 
            // bcostDataGrid
            // 
            this.bcostDataGrid.AllowUserToAddRows = false;
            this.bcostDataGrid.AllowUserToDeleteRows = false;
            this.bcostDataGrid.AllowUserToResizeColumns = false;
            this.bcostDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.bcostDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.bcostDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bcostDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.bcostDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.bcostDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bcostDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.bcostDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.bcostDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectC,
            this.bcid,
            this.costname});
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bcostDataGrid.DefaultCellStyle = dataGridViewCellStyle43;
            this.bcostDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bcostDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.bcostDataGrid.Location = new System.Drawing.Point(1, 16);
            this.bcostDataGrid.MultiSelect = false;
            this.bcostDataGrid.Name = "bcostDataGrid";
            this.bcostDataGrid.ReadOnly = true;
            this.bcostDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bcostDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.bcostDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bcostDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.bcostDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.bcostDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bcostDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bcostDataGrid.ShowCellErrors = false;
            this.bcostDataGrid.ShowCellToolTips = false;
            this.bcostDataGrid.ShowEditingIcon = false;
            this.bcostDataGrid.ShowRowErrors = false;
            this.bcostDataGrid.Size = new System.Drawing.Size(284, 344);
            this.bcostDataGrid.TabIndex = 0;
            this.bcostDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.bcostDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bcostDataGrid_MouseClick);
            this.bcostDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bcostDataGrid_CellClick);
            this.bcostDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bcostDataGrid_KeyDown);
            // 
            // SelectC
            // 
            this.SelectC.HeaderText = "";
            this.SelectC.Name = "SelectC";
            this.SelectC.ReadOnly = true;
            this.SelectC.Text = "انتخاب";
            this.SelectC.UseColumnTextForButtonValue = true;
            // 
            // bcid
            // 
            this.bcid.DataPropertyName = "bcid";
            this.bcid.HeaderText = "کد";
            this.bcid.Name = "bcid";
            this.bcid.ReadOnly = true;
            this.bcid.Visible = false;
            // 
            // costname
            // 
            this.costname.DataPropertyName = "costname";
            this.costname.HeaderText = "عنوان هزینه";
            this.costname.Name = "costname";
            this.costname.ReadOnly = true;
            // 
            // txtcostname
            // 
            this.txtcostname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcostname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcostname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcostname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcostname.CaptionStyle.TextStyle.Text = "عنوان هزینه";
            this.txtcostname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcostname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcostname.Location = new System.Drawing.Point(296, 6);
            this.txtcostname.Name = "txtcostname";
            this.txtcostname.Size = new System.Drawing.Size(247, 27);
            this.txtcostname.TabIndex = 0;
            this.txtcostname.Tag = "1";
            this.txtcostname.ValidationStyle.AcceptsTab = true;
            this.txtcostname.ValidationStyle.PasswordChar = '\0';
            this.txtcostname.Value = "";
            this.txtcostname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpid_KeyPress);
            // 
            // Tab4
            // 
            this.Tab4.CaptionTextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tab4.CaptionTextStyle.Text = "فعالیتها";
            this.Tab4.Controls.Add(this.elRichPanel1);
            this.Tab4.Controls.Add(this.txtactname);
            this.Tab4.Location = new System.Drawing.Point(1, 23);
            this.Tab4.Name = "Tab4";
            this.Tab4.Size = new System.Drawing.Size(552, 376);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.Controls.Add(this.bactDataGrid);
            this.elRichPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.Location = new System.Drawing.Point(0, 0);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(286, 376);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // bactDataGrid
            // 
            this.bactDataGrid.AllowUserToAddRows = false;
            this.bactDataGrid.AllowUserToDeleteRows = false;
            this.bactDataGrid.AllowUserToResizeColumns = false;
            this.bactDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.bactDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle46;
            this.bactDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bactDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.bactDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.bactDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bactDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.bactDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.bactDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectAC,
            this.baida,
            this.actname});
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bactDataGrid.DefaultCellStyle = dataGridViewCellStyle48;
            this.bactDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bactDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.bactDataGrid.Location = new System.Drawing.Point(1, 16);
            this.bactDataGrid.MultiSelect = false;
            this.bactDataGrid.Name = "bactDataGrid";
            this.bactDataGrid.ReadOnly = true;
            this.bactDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bactDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.bactDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bactDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle50;
            this.bactDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.bactDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bactDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bactDataGrid.ShowCellErrors = false;
            this.bactDataGrid.ShowCellToolTips = false;
            this.bactDataGrid.ShowEditingIcon = false;
            this.bactDataGrid.ShowRowErrors = false;
            this.bactDataGrid.Size = new System.Drawing.Size(284, 344);
            this.bactDataGrid.TabIndex = 0;
            this.bactDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.bactDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bactDataGrid_MouseClick);
            this.bactDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bactDataGrid_CellClick);
            this.bactDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bactDataGrid_KeyDown);
            // 
            // SelectAC
            // 
            this.SelectAC.HeaderText = "";
            this.SelectAC.Name = "SelectAC";
            this.SelectAC.ReadOnly = true;
            this.SelectAC.Text = "انتخاب";
            this.SelectAC.UseColumnTextForButtonValue = true;
            // 
            // baida
            // 
            this.baida.DataPropertyName = "baid";
            this.baida.HeaderText = "کد";
            this.baida.Name = "baida";
            this.baida.ReadOnly = true;
            this.baida.Visible = false;
            // 
            // actname
            // 
            this.actname.DataPropertyName = "actname";
            this.actname.HeaderText = "عنوان فعالیت";
            this.actname.Name = "actname";
            this.actname.ReadOnly = true;
            // 
            // txtactname
            // 
            this.txtactname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtactname.CaptionStyle.CaptionSize = 90;
            this.txtactname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtactname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtactname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtactname.CaptionStyle.TextStyle.Text = "عنوان فعالیت";
            this.txtactname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtactname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtactname.Location = new System.Drawing.Point(296, 6);
            this.txtactname.Name = "txtactname";
            this.txtactname.Size = new System.Drawing.Size(247, 27);
            this.txtactname.TabIndex = 0;
            this.txtactname.Tag = "1";
            this.txtactname.ValidationStyle.AcceptsTab = true;
            this.txtactname.ValidationStyle.PasswordChar = '\0';
            this.txtactname.Value = "";
            this.txtactname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpid_KeyPress);
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(51, 429);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 1;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // FrmBaseInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 477);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.backContainer);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmBaseInfo";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اطلاعات پایه سیستم";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmBaseInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabBase)).EndInit();
            this.tabBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Tab0)).EndInit();
            this.Tab0.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel5)).EndInit();
            this.elRichPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bbankDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab1)).EndInit();
            this.Tab1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel4)).EndInit();
            this.elRichPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.baccDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab2)).EndInit();
            this.Tab2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel3)).EndInit();
            this.elRichPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bsalDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab3)).EndInit();
            this.Tab3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bcostDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcostname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tab4)).EndInit();
            this.Tab4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bactDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtactname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELTab tabBase;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab0;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbankname;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccname;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalname;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab3;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcostname;
        private Klik.Windows.Forms.v1.EntryLib.ELTabPage Tab4;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtactname;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel5;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView bbankDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel4;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView baccDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel3;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView bsalDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView bcostDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView bactDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private System.Windows.Forms.DataGridViewButtonColumn SelectB;
        private System.Windows.Forms.DataGridViewTextBoxColumn bbid;
        private System.Windows.Forms.DataGridViewTextBoxColumn bankname;
        private System.Windows.Forms.DataGridViewButtonColumn SelectA;
        private System.Windows.Forms.DataGridViewTextBoxColumn baid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accname;
        private System.Windows.Forms.DataGridViewButtonColumn SelectS;
        private System.Windows.Forms.DataGridViewTextBoxColumn bsid;
        private System.Windows.Forms.DataGridViewTextBoxColumn salname;
        private System.Windows.Forms.DataGridViewButtonColumn SelectC;
        private System.Windows.Forms.DataGridViewTextBoxColumn bcid;
        private System.Windows.Forms.DataGridViewTextBoxColumn costname;
        private System.Windows.Forms.DataGridViewButtonColumn SelectAC;
        private System.Windows.Forms.DataGridViewTextBoxColumn baida;
        private System.Windows.Forms.DataGridViewTextBoxColumn actname;
    }
}