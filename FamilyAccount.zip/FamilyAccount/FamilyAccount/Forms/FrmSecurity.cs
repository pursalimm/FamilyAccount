﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FamilyAccount
{
    public partial class FrmSecurity : Form
    {
        string idSel = "";
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.AccountConnectionString);
        public FrmSecurity()
        {
            InitializeComponent();
        }

        public static FrmSecurity Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmSecurity();
            }
            return aForm;
        }

        private void btnSaveOk_Click(object sender, EventArgs e)
        {
            if (txtusername.Text != "")
            {
                if (txtpassword.Text != "")
                {
                    if (!Convert.ToBoolean(string.Compare(txtpassword.Text, txtconfirmpass.Text)))
                    {
                        if (cbosecureques.Text != "" && txtquesanswer.Text != "")
                        {
                            cmd.Parameters.Clear();
                            cmd.CommandText = "update security set username=@username,password=@password,secureques=@secureques,quesanswer=@quesanswer where iduser=@iduser";
                            cmd.Parameters.Add("@iduser", SqlDbType.Int).Value = idSel;
                            cmd.Parameters.Add("@username", SqlDbType.NVarChar).Value = txtusername.Text;
                            cmd.Parameters.Add("@password", SqlDbType.NVarChar).Value = ado.EncryptText(txtpassword.Text);
                            cmd.Parameters.Add("@secureques", SqlDbType.NVarChar).Value = cbosecureques.Text;
                            cmd.Parameters.Add("@quesanswer", SqlDbType.NVarChar).Value = ado.EncryptText(txtquesanswer.Text);
                            cmd.Connection = cnn;
                            cnn.Open();
                            cmd.ExecuteNonQuery();
                            cnn.Close();
                            Properties.Settings.Default.ShowLogin = true;
                            Properties.Settings.Default.Save();
                            this.Close();
                        }
                        else
                            MessageBox.Show("لطفا سئوال امنیتی و جواب آنرا جهت مواقع فراموشی کلمه عبور وارد نمائید", "سئوال امنیتی", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    }
                    else
                        MessageBox.Show("کلمه عبور و تائیدیه آن باید یکسان باشد", "کلمه عبور", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                }
                else
                    MessageBox.Show("کلمه عبور را وارد نمائید", "کلمه عبور", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            }
            else
                MessageBox.Show("لطفا نام کاربری را وارد نمائید", "نام کاربری", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void FrmSecurity_Load(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from security");
            idSel = ds.Tables[0].Rows[0]["iduser"].ToString();
            txtusername.Text = ds.Tables[0].Rows[0]["username"].ToString();
            txtpassword.Text = ado.DecryptText(ds.Tables[0].Rows[0]["password"].ToString());
            txtconfirmpass.Text = ado.DecryptText(ds.Tables[0].Rows[0]["password"].ToString());
            cbosecureques.Text = ds.Tables[0].Rows[0]["secureques"].ToString();
            txtquesanswer.Text = ado.DecryptText(ds.Tables[0].Rows[0]["quesanswer"].ToString());
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtusername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void txtpassword_Enter(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

        private void txtpassword_Leave(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

    }
}
