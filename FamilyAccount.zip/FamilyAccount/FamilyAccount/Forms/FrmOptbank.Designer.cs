﻿namespace FamilyAccount
{
    partial class FrmOptbank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle3 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOptbank));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.rdoSettle = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdoTake = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.lblRemain = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblSettle = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lblTake = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtquandate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton3 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.txtquantake = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtquannote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtquansettle = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtquanremain = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.detailDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quandate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quannote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantake = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quansettle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quanremain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elContainer3 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elButton6 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton8 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.rdoremainS = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdotakeS = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdosettleS = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.txtnoteS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmaxMoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtminMoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoSettle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRemain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSettle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquandate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtquantake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquannote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquansettle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquanremain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.detailDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).BeginInit();
            this.elContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoremainS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdotakeS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdosettleS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnoteS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaxMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtminMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.rdoSettle);
            this.backContainer.Controls.Add(this.rdoTake);
            this.backContainer.Controls.Add(this.lblRemain);
            this.backContainer.Controls.Add(this.lblSettle);
            this.backContainer.Controls.Add(this.lblTake);
            this.backContainer.Controls.Add(this.txtaccid);
            this.backContainer.Controls.Add(this.txtquandate);
            this.backContainer.Controls.Add(this.txtquantake);
            this.backContainer.Controls.Add(this.txtquannote);
            this.backContainer.Controls.Add(this.txtquansettle);
            this.backContainer.Controls.Add(this.txtquanremain);
            this.backContainer.Location = new System.Drawing.Point(8, 32);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(592, 185);
            this.backContainer.TabIndex = 0;
            // 
            // rdoSettle
            // 
            this.rdoSettle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdoSettle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdoSettle.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdoSettle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoSettle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoSettle.Location = new System.Drawing.Point(559, 93);
            this.rdoSettle.Name = "rdoSettle";
            this.rdoSettle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoSettle.Size = new System.Drawing.Size(23, 27);
            this.rdoSettle.TabIndex = 4;
            this.rdoSettle.Tag = "0";
            this.rdoSettle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoSettle.Value = false;
            this.rdoSettle.CheckedChanged += new System.EventHandler(this.rdoSettle_CheckedChanged);
            // 
            // rdoTake
            // 
            this.rdoTake.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdoTake.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.rdoTake.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdoTake.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoTake.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoTake.Location = new System.Drawing.Point(559, 64);
            this.rdoTake.Name = "rdoTake";
            this.rdoTake.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoTake.Size = new System.Drawing.Size(23, 27);
            this.rdoTake.TabIndex = 2;
            this.rdoTake.Tag = "0";
            this.rdoTake.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoTake.Value = false;
            this.rdoTake.CheckedChanged += new System.EventHandler(this.rdoTake_CheckedChanged);
            // 
            // lblRemain
            // 
            this.lblRemain.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblRemain.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblRemain.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblRemain.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblRemain.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblRemain.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.Transparent;
            this.lblRemain.FlashStyle = paintStyle1;
            this.lblRemain.Location = new System.Drawing.Point(8, 122);
            this.lblRemain.Name = "lblRemain";
            this.lblRemain.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblRemain.Size = new System.Drawing.Size(354, 27);
            this.lblRemain.TabIndex = 9;
            this.lblRemain.TabStop = false;
            this.lblRemain.Tag = "0";
            this.lblRemain.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblRemain.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemain.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblRemain.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblRemain.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblSettle
            // 
            this.lblSettle.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSettle.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSettle.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblSettle.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSettle.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSettle.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.Transparent;
            this.lblSettle.FlashStyle = paintStyle2;
            this.lblSettle.Location = new System.Drawing.Point(8, 93);
            this.lblSettle.Name = "lblSettle";
            this.lblSettle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblSettle.Size = new System.Drawing.Size(354, 27);
            this.lblSettle.TabIndex = 8;
            this.lblSettle.TabStop = false;
            this.lblSettle.Tag = "0";
            this.lblSettle.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSettle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettle.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblSettle.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSettle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lblTake
            // 
            this.lblTake.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblTake.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblTake.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblTake.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblTake.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblTake.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle3.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle3.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle3.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle3.SolidColor = System.Drawing.Color.Transparent;
            this.lblTake.FlashStyle = paintStyle3;
            this.lblTake.Location = new System.Drawing.Point(8, 64);
            this.lblTake.Name = "lblTake";
            this.lblTake.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblTake.Size = new System.Drawing.Size(354, 27);
            this.lblTake.TabIndex = 7;
            this.lblTake.TabStop = false;
            this.lblTake.Tag = "0";
            this.lblTake.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblTake.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTake.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblTake.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblTake.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 85;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccid.Location = new System.Drawing.Point(346, 6);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(236, 27);
            this.txtaccid.TabIndex = 0;
            this.txtaccid.Tag = "1";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.ValidationStyle.ReadOnly = true;
            this.txtaccid.Value = "";
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            this.txtaccid.Enter += new System.EventHandler(this.txtaccid_Enter);
            // 
            // txtquandate
            // 
            this.txtquandate.ButtonStyle.Buttons.Add(this.elEntryBoxButton3);
            this.txtquandate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquandate.CaptionStyle.CaptionSize = 85;
            this.txtquandate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquandate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquandate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquandate.CaptionStyle.TextStyle.Text = "تاریخ";
            this.txtquandate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquandate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquandate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtquandate.Location = new System.Drawing.Point(395, 35);
            this.txtquandate.Name = "txtquandate";
            this.txtquandate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtquandate.Size = new System.Drawing.Size(187, 27);
            this.txtquandate.TabIndex = 1;
            this.txtquandate.Tag = "1";
            this.txtquandate.ValidationStyle.AcceptsTab = true;
            this.txtquandate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtquandate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtquandate.ValidationStyle.PasswordChar = '\0';
            this.txtquandate.Value = "";
            this.txtquandate.Leave += new System.EventHandler(this.txtquandate_Leave);
            this.txtquandate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton3
            // 
            this.elEntryBoxButton3.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton3.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton3.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // txtquantake
            // 
            this.txtquantake.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtquantake.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtquantake.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquantake.CaptionStyle.CaptionSize = 65;
            this.txtquantake.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquantake.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquantake.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquantake.CaptionStyle.TextStyle.Text = "برداشت";
            this.txtquantake.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquantake.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquantake.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtquantake.Enabled = false;
            this.txtquantake.Location = new System.Drawing.Point(369, 64);
            this.txtquantake.Name = "txtquantake";
            this.txtquantake.Size = new System.Drawing.Size(193, 27);
            this.txtquantake.TabIndex = 3;
            this.txtquantake.Tag = "0";
            this.txtquantake.ValidationStyle.AcceptsTab = true;
            this.txtquantake.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtquantake.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtquantake.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtquantake.ValidationStyle.PasswordChar = '\0';
            this.txtquantake.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtquantake.Value = 0;
            this.txtquantake.TextChanged += new System.EventHandler(this.txtquantake_TextChanged);
            this.txtquantake.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantake_KeyPress);
            // 
            // txtquannote
            // 
            this.txtquannote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquannote.CaptionStyle.CaptionSize = 85;
            this.txtquannote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquannote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquannote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquannote.CaptionStyle.TextStyle.Text = "شرح تراکنش";
            this.txtquannote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquannote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquannote.Location = new System.Drawing.Point(8, 151);
            this.txtquannote.Name = "txtquannote";
            this.txtquannote.Size = new System.Drawing.Size(574, 27);
            this.txtquannote.TabIndex = 7;
            this.txtquannote.Tag = "0";
            this.txtquannote.ValidationStyle.AcceptsTab = true;
            this.txtquannote.ValidationStyle.PasswordChar = '\0';
            this.txtquannote.Value = "";
            this.txtquannote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtquansettle
            // 
            this.txtquansettle.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtquansettle.CaptionStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtquansettle.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquansettle.CaptionStyle.CaptionSize = 65;
            this.txtquansettle.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquansettle.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquansettle.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquansettle.CaptionStyle.TextStyle.Text = "واریز";
            this.txtquansettle.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquansettle.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquansettle.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtquansettle.Enabled = false;
            this.txtquansettle.Location = new System.Drawing.Point(369, 93);
            this.txtquansettle.Name = "txtquansettle";
            this.txtquansettle.Size = new System.Drawing.Size(193, 27);
            this.txtquansettle.TabIndex = 5;
            this.txtquansettle.Tag = "0";
            this.txtquansettle.ValidationStyle.AcceptsTab = true;
            this.txtquansettle.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtquansettle.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtquansettle.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtquansettle.ValidationStyle.PasswordChar = '\0';
            this.txtquansettle.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtquansettle.Value = 0;
            this.txtquansettle.TextChanged += new System.EventHandler(this.txtquansettle_TextChanged);
            this.txtquansettle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantake_KeyPress);
            // 
            // txtquanremain
            // 
            this.txtquanremain.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquanremain.CaptionStyle.CaptionSize = 85;
            this.txtquanremain.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquanremain.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquanremain.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquanremain.CaptionStyle.TextStyle.Text = "باقیمانده";
            this.txtquanremain.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquanremain.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquanremain.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtquanremain.Location = new System.Drawing.Point(368, 122);
            this.txtquanremain.Name = "txtquanremain";
            this.txtquanremain.Size = new System.Drawing.Size(214, 27);
            this.txtquanremain.TabIndex = 6;
            this.txtquanremain.Tag = "1";
            this.txtquanremain.ValidationStyle.AcceptsTab = true;
            this.txtquanremain.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtquanremain.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtquanremain.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtquanremain.ValidationStyle.PasswordChar = '\0';
            this.txtquanremain.ValidationStyle.ReadOnly = true;
            this.txtquanremain.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtquanremain.Value = 0;
            this.txtquanremain.TextChanged += new System.EventHandler(this.txtquanremain_TextChanged);
            this.txtquanremain.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantake_KeyPress);
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel2.Controls.Add(this.detailDataGrid);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel2.Location = new System.Drawing.Point(8, 220);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel2.Size = new System.Drawing.Size(592, 211);
            this.elRichPanel2.TabIndex = 1;
            this.elRichPanel2.Tag = "0";
            // 
            // detailDataGrid
            // 
            this.detailDataGrid.AllowUserToDeleteRows = false;
            this.detailDataGrid.AllowUserToResizeColumns = false;
            this.detailDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.detailDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.detailDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.detailDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.detailDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.detailDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.detailDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.detailDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.detailDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.accid,
            this.quandate,
            this.quannote,
            this.quantake,
            this.quansettle,
            this.quanremain});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.detailDataGrid.DefaultCellStyle = dataGridViewCellStyle6;
            this.detailDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.detailDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.detailDataGrid.Location = new System.Drawing.Point(1, 16);
            this.detailDataGrid.MultiSelect = false;
            this.detailDataGrid.Name = "detailDataGrid";
            this.detailDataGrid.ReadOnly = true;
            this.detailDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.detailDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.detailDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.detailDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.detailDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.detailDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.detailDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.detailDataGrid.ShowCellErrors = false;
            this.detailDataGrid.ShowCellToolTips = false;
            this.detailDataGrid.ShowEditingIcon = false;
            this.detailDataGrid.ShowRowErrors = false;
            this.detailDataGrid.Size = new System.Drawing.Size(590, 179);
            this.detailDataGrid.TabIndex = 0;
            this.detailDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.detailDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.detailDataGrid_MouseClick);
            this.detailDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.detailDataGrid_KeyDown);
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            this.accid.Visible = false;
            // 
            // quandate
            // 
            this.quandate.DataPropertyName = "quandate";
            this.quandate.HeaderText = "تاریخ";
            this.quandate.Name = "quandate";
            this.quandate.ReadOnly = true;
            // 
            // quannote
            // 
            this.quannote.DataPropertyName = "quannote";
            this.quannote.HeaderText = "شرح";
            this.quannote.Name = "quannote";
            this.quannote.ReadOnly = true;
            // 
            // quantake
            // 
            this.quantake.DataPropertyName = "quantake";
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = null;
            this.quantake.DefaultCellStyle = dataGridViewCellStyle3;
            this.quantake.HeaderText = "برداشت";
            this.quantake.Name = "quantake";
            this.quantake.ReadOnly = true;
            // 
            // quansettle
            // 
            this.quansettle.DataPropertyName = "quansettle";
            dataGridViewCellStyle4.Format = "C0";
            dataGridViewCellStyle4.NullValue = null;
            this.quansettle.DefaultCellStyle = dataGridViewCellStyle4;
            this.quansettle.HeaderText = "واریز";
            this.quansettle.Name = "quansettle";
            this.quansettle.ReadOnly = true;
            // 
            // quanremain
            // 
            this.quanremain.DataPropertyName = "quanremain";
            dataGridViewCellStyle5.Format = "C0";
            dataGridViewCellStyle5.NullValue = null;
            this.quanremain.DefaultCellStyle = dataGridViewCellStyle5;
            this.quanremain.HeaderText = "باقیمانده";
            this.quanremain.Name = "quanremain";
            this.quanremain.ReadOnly = true;
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(11, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(88, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(164, 7);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // elContainer3
            // 
            this.elContainer3.Controls.Add(this.elButton6);
            this.elContainer3.Controls.Add(this.btnClose);
            this.elContainer3.Controls.Add(this.elButton8);
            this.elContainer3.Controls.Add(this.btnNew);
            this.elContainer3.Controls.Add(this.btnSave);
            this.elContainer3.Location = new System.Drawing.Point(8, 437);
            this.elContainer3.Name = "elContainer3";
            this.elContainer3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer3.Size = new System.Drawing.Size(243, 41);
            this.elContainer3.TabIndex = 2;
            this.elContainer3.Tag = "0";
            this.elContainer3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elButton6
            // 
            this.elButton6.Location = new System.Drawing.Point(0, 0);
            this.elButton6.Name = "elButton6";
            this.elButton6.Size = new System.Drawing.Size(0, 0);
            this.elButton6.TabIndex = 5;
            // 
            // elButton8
            // 
            this.elButton8.Location = new System.Drawing.Point(0, 0);
            this.elButton8.Name = "elButton8";
            this.elButton8.Size = new System.Drawing.Size(0, 0);
            this.elButton8.TabIndex = 5;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(8, 7, 592, 210);
            this.expandPanel.Location = new System.Drawing.Point(8, 7);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(592, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 4;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.rdoremainS);
            this.BackSearch.Controls.Add(this.rdotakeS);
            this.BackSearch.Controls.Add(this.rdosettleS);
            this.BackSearch.Controls.Add(this.txtnoteS);
            this.BackSearch.Controls.Add(this.txtmaxMoney);
            this.BackSearch.Controls.Add(this.txtminMoney);
            this.BackSearch.Controls.Add(this.txtstartdate);
            this.BackSearch.Controls.Add(this.txtenddate);
            this.BackSearch.Location = new System.Drawing.Point(9, 32);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(574, 139);
            this.BackSearch.TabIndex = 9;
            // 
            // rdoremainS
            // 
            this.rdoremainS.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoremainS.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoremainS.Location = new System.Drawing.Point(108, 12);
            this.rdoremainS.Name = "rdoremainS";
            this.rdoremainS.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoremainS.Size = new System.Drawing.Size(104, 27);
            this.rdoremainS.TabIndex = 2;
            this.rdoremainS.Tag = "0";
            this.rdoremainS.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoremainS.TextStyle.Text = "مبالغ باقیمانده";
            this.rdoremainS.Value = false;
            // 
            // rdotakeS
            // 
            this.rdotakeS.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdotakeS.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdotakeS.Location = new System.Drawing.Point(362, 12);
            this.rdotakeS.Name = "rdotakeS";
            this.rdotakeS.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdotakeS.Size = new System.Drawing.Size(104, 27);
            this.rdotakeS.TabIndex = 0;
            this.rdotakeS.Tag = "0";
            this.rdotakeS.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdotakeS.TextStyle.Text = "مبالغ برداشتی";
            this.rdotakeS.Value = false;
            // 
            // rdosettleS
            // 
            this.rdosettleS.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdosettleS.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdosettleS.Location = new System.Drawing.Point(234, 12);
            this.rdosettleS.Name = "rdosettleS";
            this.rdosettleS.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdosettleS.Size = new System.Drawing.Size(104, 27);
            this.rdosettleS.TabIndex = 1;
            this.rdosettleS.Tag = "0";
            this.rdosettleS.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdosettleS.TextStyle.Text = "مبالغ واریزی";
            this.rdosettleS.Value = false;
            // 
            // txtnoteS
            // 
            this.txtnoteS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtnoteS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtnoteS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtnoteS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoteS.CaptionStyle.TextStyle.Text = "شرح تراکنش";
            this.txtnoteS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoteS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtnoteS.Location = new System.Drawing.Point(10, 45);
            this.txtnoteS.Name = "txtnoteS";
            this.txtnoteS.Size = new System.Drawing.Size(554, 27);
            this.txtnoteS.TabIndex = 3;
            this.txtnoteS.Tag = "0";
            this.txtnoteS.ValidationStyle.AcceptsTab = true;
            this.txtnoteS.ValidationStyle.PasswordChar = '\0';
            this.txtnoteS.Value = "";
            this.txtnoteS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtmaxMoney
            // 
            this.txtmaxMoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmaxMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmaxMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmaxMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmaxMoney.CaptionStyle.TextStyle.Text = "حداکثر مبلغ";
            this.txtmaxMoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaxMoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmaxMoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtmaxMoney.Location = new System.Drawing.Point(10, 74);
            this.txtmaxMoney.Name = "txtmaxMoney";
            this.txtmaxMoney.Size = new System.Drawing.Size(244, 27);
            this.txtmaxMoney.TabIndex = 5;
            this.txtmaxMoney.Tag = "1";
            this.txtmaxMoney.ValidationStyle.AcceptsTab = true;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtmaxMoney.ValidationStyle.PasswordChar = '\0';
            this.txtmaxMoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtmaxMoney.Value = 0;
            this.txtmaxMoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantake_KeyPress);
            // 
            // txtminMoney
            // 
            this.txtminMoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtminMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtminMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtminMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtminMoney.CaptionStyle.TextStyle.Text = "حداقل مبلغ";
            this.txtminMoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtminMoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtminMoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtminMoney.Location = new System.Drawing.Point(320, 74);
            this.txtminMoney.Name = "txtminMoney";
            this.txtminMoney.Size = new System.Drawing.Size(244, 27);
            this.txtminMoney.TabIndex = 4;
            this.txtminMoney.Tag = "1";
            this.txtminMoney.ValidationStyle.AcceptsTab = true;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtminMoney.ValidationStyle.PasswordChar = '\0';
            this.txtminMoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtminMoney.Value = 0;
            this.txtminMoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtquantake_KeyPress);
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(386, 103);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(178, 27);
            this.txtstartdate.TabIndex = 6;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(76, 103);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(178, 27);
            this.txtenddate.TabIndex = 7;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(84, 176);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 0;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(9, 176);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 1;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmOptbank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 486);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elRichPanel2);
            this.Controls.Add(this.elContainer3);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmOptbank";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "تراکنشهای بانکی";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmOptbank_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoSettle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoTake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRemain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSettle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquandate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtquantake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquannote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquansettle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquanremain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.detailDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).EndInit();
            this.elContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdoremainS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdotakeS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdosettleS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnoteS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaxMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtminMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView detailDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquandate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquantake;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquannote;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquansettle;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquanremain;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer3;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton6;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton8;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblRemain;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblSettle;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblTake;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoSettle;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoTake;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewTextBoxColumn quandate;
        private System.Windows.Forms.DataGridViewTextBoxColumn quannote;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantake;
        private System.Windows.Forms.DataGridViewTextBoxColumn quansettle;
        private System.Windows.Forms.DataGridViewTextBoxColumn quanremain;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmaxMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtminMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtnoteS;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoremainS;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdotakeS;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdosettleS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton3;
    }
}