﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace FamilyAccount
{
    public partial class FrmSetting : Form
    {
        RegistryKey key;
        public FrmSetting()
        {
            InitializeComponent();
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
        }

        public static FrmSetting Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmSetting();
            }
            return aForm;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //Startup
            if (Startup.Checked == true)
                key.SetValue("Family Accounting", Application.ExecutablePath);
            else
                key.DeleteValue("Family Accounting", false);

            //Show Login
            if (ShowLogin.Checked)
                Properties.Settings.Default.ShowLogin = true;
            else
                Properties.Settings.Default.ShowLogin = false;

            //Time Event
            Properties.Settings.Default.EventTime = int.Parse(txteventTime.Text);

            Properties.Settings.Default.Save();
            this.Close();
        }

        private void FrmSetting_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ShowLogin) ShowLogin.Checked = true;
            if (key.GetValue("Family Accounting") != null)
                Startup.Checked = true;
            txteventTime.Text = Properties.Settings.Default.EventTime.ToString();
        }
    }
}
