﻿namespace FamilyAccount
{
    partial class FrmLoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmLoan aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles5 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem15 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem16 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem17 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem18 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem19 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem10 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem11 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem8 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem9 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem12 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem13 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem14 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLoan));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.grpAghsat = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.txtspace = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpayfirstquan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpaynum = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton5 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtpayothquan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpaydate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton6 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.grpRas = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.txtloantime = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton4 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtloanbackdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton3 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.lblLoanquan = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.cboloantype = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtloannote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtloandate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.cboloanbacktype = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtloanback = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtloanquan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtloanrate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.loanDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.loanid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.familyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loandate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loantype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanrate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanback = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanbacktype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loantime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanbackdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loannote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payfirstquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payothquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paynum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mspace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paydate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSponser = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnPayment = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.familyTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter();
            this.backtype = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.grpDate = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.rdodateL = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.rdobackL = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.grpMoney = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.txtminMoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmaxMoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.rdoquanback = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdoloanquan = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.txtaccidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtloanrateS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmemidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cbobacktypeS = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.cboloantypeS = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpAghsat)).BeginInit();
            this.grpAghsat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpayfirstquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpaynum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpayothquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpaydate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpRas)).BeginInit();
            this.grpRas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtloantime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanbackdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLoanquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloantype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloannote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloandate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloanbacktype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanrate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSponser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnPayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backtype)).BeginInit();
            this.backtype.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpDate)).BeginInit();
            this.grpDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdodateL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdobackL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpMoney)).BeginInit();
            this.grpMoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtminMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaxMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoquanback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoloanquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanrateS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbobacktypeS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloantypeS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // grpAghsat
            // 
            this.grpAghsat.BackgroundStyle.GradientAngle = 45F;
            this.grpAghsat.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpAghsat.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpAghsat.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.grpAghsat.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpAghsat.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpAghsat.CaptionStyle.PositionIndent = new System.Drawing.Point(0, 0);
            this.grpAghsat.CaptionStyle.Size = new System.Drawing.Size(120, 20);
            this.grpAghsat.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpAghsat.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAghsat.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.grpAghsat.CaptionStyle.TextStyle.Text = "بازپرداخت اقساط";
            this.grpAghsat.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grpAghsat.Controls.Add(this.txtspace);
            this.grpAghsat.Controls.Add(this.txtpayfirstquan);
            this.grpAghsat.Controls.Add(this.txtpaynum);
            this.grpAghsat.Controls.Add(this.txtpayothquan);
            this.grpAghsat.Controls.Add(this.txtpaydate);
            this.grpAghsat.Enabled = false;
            this.grpAghsat.Location = new System.Drawing.Point(248, 5);
            this.grpAghsat.Name = "grpAghsat";
            this.grpAghsat.Padding = new System.Windows.Forms.Padding(4, 23, 4, 3);
            this.grpAghsat.Size = new System.Drawing.Size(502, 111);
            this.grpAghsat.TabIndex = 0;
            this.grpAghsat.Tag = "0";
            this.grpAghsat.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // txtspace
            // 
            this.txtspace.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtspace.CaptionStyle.CaptionSize = 110;
            this.txtspace.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtspace.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtspace.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtspace.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtspace.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtspace.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspace.CaptionStyle.TextStyle.Text = "(فاصله اقساط(ماه";
            this.txtspace.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspace.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtspace.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtspace.Location = new System.Drawing.Point(325, 78);
            this.txtspace.Name = "txtspace";
            this.txtspace.Size = new System.Drawing.Size(171, 27);
            this.txtspace.TabIndex = 4;
            this.txtspace.Tag = "0";
            this.txtspace.ValidationStyle.AcceptsTab = true;
            this.txtspace.ValidationStyle.NumericValidationStyle.Minimum = "1";
            this.txtspace.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtspace.ValidationStyle.PasswordChar = '\0';
            this.txtspace.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtspace.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtpayfirstquan
            // 
            this.txtpayfirstquan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpayfirstquan.CaptionStyle.CaptionSize = 110;
            this.txtpayfirstquan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpayfirstquan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpayfirstquan.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpayfirstquan.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayfirstquan.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayfirstquan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayfirstquan.CaptionStyle.TextStyle.Text = "مبلغ اولین قسط";
            this.txtpayfirstquan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayfirstquan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpayfirstquan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpayfirstquan.Location = new System.Drawing.Point(263, 24);
            this.txtpayfirstquan.Name = "txtpayfirstquan";
            this.txtpayfirstquan.Size = new System.Drawing.Size(233, 27);
            this.txtpayfirstquan.TabIndex = 0;
            this.txtpayfirstquan.Tag = "0";
            this.txtpayfirstquan.ValidationStyle.AcceptsTab = true;
            this.txtpayfirstquan.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtpayfirstquan.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtpayfirstquan.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtpayfirstquan.ValidationStyle.PasswordChar = '\0';
            this.txtpayfirstquan.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtpayfirstquan.Value = 0;
            this.txtpayfirstquan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtpaynum
            // 
            this.txtpaynum.ButtonStyle.Buttons.Add(this.elEntryBoxButton5);
            this.txtpaynum.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpaynum.CaptionStyle.CaptionSize = 120;
            this.txtpaynum.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpaynum.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpaynum.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpaynum.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpaynum.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpaynum.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaynum.CaptionStyle.TextStyle.Text = "تعداد اقساط";
            this.txtpaynum.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaynum.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpaynum.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtpaynum.Location = new System.Drawing.Point(61, 51);
            this.txtpaynum.Name = "txtpaynum";
            this.txtpaynum.Size = new System.Drawing.Size(180, 27);
            this.txtpaynum.TabIndex = 3;
            this.txtpaynum.Tag = "0";
            this.txtpaynum.ValidationStyle.AcceptsTab = true;
            this.txtpaynum.ValidationStyle.NumericValidationStyle.Minimum = "0";
            this.txtpaynum.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtpaynum.ValidationStyle.PasswordChar = '\0';
            this.txtpaynum.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtpaynum.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtpaynum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // elEntryBoxButton5
            // 
            this.elEntryBoxButton5.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton5.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.Spin;
            // 
            // txtpayothquan
            // 
            this.txtpayothquan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpayothquan.CaptionStyle.CaptionSize = 110;
            this.txtpayothquan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpayothquan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpayothquan.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpayothquan.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayothquan.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayothquan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayothquan.CaptionStyle.TextStyle.Text = "مبلغ هر قسط";
            this.txtpayothquan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayothquan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpayothquan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpayothquan.Location = new System.Drawing.Point(263, 51);
            this.txtpayothquan.Name = "txtpayothquan";
            this.txtpayothquan.Size = new System.Drawing.Size(233, 27);
            this.txtpayothquan.TabIndex = 2;
            this.txtpayothquan.Tag = "0";
            this.txtpayothquan.ValidationStyle.AcceptsTab = true;
            this.txtpayothquan.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtpayothquan.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtpayothquan.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtpayothquan.ValidationStyle.PasswordChar = '\0';
            this.txtpayothquan.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtpayothquan.Value = 0;
            this.txtpayothquan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtpaydate
            // 
            this.txtpaydate.ButtonStyle.Buttons.Add(this.elEntryBoxButton6);
            this.txtpaydate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpaydate.CaptionStyle.CaptionSize = 120;
            this.txtpaydate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpaydate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpaydate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpaydate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpaydate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpaydate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaydate.CaptionStyle.TextStyle.Text = "تاریخ اولین قسط";
            this.txtpaydate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaydate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpaydate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpaydate.Location = new System.Drawing.Point(12, 24);
            this.txtpaydate.Name = "txtpaydate";
            this.txtpaydate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtpaydate.Size = new System.Drawing.Size(229, 27);
            this.txtpaydate.TabIndex = 1;
            this.txtpaydate.Tag = "0";
            this.txtpaydate.ValidationStyle.AcceptsTab = true;
            this.txtpaydate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtpaydate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtpaydate.ValidationStyle.PasswordChar = '\0';
            this.txtpaydate.Value = "";
            this.txtpaydate.Leave += new System.EventHandler(this.txtpaydate_Leave);
            this.txtpaydate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // elEntryBoxButton6
            // 
            this.elEntryBoxButton6.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton6.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton6.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // grpRas
            // 
            this.grpRas.BackgroundStyle.GradientAngle = 45F;
            this.grpRas.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpRas.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpRas.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.grpRas.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpRas.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpRas.CaptionStyle.PositionIndent = new System.Drawing.Point(0, 0);
            this.grpRas.CaptionStyle.Size = new System.Drawing.Size(120, 20);
            this.grpRas.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpRas.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRas.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.grpRas.CaptionStyle.TextStyle.Text = "بازپرداخت راس مدت";
            this.grpRas.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grpRas.Controls.Add(this.txtloantime);
            this.grpRas.Controls.Add(this.txtloanbackdate);
            this.grpRas.Enabled = false;
            this.grpRas.Location = new System.Drawing.Point(9, 5);
            this.grpRas.Name = "grpRas";
            this.grpRas.Padding = new System.Windows.Forms.Padding(4, 23, 4, 3);
            this.grpRas.Size = new System.Drawing.Size(235, 111);
            this.grpRas.TabIndex = 1;
            this.grpRas.Tag = "0";
            this.grpRas.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // txtloantime
            // 
            this.txtloantime.ButtonStyle.Buttons.Add(this.elEntryBoxButton4);
            this.txtloantime.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloantime.CaptionStyle.CaptionSize = 120;
            this.txtloantime.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloantime.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloantime.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloantime.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloantime.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloantime.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloantime.CaptionStyle.TextStyle.Text = "(مدت باز پرداخت(ماه";
            this.txtloantime.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloantime.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloantime.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtloantime.Location = new System.Drawing.Point(54, 24);
            this.txtloantime.Name = "txtloantime";
            this.txtloantime.Size = new System.Drawing.Size(174, 27);
            this.txtloantime.TabIndex = 0;
            this.txtloantime.Tag = "0";
            this.txtloantime.ValidationStyle.AcceptsTab = true;
            this.txtloantime.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtloantime.ValidationStyle.NumericValidationStyle.Minimum = "0";
            this.txtloantime.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtloantime.ValidationStyle.PasswordChar = '\0';
            this.txtloantime.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloantime.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtloantime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // elEntryBoxButton4
            // 
            this.elEntryBoxButton4.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton4.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.Spin;
            // 
            // txtloanbackdate
            // 
            this.txtloanbackdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton3);
            this.txtloanbackdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanbackdate.CaptionStyle.CaptionSize = 120;
            this.txtloanbackdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanbackdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanbackdate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanbackdate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanbackdate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanbackdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanbackdate.CaptionStyle.TextStyle.Text = "تاریخ بازپرداخت";
            this.txtloanbackdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanbackdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanbackdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanbackdate.Location = new System.Drawing.Point(6, 51);
            this.txtloanbackdate.Name = "txtloanbackdate";
            this.txtloanbackdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtloanbackdate.Size = new System.Drawing.Size(222, 27);
            this.txtloanbackdate.TabIndex = 1;
            this.txtloanbackdate.Tag = "0";
            this.txtloanbackdate.ValidationStyle.AcceptsTab = true;
            this.txtloanbackdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtloanbackdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtloanbackdate.ValidationStyle.PasswordChar = '\0';
            this.txtloanbackdate.Value = "";
            this.txtloanbackdate.Leave += new System.EventHandler(this.txtloanbackdate_Leave);
            this.txtloanbackdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // elEntryBoxButton3
            // 
            this.elEntryBoxButton3.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton3.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton3.DropDownContextMenuStrip = this.contextDate;
            // 
            // txtmemid
            // 
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemid.CaptionStyle.CaptionSize = 125;
            this.txtmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemid.CaptionStyle.TextStyle.Text = "دریافت کننده تسهیلات";
            this.txtmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemid.Location = new System.Drawing.Point(37, 7);
            this.txtmemid.Name = "txtmemid";
            this.txtmemid.Size = new System.Drawing.Size(713, 27);
            this.txtmemid.TabIndex = 0;
            this.txtmemid.Tag = "1";
            this.txtmemid.ValidationStyle.AcceptsTab = true;
            this.txtmemid.ValidationStyle.PasswordChar = '\0';
            this.txtmemid.ValidationStyle.ReadOnly = true;
            this.txtmemid.Value = "";
            this.txtmemid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            this.txtmemid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // lblLoanquan
            // 
            this.lblLoanquan.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.FlashStyle = paintStyle2;
            this.lblLoanquan.Location = new System.Drawing.Point(168, 92);
            this.lblLoanquan.Name = "lblLoanquan";
            this.lblLoanquan.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblLoanquan.Size = new System.Drawing.Size(582, 23);
            this.lblLoanquan.TabIndex = 13;
            this.lblLoanquan.TabStop = false;
            this.lblLoanquan.Tag = "0";
            this.lblLoanquan.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoanquan.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblLoanquan.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblLoanquan.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // cboloantype
            // 
            // 
            // 
            // 
            this.cboloantype.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cboloantype.CaptionStyle.CaptionSize = 120;
            this.cboloantype.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloantype.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cboloantype.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloantype.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboloantype.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloantype.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloantype.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloantype.CaptionStyle.TextStyle.Text = "نوع تسهیلات";
            this.cboloantype.CheckedDisplaySeparator = ',';
            this.cboloantype.Cursor = System.Windows.Forms.Cursors.Default;
            this.cboloantype.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloantype.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cboloantype.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloantype.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cboloantype.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles5.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles5.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cboloantype.DropDownItemSelectionStyle = elListBoxSelectionStyles5;
            this.cboloantype.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cboloantype.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloantype.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cboloantype.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantype.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem15.Key = "0";
            elListBoxItem15.Value = "جعاله";
            elListBoxItem16.Key = "1";
            elListBoxItem16.Value = "کشاورزی";
            elListBoxItem17.Key = "2";
            elListBoxItem17.Value = "مضاربه";
            elListBoxItem18.Key = "3";
            elListBoxItem18.Value = "خودرو";
            elListBoxItem19.Key = "4";
            elListBoxItem19.Value = "مسکن";
            this.cboloantype.Items.Add(elListBoxItem15);
            this.cboloantype.Items.Add(elListBoxItem16);
            this.cboloantype.Items.Add(elListBoxItem17);
            this.cboloantype.Items.Add(elListBoxItem18);
            this.cboloantype.Items.Add(elListBoxItem19);
            this.cboloantype.Location = new System.Drawing.Point(168, 35);
            this.cboloantype.Name = "cboloantype";
            this.cboloantype.Size = new System.Drawing.Size(235, 27);
            this.cboloantype.TabIndex = 3;
            this.cboloantype.Tag = "0";
            this.cboloantype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtloannote
            // 
            this.txtloannote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloannote.CaptionStyle.CaptionSize = 130;
            this.txtloannote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloannote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloannote.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloannote.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloannote.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloannote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloannote.CaptionStyle.TextStyle.Text = "شرح تسهیلات";
            this.txtloannote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloannote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloannote.Location = new System.Drawing.Point(8, 146);
            this.txtloannote.Name = "txtloannote";
            this.txtloannote.Size = new System.Drawing.Size(742, 27);
            this.txtloannote.TabIndex = 8;
            this.txtloannote.Tag = "0";
            this.txtloannote.ValidationStyle.AcceptsTab = true;
            this.txtloannote.ValidationStyle.PasswordChar = '\0';
            this.txtloannote.Value = "";
            this.txtloannote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtloandate
            // 
            this.txtloandate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtloandate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloandate.CaptionStyle.CaptionSize = 130;
            this.txtloandate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloandate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloandate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloandate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloandate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloandate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloandate.CaptionStyle.TextStyle.Text = "تاریخ دریافت تسهیلات";
            this.txtloandate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloandate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloandate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloandate.Location = new System.Drawing.Point(519, 36);
            this.txtloandate.Name = "txtloandate";
            this.txtloandate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtloandate.Size = new System.Drawing.Size(231, 27);
            this.txtloandate.TabIndex = 2;
            this.txtloandate.Tag = "1";
            this.txtloandate.ValidationStyle.AcceptsTab = true;
            this.txtloandate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtloandate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtloandate.ValidationStyle.PasswordChar = '\0';
            this.txtloandate.Value = "";
            this.txtloandate.Leave += new System.EventHandler(this.txtloandate_Leave);
            this.txtloandate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // cboloanbacktype
            // 
            // 
            // 
            // 
            this.cboloanbacktype.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cboloanbacktype.CaptionStyle.CaptionSize = 120;
            this.cboloanbacktype.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloanbacktype.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cboloanbacktype.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloanbacktype.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboloanbacktype.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloanbacktype.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloanbacktype.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloanbacktype.CaptionStyle.TextStyle.Text = "نوع بازپرداخت";
            this.cboloanbacktype.CheckedDisplaySeparator = ',';
            this.cboloanbacktype.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloanbacktype.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cboloanbacktype.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloanbacktype.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cboloanbacktype.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles4.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles4.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cboloanbacktype.DropDownItemSelectionStyle = elListBoxSelectionStyles4;
            this.cboloanbacktype.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cboloanbacktype.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloanbacktype.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cboloanbacktype.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloanbacktype.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem10.Key = ((byte)(0));
            elListBoxItem10.Value = "راس مدت";
            elListBoxItem11.Key = ((byte)(1));
            elListBoxItem11.Value = "اقساط";
            this.cboloanbacktype.Items.Add(elListBoxItem10);
            this.cboloanbacktype.Items.Add(elListBoxItem11);
            this.cboloanbacktype.Location = new System.Drawing.Point(168, 117);
            this.cboloanbacktype.Name = "cboloanbacktype";
            this.cboloanbacktype.Size = new System.Drawing.Size(235, 27);
            this.cboloanbacktype.TabIndex = 7;
            this.cboloanbacktype.Tag = "1";
            this.cboloanbacktype.SelectedIndexChanged += new System.EventHandler(this.cboloanbacktype_SelectedIndexChanged);
            this.cboloanbacktype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtloanback
            // 
            this.txtloanback.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanback.CaptionStyle.CaptionSize = 130;
            this.txtloanback.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanback.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanback.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanback.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanback.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanback.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanback.CaptionStyle.TextStyle.Text = "مبلغ بازپرداخت";
            this.txtloanback.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanback.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanback.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanback.Location = new System.Drawing.Point(476, 117);
            this.txtloanback.Name = "txtloanback";
            this.txtloanback.Size = new System.Drawing.Size(274, 27);
            this.txtloanback.TabIndex = 6;
            this.txtloanback.Tag = "1";
            this.txtloanback.ValidationStyle.AcceptsTab = true;
            this.txtloanback.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanback.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtloanback.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanback.ValidationStyle.PasswordChar = '\0';
            this.txtloanback.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanback.Value = 0;
            this.txtloanback.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanquan_KeyPress);
            // 
            // txtloanquan
            // 
            this.txtloanquan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanquan.CaptionStyle.CaptionSize = 130;
            this.txtloanquan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanquan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanquan.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanquan.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanquan.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanquan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanquan.CaptionStyle.TextStyle.Text = "مبلغ تسهیلات";
            this.txtloanquan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanquan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanquan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanquan.Location = new System.Drawing.Point(476, 65);
            this.txtloanquan.Name = "txtloanquan";
            this.txtloanquan.Size = new System.Drawing.Size(274, 27);
            this.txtloanquan.TabIndex = 4;
            this.txtloanquan.Tag = "1";
            this.txtloanquan.ValidationStyle.AcceptsTab = true;
            this.txtloanquan.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanquan.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtloanquan.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanquan.ValidationStyle.PasswordChar = '\0';
            this.txtloanquan.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanquan.Value = 0;
            this.txtloanquan.TextChanged += new System.EventHandler(this.txtloanquan_TextChanged);
            this.txtloanquan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanquan_KeyPress);
            // 
            // txtloanrate
            // 
            this.txtloanrate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanrate.CaptionStyle.CaptionSize = 120;
            this.txtloanrate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanrate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanrate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanrate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanrate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanrate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanrate.CaptionStyle.TextStyle.Text = "نرخ سود تسهیلات";
            this.txtloanrate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanrate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanrate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanrate.Location = new System.Drawing.Point(220, 64);
            this.txtloanrate.Name = "txtloanrate";
            this.txtloanrate.Size = new System.Drawing.Size(183, 27);
            this.txtloanrate.TabIndex = 5;
            this.txtloanrate.Tag = "1";
            this.txtloanrate.ValidationStyle.AcceptsTab = true;
            this.txtloanrate.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtloanrate.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanrate.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Percent;
            this.txtloanrate.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanrate.ValidationStyle.PasswordChar = '\0';
            this.txtloanrate.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanrate.Value = 0;
            this.txtloanrate.TextChanged += new System.EventHandler(this.txtloanquan_TextChanged);
            this.txtloanrate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanrate_KeyPress);
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(141, 562);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 3;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image10")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // loanDataGrid
            // 
            this.loanDataGrid.AllowUserToAddRows = false;
            this.loanDataGrid.AllowUserToDeleteRows = false;
            this.loanDataGrid.AllowUserToResizeColumns = false;
            this.loanDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.loanDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.loanDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.loanDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.loanDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.loanDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.loanDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.loanDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.loanDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.loanid,
            this.memid,
            this.accid,
            this.loandate,
            this.loantype,
            this.loanquan,
            this.loanrate,
            this.loanback,
            this.loanbacktype,
            this.loantime,
            this.loanbackdate,
            this.loannote,
            this.payfirstquan,
            this.payothquan,
            this.paynum,
            this.mspace,
            this.paydate});
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.loanDataGrid.DefaultCellStyle = dataGridViewCellStyle16;
            this.loanDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loanDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.loanDataGrid.Location = new System.Drawing.Point(1, 16);
            this.loanDataGrid.MultiSelect = false;
            this.loanDataGrid.Name = "loanDataGrid";
            this.loanDataGrid.ReadOnly = true;
            this.loanDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.loanDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.loanDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.loanDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.loanDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.loanDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.loanDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.loanDataGrid.ShowCellErrors = false;
            this.loanDataGrid.ShowCellToolTips = false;
            this.loanDataGrid.ShowEditingIcon = false;
            this.loanDataGrid.ShowRowErrors = false;
            this.loanDataGrid.Size = new System.Drawing.Size(757, 186);
            this.loanDataGrid.TabIndex = 5;
            this.loanDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.loanDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.loanDataGrid_MouseClick);
            this.loanDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.loanDataGrid_CellClick);
            this.loanDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.loanDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.FillWeight = 69.0842F;
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // loanid
            // 
            this.loanid.DataPropertyName = "loanid";
            this.loanid.FillWeight = 25F;
            this.loanid.HeaderText = "کد";
            this.loanid.Name = "loanid";
            this.loanid.ReadOnly = true;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.DataSource = this.familyBindingSource;
            this.memid.DisplayMember = "name";
            this.memid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.memid.FillWeight = 69.0842F;
            this.memid.HeaderText = "دریافت کننده";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.memid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.memid.ValueMember = "memid";
            // 
            // familyBindingSource
            // 
            this.familyBindingSource.DataMember = "family";
            this.familyBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.FillWeight = 69.0842F;
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            // 
            // loandate
            // 
            this.loandate.DataPropertyName = "loandate";
            this.loandate.FillWeight = 69.0842F;
            this.loandate.HeaderText = "تاریخ دریافت";
            this.loandate.Name = "loandate";
            this.loandate.ReadOnly = true;
            // 
            // loantype
            // 
            this.loantype.DataPropertyName = "loantype";
            this.loantype.HeaderText = "نوع تسهیلات";
            this.loantype.Name = "loantype";
            this.loantype.ReadOnly = true;
            this.loantype.Visible = false;
            // 
            // loanquan
            // 
            this.loanquan.DataPropertyName = "loanquan";
            dataGridViewCellStyle12.Format = "C0";
            dataGridViewCellStyle12.NullValue = null;
            this.loanquan.DefaultCellStyle = dataGridViewCellStyle12;
            this.loanquan.FillWeight = 69.0842F;
            this.loanquan.HeaderText = "مبلغ تسهیلات";
            this.loanquan.Name = "loanquan";
            this.loanquan.ReadOnly = true;
            // 
            // loanrate
            // 
            this.loanrate.DataPropertyName = "loanrate";
            this.loanrate.FillWeight = 25F;
            this.loanrate.HeaderText = "نرخ";
            this.loanrate.Name = "loanrate";
            this.loanrate.ReadOnly = true;
            // 
            // loanback
            // 
            this.loanback.DataPropertyName = "loanback";
            dataGridViewCellStyle13.Format = "C0";
            dataGridViewCellStyle13.NullValue = null;
            this.loanback.DefaultCellStyle = dataGridViewCellStyle13;
            this.loanback.FillWeight = 69.0842F;
            this.loanback.HeaderText = " مبلغ بازپرداخت";
            this.loanback.Name = "loanback";
            this.loanback.ReadOnly = true;
            // 
            // loanbacktype
            // 
            this.loanbacktype.DataPropertyName = "loanbacktype";
            this.loanbacktype.FillWeight = 69.0842F;
            this.loanbacktype.HeaderText = "نوع بازپرداخت";
            this.loanbacktype.Name = "loanbacktype";
            this.loanbacktype.ReadOnly = true;
            // 
            // loantime
            // 
            this.loantime.DataPropertyName = "loantime";
            this.loantime.HeaderText = "مدت بازپرداخت";
            this.loantime.Name = "loantime";
            this.loantime.ReadOnly = true;
            this.loantime.Visible = false;
            // 
            // loanbackdate
            // 
            this.loanbackdate.DataPropertyName = "loanbackdate";
            this.loanbackdate.HeaderText = "تاریخ بازپرداخت";
            this.loanbackdate.Name = "loanbackdate";
            this.loanbackdate.ReadOnly = true;
            this.loanbackdate.Visible = false;
            // 
            // loannote
            // 
            this.loannote.DataPropertyName = "loannote";
            this.loannote.HeaderText = "شرح تسهیلات";
            this.loannote.Name = "loannote";
            this.loannote.ReadOnly = true;
            this.loannote.Visible = false;
            // 
            // payfirstquan
            // 
            this.payfirstquan.DataPropertyName = "payfirstquan";
            dataGridViewCellStyle14.Format = "C0";
            dataGridViewCellStyle14.NullValue = null;
            this.payfirstquan.DefaultCellStyle = dataGridViewCellStyle14;
            this.payfirstquan.HeaderText = "قسط اول/آخر";
            this.payfirstquan.Name = "payfirstquan";
            this.payfirstquan.ReadOnly = true;
            this.payfirstquan.Visible = false;
            // 
            // payothquan
            // 
            this.payothquan.DataPropertyName = "payothquan";
            dataGridViewCellStyle15.Format = "C0";
            dataGridViewCellStyle15.NullValue = null;
            this.payothquan.DefaultCellStyle = dataGridViewCellStyle15;
            this.payothquan.HeaderText = "مبلغ هر قسط";
            this.payothquan.Name = "payothquan";
            this.payothquan.ReadOnly = true;
            this.payothquan.Visible = false;
            // 
            // paynum
            // 
            this.paynum.DataPropertyName = "paynum";
            this.paynum.HeaderText = "تعداد قسط";
            this.paynum.Name = "paynum";
            this.paynum.ReadOnly = true;
            this.paynum.Visible = false;
            // 
            // mspace
            // 
            this.mspace.DataPropertyName = "mspace";
            this.mspace.HeaderText = "فاصله اقساط";
            this.mspace.Name = "mspace";
            this.mspace.ReadOnly = true;
            this.mspace.Visible = false;
            // 
            // paydate
            // 
            this.paydate.DataPropertyName = "paydate";
            this.paydate.HeaderText = "تاریخ اولین قسط";
            this.paydate.Name = "paydate";
            this.paydate.ReadOnly = true;
            this.paydate.Visible = false;
            // 
            // btnSponser
            // 
            this.btnSponser.BackgroundImageStyle.Alpha = 100;
            this.btnSponser.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnSponser.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSponser.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSponser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSponser.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSponser.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSponser.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSponser.Location = new System.Drawing.Point(8, 35);
            this.btnSponser.Name = "btnSponser";
            this.btnSponser.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnSponser.Size = new System.Drawing.Size(120, 27);
            this.btnSponser.TabIndex = 11;
            this.btnSponser.Tag = "0";
            this.btnSponser.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSponser.TextStyle.Text = "ضامن تسهیلات";
            this.btnSponser.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSponser.Click += new System.EventHandler(this.btnSponser_Click);
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(8, 7);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 1;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.btnSponser);
            this.backContainer.Controls.Add(this.btnPayment);
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtloanrate);
            this.backContainer.Controls.Add(this.txtloanquan);
            this.backContainer.Controls.Add(this.txtloanback);
            this.backContainer.Controls.Add(this.txtmemid);
            this.backContainer.Controls.Add(this.cboloanbacktype);
            this.backContainer.Controls.Add(this.txtloandate);
            this.backContainer.Controls.Add(this.lblLoanquan);
            this.backContainer.Controls.Add(this.txtloannote);
            this.backContainer.Controls.Add(this.cboloantype);
            this.backContainer.Location = new System.Drawing.Point(7, 34);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(759, 180);
            this.backContainer.TabIndex = 1;
            // 
            // btnPayment
            // 
            this.btnPayment.BackgroundImageStyle.Alpha = 100;
            this.btnPayment.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnPayment.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPayment.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPayment.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnPayment.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnPayment.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnPayment.Location = new System.Drawing.Point(8, 64);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnPayment.Size = new System.Drawing.Size(120, 27);
            this.btnPayment.TabIndex = 12;
            this.btnPayment.Tag = "0";
            this.btnPayment.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.TextStyle.Text = "اقساط تسهیلات";
            this.btnPayment.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // familyTableAdapter
            // 
            this.familyTableAdapter.ClearBeforeFill = true;
            // 
            // backtype
            // 
            this.backtype.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backtype.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backtype.Controls.Add(this.grpRas);
            this.backtype.Controls.Add(this.grpAghsat);
            this.backtype.Location = new System.Drawing.Point(7, 213);
            this.backtype.Name = "backtype";
            this.backtype.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backtype.Size = new System.Drawing.Size(759, 122);
            this.backtype.TabIndex = 2;
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel2.Controls.Add(this.loanDataGrid);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel2.Location = new System.Drawing.Point(7, 338);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel2.Size = new System.Drawing.Size(759, 218);
            this.elRichPanel2.TabIndex = 4;
            this.elRichPanel2.Tag = "0";
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(7, 8, 759, 327);
            this.expandPanel.Location = new System.Drawing.Point(7, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(759, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 5;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.grpDate);
            this.BackSearch.Controls.Add(this.grpMoney);
            this.BackSearch.Controls.Add(this.txtaccidS);
            this.BackSearch.Controls.Add(this.txtloanrateS);
            this.BackSearch.Controls.Add(this.txtmemidS);
            this.BackSearch.Controls.Add(this.cbobacktypeS);
            this.BackSearch.Controls.Add(this.cboloantypeS);
            this.BackSearch.Location = new System.Drawing.Point(9, 32);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(742, 256);
            this.BackSearch.TabIndex = 9;
            // 
            // grpDate
            // 
            this.grpDate.BackgroundStyle.GradientAngle = 45F;
            this.grpDate.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpDate.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpDate.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.grpDate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpDate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpDate.CaptionStyle.PositionIndent = new System.Drawing.Point(0, 0);
            this.grpDate.CaptionStyle.Size = new System.Drawing.Size(120, 20);
            this.grpDate.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpDate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDate.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.grpDate.CaptionStyle.TextStyle.Text = "تاریخ تسهیلات";
            this.grpDate.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grpDate.Controls.Add(this.rdodateL);
            this.grpDate.Controls.Add(this.txtenddate);
            this.grpDate.Controls.Add(this.txtstartdate);
            this.grpDate.Controls.Add(this.rdobackL);
            this.grpDate.Location = new System.Drawing.Point(8, 95);
            this.grpDate.Name = "grpDate";
            this.grpDate.Padding = new System.Windows.Forms.Padding(4, 23, 4, 3);
            this.grpDate.Size = new System.Drawing.Size(306, 90);
            this.grpDate.TabIndex = 6;
            this.grpDate.Tag = "0";
            this.grpDate.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // rdodateL
            // 
            this.rdodateL.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdodateL.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdodateL.Location = new System.Drawing.Point(193, 26);
            this.rdodateL.Name = "rdodateL";
            this.rdodateL.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdodateL.Size = new System.Drawing.Size(104, 27);
            this.rdodateL.TabIndex = 0;
            this.rdodateL.Tag = "0";
            this.rdodateL.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdodateL.TextStyle.Text = "تاریخ دریافت";
            this.rdodateL.Value = false;
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(9, 54);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(178, 27);
            this.txtenddate.TabIndex = 3;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtstartdate
            // 
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(9, 26);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(178, 27);
            this.txtstartdate.TabIndex = 2;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // rdobackL
            // 
            this.rdobackL.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdobackL.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdobackL.Location = new System.Drawing.Point(193, 54);
            this.rdobackL.Name = "rdobackL";
            this.rdobackL.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdobackL.Size = new System.Drawing.Size(104, 27);
            this.rdobackL.TabIndex = 1;
            this.rdobackL.Tag = "0";
            this.rdobackL.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobackL.TextStyle.Text = "تاریخ بازپرداخت";
            this.rdobackL.Value = false;
            // 
            // grpMoney
            // 
            this.grpMoney.BackgroundStyle.GradientAngle = 45F;
            this.grpMoney.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpMoney.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpMoney.CaptionStyle.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.grpMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpMoney.CaptionStyle.PositionIndent = new System.Drawing.Point(0, 0);
            this.grpMoney.CaptionStyle.Size = new System.Drawing.Size(120, 20);
            this.grpMoney.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMoney.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.grpMoney.CaptionStyle.TextStyle.Text = "مبالغ تسهیلات";
            this.grpMoney.CaptionStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.grpMoney.Controls.Add(this.txtminMoney);
            this.grpMoney.Controls.Add(this.txtmaxMoney);
            this.grpMoney.Controls.Add(this.rdoquanback);
            this.grpMoney.Controls.Add(this.rdoloanquan);
            this.grpMoney.Location = new System.Drawing.Point(391, 95);
            this.grpMoney.Name = "grpMoney";
            this.grpMoney.Padding = new System.Windows.Forms.Padding(4, 23, 4, 3);
            this.grpMoney.Size = new System.Drawing.Size(343, 90);
            this.grpMoney.TabIndex = 5;
            this.grpMoney.Tag = "0";
            this.grpMoney.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // txtminMoney
            // 
            this.txtminMoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtminMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtminMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtminMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtminMoney.CaptionStyle.TextStyle.Text = "حداقل مبلغ";
            this.txtminMoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtminMoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtminMoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtminMoney.Location = new System.Drawing.Point(9, 26);
            this.txtminMoney.Name = "txtminMoney";
            this.txtminMoney.Size = new System.Drawing.Size(215, 27);
            this.txtminMoney.TabIndex = 2;
            this.txtminMoney.Tag = "1";
            this.txtminMoney.ValidationStyle.AcceptsTab = true;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtminMoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtminMoney.ValidationStyle.PasswordChar = '\0';
            this.txtminMoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtminMoney.Value = 0;
            this.txtminMoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanquan_KeyPress);
            // 
            // txtmaxMoney
            // 
            this.txtmaxMoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmaxMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmaxMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmaxMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmaxMoney.CaptionStyle.TextStyle.Text = "حداکثر مبلغ";
            this.txtmaxMoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaxMoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmaxMoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtmaxMoney.Location = new System.Drawing.Point(9, 54);
            this.txtmaxMoney.Name = "txtmaxMoney";
            this.txtmaxMoney.Size = new System.Drawing.Size(215, 27);
            this.txtmaxMoney.TabIndex = 3;
            this.txtmaxMoney.Tag = "1";
            this.txtmaxMoney.ValidationStyle.AcceptsTab = true;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtmaxMoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtmaxMoney.ValidationStyle.PasswordChar = '\0';
            this.txtmaxMoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtmaxMoney.Value = 0;
            this.txtmaxMoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanquan_KeyPress);
            // 
            // rdoquanback
            // 
            this.rdoquanback.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoquanback.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoquanback.Location = new System.Drawing.Point(230, 54);
            this.rdoquanback.Name = "rdoquanback";
            this.rdoquanback.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoquanback.Size = new System.Drawing.Size(104, 27);
            this.rdoquanback.TabIndex = 1;
            this.rdoquanback.Tag = "0";
            this.rdoquanback.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoquanback.TextStyle.Text = "مبلغ بازپرداخت";
            this.rdoquanback.Value = false;
            // 
            // rdoloanquan
            // 
            this.rdoloanquan.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoloanquan.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoloanquan.Location = new System.Drawing.Point(230, 26);
            this.rdoloanquan.Name = "rdoloanquan";
            this.rdoloanquan.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoloanquan.Size = new System.Drawing.Size(104, 27);
            this.rdoloanquan.TabIndex = 0;
            this.rdoloanquan.Tag = "0";
            this.rdoloanquan.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoloanquan.TextStyle.Text = "مبلغ تسهیلات";
            this.rdoloanquan.Value = false;
            // 
            // txtaccidS
            // 
            this.txtaccidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccidS.CaptionStyle.CaptionSize = 85;
            this.txtaccidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidS.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccidS.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtaccidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccidS.Location = new System.Drawing.Point(37, 34);
            this.txtaccidS.Name = "txtaccidS";
            this.txtaccidS.Size = new System.Drawing.Size(277, 27);
            this.txtaccidS.TabIndex = 2;
            this.txtaccidS.Tag = "1";
            this.txtaccidS.ValidationStyle.AcceptsTab = true;
            this.txtaccidS.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccidS.ValidationStyle.PasswordChar = '\0';
            this.txtaccidS.Value = "";
            this.txtaccidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtloanrateS
            // 
            this.txtloanrateS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtloanrateS.CaptionStyle.CaptionSize = 85;
            this.txtloanrateS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtloanrateS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtloanrateS.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanrateS.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanrateS.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtloanrateS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtloanrateS.CaptionStyle.TextStyle.Text = "نرخ تسهیلات";
            this.txtloanrateS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloanrateS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtloanrateS.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtloanrateS.Location = new System.Drawing.Point(159, 62);
            this.txtloanrateS.Name = "txtloanrateS";
            this.txtloanrateS.Size = new System.Drawing.Size(155, 27);
            this.txtloanrateS.TabIndex = 4;
            this.txtloanrateS.Tag = "1";
            this.txtloanrateS.ValidationStyle.AcceptsTab = true;
            this.txtloanrateS.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtloanrateS.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtloanrateS.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Percent;
            this.txtloanrateS.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtloanrateS.ValidationStyle.PasswordChar = '\0';
            this.txtloanrateS.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtloanrateS.Value = 0;
            this.txtloanrateS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // txtmemidS
            // 
            this.txtmemidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemidS.CaptionStyle.TextStyle.Text = "دریافت کننده";
            this.txtmemidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemidS.Location = new System.Drawing.Point(440, 34);
            this.txtmemidS.Name = "txtmemidS";
            this.txtmemidS.Size = new System.Drawing.Size(295, 27);
            this.txtmemidS.TabIndex = 1;
            this.txtmemidS.Tag = "1";
            this.txtmemidS.ValidationStyle.AcceptsTab = true;
            this.txtmemidS.ValidationStyle.PasswordChar = '\0';
            this.txtmemidS.Value = "";
            this.txtmemidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // cbobacktypeS
            // 
            // 
            // 
            // 
            this.cbobacktypeS.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbobacktypeS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbobacktypeS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbobacktypeS.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbobacktypeS.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbobacktypeS.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbobacktypeS.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbobacktypeS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbobacktypeS.CaptionStyle.TextStyle.Text = "نوع بازپرداخت";
            this.cbobacktypeS.CheckedDisplaySeparator = ',';
            this.cbobacktypeS.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbobacktypeS.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbobacktypeS.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbobacktypeS.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbobacktypeS.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles3.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles3.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbobacktypeS.DropDownItemSelectionStyle = elListBoxSelectionStyles3;
            this.cbobacktypeS.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbobacktypeS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbobacktypeS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbobacktypeS.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbobacktypeS.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem8.Key = ((byte)(0));
            elListBoxItem8.Value = "راس مدت";
            elListBoxItem9.Key = ((byte)(1));
            elListBoxItem9.Value = "اقساط";
            this.cbobacktypeS.Items.Add(elListBoxItem8);
            this.cbobacktypeS.Items.Add(elListBoxItem9);
            this.cbobacktypeS.Location = new System.Drawing.Point(557, 6);
            this.cbobacktypeS.Name = "cbobacktypeS";
            this.cbobacktypeS.Size = new System.Drawing.Size(178, 27);
            this.cbobacktypeS.TabIndex = 0;
            this.cbobacktypeS.Tag = "1";
            this.cbobacktypeS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // cboloantypeS
            // 
            // 
            // 
            // 
            this.cboloantypeS.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cboloantypeS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloantypeS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cboloantypeS.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloantypeS.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboloantypeS.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloantypeS.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboloantypeS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboloantypeS.CaptionStyle.TextStyle.Text = "نوع تسهیلات";
            this.cboloantypeS.CheckedDisplaySeparator = ',';
            this.cboloantypeS.Cursor = System.Windows.Forms.Cursors.Default;
            this.cboloantypeS.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cboloantypeS.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cboloantypeS.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboloantypeS.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cboloantypeS.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cboloantypeS.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cboloantypeS.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cboloantypeS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboloantypeS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cboloantypeS.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboloantypeS.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = "0";
            elListBoxItem1.Value = "جعاله";
            elListBoxItem2.Key = "1";
            elListBoxItem2.Value = "کشاورزی";
            elListBoxItem12.Key = "2";
            elListBoxItem12.Value = "مضاربه";
            elListBoxItem13.Key = "3";
            elListBoxItem13.Value = "خودرو";
            elListBoxItem14.Key = "4";
            elListBoxItem14.Value = "مسکن";
            this.cboloantypeS.Items.Add(elListBoxItem1);
            this.cboloantypeS.Items.Add(elListBoxItem2);
            this.cboloantypeS.Items.Add(elListBoxItem12);
            this.cboloantypeS.Items.Add(elListBoxItem13);
            this.cboloantypeS.Items.Add(elListBoxItem14);
            this.cboloantypeS.Location = new System.Drawing.Point(557, 62);
            this.cboloantypeS.Name = "cboloantypeS";
            this.cboloantypeS.Size = new System.Drawing.Size(178, 27);
            this.cboloantypeS.TabIndex = 3;
            this.cboloantypeS.Tag = "0";
            this.cboloantypeS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtloanid_KeyPress);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(85, 294);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 0;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(10, 294);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 1;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmLoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(773, 610);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.elRichPanel2);
            this.Controls.Add(this.backtype);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLoan";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "                      تسهیلات بانکی                                              " +
                "                                              محاسبه سود تسهیلات : F12";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmLoan_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmLoan_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpAghsat)).EndInit();
            this.grpAghsat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpayfirstquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpaynum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpayothquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpaydate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grpRas)).EndInit();
            this.grpRas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtloantime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanbackdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLoanquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloantype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloannote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloandate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloanbacktype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanrate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loanDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSponser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnPayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backtype)).EndInit();
            this.backtype.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grpDate)).EndInit();
            this.grpDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rdodateL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdobackL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpMoney)).EndInit();
            this.grpMoney.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtminMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaxMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoquanback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoloanquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtloanrateS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbobacktypeS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboloantypeS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloandate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanrate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanquan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloannote;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cboloanbacktype;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cboloantype;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanback;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpayfirstquan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpayothquan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpaydate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpaynum;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblLoanquan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnSponser;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView loanDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanbackdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloantime;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpRas;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpAghsat;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton6;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnPayment;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource familyBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter familyTableAdapter;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backtype;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtspace;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanid;
        private System.Windows.Forms.DataGridViewComboBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewTextBoxColumn loandate;
        private System.Windows.Forms.DataGridViewTextBoxColumn loantype;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanrate;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanback;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanbacktype;
        private System.Windows.Forms.DataGridViewTextBoxColumn loantime;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanbackdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn loannote;
        private System.Windows.Forms.DataGridViewTextBoxColumn payfirstquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn payothquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn paynum;
        private System.Windows.Forms.DataGridViewTextBoxColumn mspace;
        private System.Windows.Forms.DataGridViewTextBoxColumn paydate;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmaxMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtminMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtloanrateS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemidS;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbobacktypeS;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cboloantypeS;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdodateL;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdobackL;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoloanquan;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoquanback;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccidS;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpDate;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton4;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton5;
    }
}