﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmBanks : Form
    {
        string idSel = "";
        string selectedkeybbid = string.Empty;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmBanks()
        {
            InitializeComponent();
        }

        public static FrmBanks Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmBanks();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtbbid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into banks values(@bbid,@branchid,@branchname,@citycode,@tel,@fax,@telbank,@sms,@email,@site,@adres,@note)";
            cmd.Parameters.Add("@bbid", SqlDbType.Int).Value = selectedkeybbid;
            cmd.Parameters.Add("@branchid", SqlDbType.NVarChar).Value = txtbranchid.Text;
            cmd.Parameters.Add("@branchname", SqlDbType.NVarChar).Value = txtbranchname.Text;
            cmd.Parameters.Add("@citycode", SqlDbType.NVarChar).Value = txtcitycode.Text;
            cmd.Parameters.Add("@tel", SqlDbType.NVarChar).Value = txttel.Text;
            cmd.Parameters.Add("@fax", SqlDbType.NVarChar).Value = txtfax.Text;
            cmd.Parameters.Add("@telbank", SqlDbType.NVarChar).Value = txttelbank.Text;
            cmd.Parameters.Add("@sms", SqlDbType.NVarChar).Value = txtsms.Text;
            cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@site", SqlDbType.NVarChar).Value = txtsite.Text;
            cmd.Parameters.Add("@adres", SqlDbType.NText).Value = txtadres.Text;
            cmd.Parameters.Add("@note", SqlDbType.NText).Value = txtnote.Text;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update banks set bbid=@bbid,branchid=@branchid,branchname=@branchname,citycode=@citycode,tel=@tel,fax=@fax,telbank=@telbank,sms=@sms,email=@email,site=@site,adres=@adres,note=@note where bankid=@bankid";
            cmd.Parameters.Add("@bankid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@bbid", SqlDbType.Int).Value = selectedkeybbid;
            cmd.Parameters.Add("@branchid", SqlDbType.NVarChar).Value = txtbranchid.Text;
            cmd.Parameters.Add("@branchname", SqlDbType.NVarChar).Value = txtbranchname.Text;
            cmd.Parameters.Add("@citycode", SqlDbType.NVarChar).Value = txtcitycode.Text;
            cmd.Parameters.Add("@tel", SqlDbType.NVarChar).Value = txttel.Text;
            cmd.Parameters.Add("@fax", SqlDbType.NVarChar).Value = txtfax.Text;
            cmd.Parameters.Add("@telbank", SqlDbType.NVarChar).Value = txttelbank.Text;
            cmd.Parameters.Add("@sms", SqlDbType.NVarChar).Value = txtsms.Text;
            cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@site", SqlDbType.NVarChar).Value = txtsite.Text;
            cmd.Parameters.Add("@adres", SqlDbType.NText).Value = txtadres.Text;
            cmd.Parameters.Add("@note", SqlDbType.NText).Value = txtnote.Text;
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from banks where bankid=@bankid";
            cmd.Parameters.Add("@bankid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmBanks_Load(object sender, EventArgs e)
        {
            basebankTableAdapter.Fill(accountDataSet.basebank);
            GridRefresh(); 
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtbankid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void txtemail_Enter(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

        private void txtemail_Leave(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from banks");
            bankDataGrid.DataSource = ds.Tables[0];
        }

        private void bankDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bankDataGrid.RowCount > 0)
            {
                if (bankDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void SelectedData()
        {
            idSel = bankDataGrid["bankid", bankDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybbid = bankDataGrid["bbid", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtbbid.Text = bankDataGrid["bbid", bankDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtbranchid.Text = bankDataGrid["branchid", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtbranchname.Text = bankDataGrid["branchname", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtcitycode.Text = bankDataGrid["citycode", bankDataGrid.CurrentRow.Index].Value.ToString();
            txttel.Text = bankDataGrid["tel", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtfax.Text = bankDataGrid["fax", bankDataGrid.CurrentRow.Index].Value.ToString();
            txttelbank.Text = bankDataGrid["telbank", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtsms.Text = bankDataGrid["sms", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtemail.Text = bankDataGrid["email", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtsite.Text = bankDataGrid["site", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtadres.Text = bankDataGrid["adres", bankDataGrid.CurrentRow.Index].Value.ToString();
            txtnote.Text = bankDataGrid["note", bankDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void bankDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bankDataGrid.RowCount > 0)
            {
                SelectedData();
                if (bankDataGrid.CurrentRow.Index == 0)
                    bankDataGrid[0, 0].Selected = true;
                else
                    bankDataGrid[0, bankDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void bankDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && bankDataGrid.RowCount > 0)
                SelectedData();
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from basebank");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from basebank");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybbid = dgvr.Cells[0].Value.ToString();
                txtbbid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtbbid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT bnk.bankid, bnk.bbid, bnk.branchid, bnk.branchname, bnk.citycode, bnk.tel, bnk.fax, bnk.telbank, bnk.sms, bnk.email, bnk.site, bnk.adres, bnk.note FROM banks AS bnk INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid ";
            if (txtbbidB.Text.Trim().Length != 0)
                query += "AND bb.bankname like (N'%" + txtbbidB.Text + "%')";
            if (txtbranchidB.Text.Trim().Length != 0)
                query += "AND branchid= '" + txtbranchidB.Text + "'";
            if (txtbranchnameB.Text.Trim().Length != 0)
                query += "AND branchname like (N'%" + txtbranchnameB.Text + "%')";
            DataSet ds = ado.select(query);
            bankDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT bnk.bankid, bnk.bbid, bnk.branchid, bnk.branchname, bnk.citycode, bnk.tel, bnk.fax, bnk.telbank, bnk.sms, bnk.email, bnk.site, bnk.adres, bnk.note FROM banks AS bnk INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid");
            bankDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }
    }
}
