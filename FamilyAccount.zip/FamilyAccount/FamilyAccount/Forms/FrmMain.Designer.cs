﻿namespace FamilyAccount
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.ribForm = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.btnFamily = new DevComponents.DotNetBar.ButtonItem();
            this.btnCoding = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel5 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar11 = new DevComponents.DotNetBar.RibbonBar();
            this.btnPhone = new DevComponents.DotNetBar.ButtonItem();
            this.btnNotation = new DevComponents.DotNetBar.ButtonItem();
            this.btnBackupRestore = new DevComponents.DotNetBar.ButtonItem();
            this.btnBackup = new DevComponents.DotNetBar.ButtonItem();
            this.btnRestore = new DevComponents.DotNetBar.ButtonItem();
            this.btnSkin = new DevComponents.DotNetBar.ButtonItem();
            this.btnBlack = new DevComponents.DotNetBar.ButtonItem();
            this.btnBlue = new DevComponents.DotNetBar.ButtonItem();
            this.btnSilver = new DevComponents.DotNetBar.ButtonItem();
            this.btnSetting = new DevComponents.DotNetBar.ButtonItem();
            this.btnAbout = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar3 = new DevComponents.DotNetBar.RibbonBar();
            this.btnSalary = new DevComponents.DotNetBar.ButtonItem();
            this.btnCost = new DevComponents.DotNetBar.ButtonItem();
            this.btnDocument = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar6 = new DevComponents.DotNetBar.RibbonBar();
            this.btnBanks = new DevComponents.DotNetBar.ButtonItem();
            this.btnAccount = new DevComponents.DotNetBar.ButtonItem();
            this.btnCheq = new DevComponents.DotNetBar.ButtonItem();
            this.btnLoan = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar10 = new DevComponents.DotNetBar.RibbonBar();
            this.btnReport = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonTabItem1 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem2 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem3 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem4 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem5 = new DevComponents.DotNetBar.RibbonTabItem();
            this.btnSecurity = new DevComponents.DotNetBar.ButtonItem();
            this.office2007StartButton2 = new DevComponents.DotNetBar.Office2007StartButton();
            this.btnExit = new DevComponents.DotNetBar.ButtonItem();
            this.txtBlue = new DevComponents.Editors.ComboItem();
            this.txtBlack = new DevComponents.Editors.ComboItem();
            this.txtSilver = new DevComponents.Editors.ComboItem();
            this.SetBackup = new System.Windows.Forms.OpenFileDialog();
            this.FolderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.notifyIco = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Prompt = new System.Windows.Forms.ToolStripMenuItem();
            this.Display = new System.Windows.Forms.ToolStripMenuItem();
            this.About = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.ribForm.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel5.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.contextNotify.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribForm
            // 
            this.ribForm.CanCustomize = false;
            this.ribForm.CaptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.ribForm.CaptionVisible = true;
            this.ribForm.Controls.Add(this.ribbonPanel1);
            this.ribForm.Controls.Add(this.ribbonPanel5);
            this.ribForm.Controls.Add(this.ribbonPanel2);
            this.ribForm.Controls.Add(this.ribbonPanel3);
            this.ribForm.Controls.Add(this.ribbonPanel4);
            this.ribForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribForm.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribForm.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ribbonTabItem1,
            this.ribbonTabItem2,
            this.ribbonTabItem3,
            this.ribbonTabItem4,
            this.ribbonTabItem5,
            this.btnSecurity});
            this.ribForm.KeyTipsFont = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribForm.Location = new System.Drawing.Point(0, 0);
            this.ribForm.Name = "ribForm";
            this.ribForm.Office2007ColorTable = DevComponents.DotNetBar.Rendering.eOffice2007ColorScheme.Black;
            this.ribForm.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.ribForm.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.office2007StartButton2,
            this.btnExit});
            this.ribForm.Size = new System.Drawing.Size(773, 151);
            this.ribForm.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribForm.TabGroupHeight = 14;
            this.ribForm.TabGroupsVisible = true;
            this.ribForm.TabIndex = 0;
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel1.Controls.Add(this.ribbonBar1);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ribbonPanel1.Size = new System.Drawing.Size(773, 93);
            this.ribbonPanel1.TabIndex = 1;
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Right;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnFamily,
            this.btnCoding});
            this.ribbonBar1.Location = new System.Drawing.Point(615, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ribbonBar1.Size = new System.Drawing.Size(155, 90);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar1.TabIndex = 0;
            this.ribbonBar1.Text = "ثبت اطلاعات پایه سیستم";
            // 
            // btnFamily
            // 
            this.btnFamily.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFamily.Image = ((System.Drawing.Image)(resources.GetObject("btnFamily.Image")));
            this.btnFamily.ImagePaddingHorizontal = 8;
            this.btnFamily.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnFamily.Name = "btnFamily";
            this.btnFamily.RibbonWordWrap = false;
            this.btnFamily.SubItemsExpandWidth = 14;
            this.btnFamily.Text = "اعضای خانواده";
            this.btnFamily.Click += new System.EventHandler(this.btnFamily_Click);
            // 
            // btnCoding
            // 
            this.btnCoding.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnCoding.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCoding.Image = ((System.Drawing.Image)(resources.GetObject("btnCoding.Image")));
            this.btnCoding.ImagePaddingHorizontal = 8;
            this.btnCoding.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCoding.Name = "btnCoding";
            this.btnCoding.RibbonWordWrap = false;
            this.btnCoding.SubItemsExpandWidth = 14;
            this.btnCoding.Text = "اطلاعات پایه";
            this.btnCoding.Click += new System.EventHandler(this.btnCoding_Click);
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel5.Controls.Add(this.ribbonBar11);
            this.ribbonPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel5.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel5.Name = "ribbonPanel5";
            this.ribbonPanel5.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel5.Size = new System.Drawing.Size(773, 93);
            this.ribbonPanel5.TabIndex = 5;
            this.ribbonPanel5.Visible = false;
            // 
            // ribbonBar11
            // 
            this.ribbonBar11.AutoOverflowEnabled = true;
            this.ribbonBar11.Dock = System.Windows.Forms.DockStyle.Right;
            this.ribbonBar11.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnPhone,
            this.btnNotation,
            this.btnBackupRestore,
            this.btnSkin,
            this.btnSetting,
            this.btnAbout});
            this.ribbonBar11.Location = new System.Drawing.Point(257, 0);
            this.ribbonBar11.Name = "ribbonBar11";
            this.ribbonBar11.Size = new System.Drawing.Size(513, 90);
            this.ribbonBar11.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar11.TabIndex = 0;
            this.ribbonBar11.Text = "امکانات";
            // 
            // btnPhone
            // 
            this.btnPhone.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnPhone.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPhone.Image = ((System.Drawing.Image)(resources.GetObject("btnPhone.Image")));
            this.btnPhone.ImagePaddingHorizontal = 8;
            this.btnPhone.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnPhone.Name = "btnPhone";
            this.btnPhone.RibbonWordWrap = false;
            this.btnPhone.SubItemsExpandWidth = 14;
            this.btnPhone.Text = "دفتر تلفن";
            this.btnPhone.Click += new System.EventHandler(this.btnPhone_Click);
            // 
            // btnNotation
            // 
            this.btnNotation.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnNotation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNotation.Image = ((System.Drawing.Image)(resources.GetObject("btnNotation.Image")));
            this.btnNotation.ImagePaddingHorizontal = 8;
            this.btnNotation.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnNotation.Name = "btnNotation";
            this.btnNotation.RibbonWordWrap = false;
            this.btnNotation.SubItemsExpandWidth = 14;
            this.btnNotation.Text = "وقایع و رویدادها";
            this.btnNotation.Click += new System.EventHandler(this.btnNotation_Click);
            // 
            // btnBackupRestore
            // 
            this.btnBackupRestore.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnBackupRestore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBackupRestore.Image = ((System.Drawing.Image)(resources.GetObject("btnBackupRestore.Image")));
            this.btnBackupRestore.ImagePaddingHorizontal = 8;
            this.btnBackupRestore.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnBackupRestore.Name = "btnBackupRestore";
            this.btnBackupRestore.RibbonWordWrap = false;
            this.btnBackupRestore.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnBackup,
            this.btnRestore});
            this.btnBackupRestore.SubItemsExpandWidth = 14;
            this.btnBackupRestore.Text = "نسخه پشتیبان";
            // 
            // btnBackup
            // 
            this.btnBackup.Icon = ((System.Drawing.Icon)(resources.GetObject("btnBackup.Icon")));
            this.btnBackup.ImagePaddingHorizontal = 8;
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Text = "تهیه نسخه پشتیبان";
            this.btnBackup.Click += new System.EventHandler(this.btnBackup_Click);
            // 
            // btnRestore
            // 
            this.btnRestore.Icon = ((System.Drawing.Icon)(resources.GetObject("btnRestore.Icon")));
            this.btnRestore.ImagePaddingHorizontal = 8;
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Text = "بازیابی نسخه پشتیبان";
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // btnSkin
            // 
            this.btnSkin.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSkin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSkin.Image = ((System.Drawing.Image)(resources.GetObject("btnSkin.Image")));
            this.btnSkin.ImagePaddingHorizontal = 8;
            this.btnSkin.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnSkin.Name = "btnSkin";
            this.btnSkin.RibbonWordWrap = false;
            this.btnSkin.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnBlack,
            this.btnBlue,
            this.btnSilver});
            this.btnSkin.SubItemsExpandWidth = 14;
            this.btnSkin.Text = "تغییر پوسته نرم افزار";
            // 
            // btnBlack
            // 
            this.btnBlack.ForeColor = System.Drawing.Color.Black;
            this.btnBlack.HotForeColor = System.Drawing.Color.White;
            this.btnBlack.ImagePaddingHorizontal = 8;
            this.btnBlack.Name = "btnBlack";
            this.btnBlack.Text = "مشکی";
            this.btnBlack.Click += new System.EventHandler(this.btnBlack_Click);
            // 
            // btnBlue
            // 
            this.btnBlue.ForeColor = System.Drawing.Color.Blue;
            this.btnBlue.ImagePaddingHorizontal = 8;
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Text = "آبی";
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);
            // 
            // btnSilver
            // 
            this.btnSilver.ForeColor = System.Drawing.Color.Silver;
            this.btnSilver.ImagePaddingHorizontal = 8;
            this.btnSilver.Name = "btnSilver";
            this.btnSilver.Text = "نقره ای";
            this.btnSilver.Click += new System.EventHandler(this.btnSilver_Click);
            // 
            // btnSetting
            // 
            this.btnSetting.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetting.Image = ((System.Drawing.Image)(resources.GetObject("btnSetting.Image")));
            this.btnSetting.ImagePaddingHorizontal = 8;
            this.btnSetting.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.RibbonWordWrap = false;
            this.btnSetting.SubItemsExpandWidth = 14;
            this.btnSetting.Text = "تنظیمات سیستم";
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbout.Image = ((System.Drawing.Image)(resources.GetObject("btnAbout.Image")));
            this.btnAbout.ImagePaddingHorizontal = 8;
            this.btnAbout.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.RibbonWordWrap = false;
            this.btnAbout.SubItemsExpandWidth = 14;
            this.btnAbout.Text = "درباره نرم افزار";
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel2.Controls.Add(this.ribbonBar3);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(773, 92);
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBar3
            // 
            this.ribbonBar3.AutoOverflowEnabled = true;
            this.ribbonBar3.Dock = System.Windows.Forms.DockStyle.Right;
            this.ribbonBar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnSalary,
            this.btnCost,
            this.btnDocument});
            this.ribbonBar3.Location = new System.Drawing.Point(563, 0);
            this.ribbonBar3.Name = "ribbonBar3";
            this.ribbonBar3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ribbonBar3.Size = new System.Drawing.Size(207, 89);
            this.ribbonBar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar3.TabIndex = 0;
            this.ribbonBar3.Text = "ثبت درآمدها ، هزینه ها و اسناد مالی";
            // 
            // btnSalary
            // 
            this.btnSalary.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalary.Image = ((System.Drawing.Image)(resources.GetObject("btnSalary.Image")));
            this.btnSalary.ImagePaddingHorizontal = 8;
            this.btnSalary.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnSalary.Name = "btnSalary";
            this.btnSalary.RibbonWordWrap = false;
            this.btnSalary.SubItemsExpandWidth = 14;
            this.btnSalary.Text = "درآمدها";
            this.btnSalary.Click += new System.EventHandler(this.btnSalary_Click);
            // 
            // btnCost
            // 
            this.btnCost.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnCost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCost.Image = ((System.Drawing.Image)(resources.GetObject("btnCost.Image")));
            this.btnCost.ImagePaddingHorizontal = 8;
            this.btnCost.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCost.Name = "btnCost";
            this.btnCost.RibbonWordWrap = false;
            this.btnCost.SubItemsExpandWidth = 14;
            this.btnCost.Text = "هزینه ها";
            this.btnCost.Click += new System.EventHandler(this.btnCost_Click);
            // 
            // btnDocument
            // 
            this.btnDocument.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnDocument.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDocument.Image = ((System.Drawing.Image)(resources.GetObject("btnDocument.Image")));
            this.btnDocument.ImagePaddingHorizontal = 8;
            this.btnDocument.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDocument.Name = "btnDocument";
            this.btnDocument.RibbonWordWrap = false;
            this.btnDocument.SubItemsExpandWidth = 14;
            this.btnDocument.Text = "اسناد مالی و اداری";
            this.btnDocument.Click += new System.EventHandler(this.btnDocument_Click);
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel3.Controls.Add(this.ribbonBar6);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(773, 93);
            this.ribbonPanel3.TabIndex = 3;
            this.ribbonPanel3.Visible = false;
            // 
            // ribbonBar6
            // 
            this.ribbonBar6.AutoOverflowEnabled = true;
            this.ribbonBar6.Dock = System.Windows.Forms.DockStyle.Right;
            this.ribbonBar6.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnBanks,
            this.btnAccount,
            this.btnCheq,
            this.btnLoan});
            this.ribbonBar6.Location = new System.Drawing.Point(389, 0);
            this.ribbonBar6.Name = "ribbonBar6";
            this.ribbonBar6.Size = new System.Drawing.Size(381, 90);
            this.ribbonBar6.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar6.TabIndex = 0;
            this.ribbonBar6.Text = "عملیات بانکی";
            // 
            // btnBanks
            // 
            this.btnBanks.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnBanks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBanks.Image = ((System.Drawing.Image)(resources.GetObject("btnBanks.Image")));
            this.btnBanks.ImagePaddingHorizontal = 8;
            this.btnBanks.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnBanks.Name = "btnBanks";
            this.btnBanks.RibbonWordWrap = false;
            this.btnBanks.SubItemsExpandWidth = 14;
            this.btnBanks.Text = "شعب بانک";
            this.btnBanks.Click += new System.EventHandler(this.btnBanks_Click);
            // 
            // btnAccount
            // 
            this.btnAccount.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnAccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccount.Image = ((System.Drawing.Image)(resources.GetObject("btnAccount.Image")));
            this.btnAccount.ImagePaddingHorizontal = 8;
            this.btnAccount.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnAccount.Name = "btnAccount";
            this.btnAccount.RibbonWordWrap = false;
            this.btnAccount.SubItemsExpandWidth = 14;
            this.btnAccount.Text = "حسابهای بانکی";
            this.btnAccount.Click += new System.EventHandler(this.btnAccount_Click);
            // 
            // btnCheq
            // 
            this.btnCheq.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnCheq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheq.Image = ((System.Drawing.Image)(resources.GetObject("btnCheq.Image")));
            this.btnCheq.ImagePaddingHorizontal = 8;
            this.btnCheq.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCheq.Name = "btnCheq";
            this.btnCheq.RibbonWordWrap = false;
            this.btnCheq.SubItemsExpandWidth = 14;
            this.btnCheq.Text = "چک های صادره و دریافتی";
            this.btnCheq.Click += new System.EventHandler(this.btnCheq_Click);
            // 
            // btnLoan
            // 
            this.btnLoan.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnLoan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoan.Image = ((System.Drawing.Image)(resources.GetObject("btnLoan.Image")));
            this.btnLoan.ImagePaddingHorizontal = 8;
            this.btnLoan.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnLoan.Name = "btnLoan";
            this.btnLoan.RibbonWordWrap = false;
            this.btnLoan.SubItemsExpandWidth = 14;
            this.btnLoan.Text = "تسهیلات بانکی";
            this.btnLoan.Click += new System.EventHandler(this.btnLoan_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel4.Controls.Add(this.ribbonBar10);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 0);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(773, 149);
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBar10
            // 
            this.ribbonBar10.AutoOverflowEnabled = true;
            this.ribbonBar10.Dock = System.Windows.Forms.DockStyle.Right;
            this.ribbonBar10.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnReport});
            this.ribbonBar10.Location = new System.Drawing.Point(669, 0);
            this.ribbonBar10.Name = "ribbonBar10";
            this.ribbonBar10.Size = new System.Drawing.Size(101, 146);
            this.ribbonBar10.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBar10.TabIndex = 0;
            this.ribbonBar10.Text = "گزارشات";
            // 
            // btnReport
            // 
            this.btnReport.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReport.Image = ((System.Drawing.Image)(resources.GetObject("btnReport.Image")));
            this.btnReport.ImagePaddingHorizontal = 8;
            this.btnReport.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnReport.Name = "btnReport";
            this.btnReport.RibbonWordWrap = false;
            this.btnReport.SubItemsExpandWidth = 14;
            this.btnReport.Text = "گزارشات سیستم";
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // ribbonTabItem1
            // 
            this.ribbonTabItem1.Checked = true;
            this.ribbonTabItem1.ImagePaddingHorizontal = 8;
            this.ribbonTabItem1.Name = "ribbonTabItem1";
            this.ribbonTabItem1.Panel = this.ribbonPanel1;
            this.ribbonTabItem1.Text = "اطلاعات پایه";
            // 
            // ribbonTabItem2
            // 
            this.ribbonTabItem2.ImagePaddingHorizontal = 8;
            this.ribbonTabItem2.Name = "ribbonTabItem2";
            this.ribbonTabItem2.Panel = this.ribbonPanel2;
            this.ribbonTabItem2.Text = "درآمد ، هزینه و اسناد مالی";
            // 
            // ribbonTabItem3
            // 
            this.ribbonTabItem3.ImagePaddingHorizontal = 8;
            this.ribbonTabItem3.Name = "ribbonTabItem3";
            this.ribbonTabItem3.Panel = this.ribbonPanel3;
            this.ribbonTabItem3.Text = "عملیات بانکی";
            // 
            // ribbonTabItem4
            // 
            this.ribbonTabItem4.ImagePaddingHorizontal = 8;
            this.ribbonTabItem4.Name = "ribbonTabItem4";
            this.ribbonTabItem4.Panel = this.ribbonPanel4;
            this.ribbonTabItem4.Text = "گزارشات";
            // 
            // ribbonTabItem5
            // 
            this.ribbonTabItem5.ImagePaddingHorizontal = 8;
            this.ribbonTabItem5.Name = "ribbonTabItem5";
            this.ribbonTabItem5.Panel = this.ribbonPanel5;
            this.ribbonTabItem5.Text = "امکانات";
            // 
            // btnSecurity
            // 
            this.btnSecurity.ColorTable = DevComponents.DotNetBar.eButtonColor.MagentaWithBackground;
            this.btnSecurity.ForeColor = System.Drawing.Color.Blue;
            this.btnSecurity.ImagePaddingHorizontal = 8;
            this.btnSecurity.Name = "btnSecurity";
            this.btnSecurity.Text = "امنیت ورود به سیستم";
            this.btnSecurity.Click += new System.EventHandler(this.btnSecurity_Click);
            // 
            // office2007StartButton2
            // 
            this.office2007StartButton2.AutoExpandOnClick = true;
            this.office2007StartButton2.CanCustomize = false;
            this.office2007StartButton2.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.office2007StartButton2.Image = ((System.Drawing.Image)(resources.GetObject("office2007StartButton2.Image")));
            this.office2007StartButton2.ImagePaddingHorizontal = 2;
            this.office2007StartButton2.ImagePaddingVertical = 2;
            this.office2007StartButton2.Name = "office2007StartButton2";
            this.office2007StartButton2.ShowSubItems = false;
            this.office2007StartButton2.Text = "&File";
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.ImagePaddingHorizontal = 8;
            this.btnExit.Name = "btnExit";
            this.btnExit.Text = "خــــــــروج";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtBlue
            // 
            this.txtBlue.ImagePosition = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBlue.Text = "آبی";
            // 
            // txtBlack
            // 
            this.txtBlack.ImagePosition = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBlack.Text = "مشکی";
            // 
            // txtSilver
            // 
            this.txtSilver.ImagePosition = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSilver.Text = "نقره ای";
            // 
            // SetBackup
            // 
            this.SetBackup.Filter = "Backup files (*.bak) |*.bak|All files(*.*) |*.*";
            this.SetBackup.Title = "Restore Database";
            // 
            // notifyIco
            // 
            this.notifyIco.ContextMenuStrip = this.contextNotify;
            this.notifyIco.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIco.Icon")));
            this.notifyIco.Text = "حسابداری خانواده-اولین نرم افزار دخل و خرج خانواده ایرانی";
            this.notifyIco.Visible = true;
            // 
            // contextNotify
            // 
            this.contextNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Prompt,
            this.Display,
            this.About,
            this.toolStripSeparator1,
            this.Exit});
            this.contextNotify.Name = "contextNotify";
            this.contextNotify.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextNotify.Size = new System.Drawing.Size(142, 98);
            // 
            // Prompt
            // 
            this.Prompt.Image = ((System.Drawing.Image)(resources.GetObject("Prompt.Image")));
            this.Prompt.Name = "Prompt";
            this.Prompt.Size = new System.Drawing.Size(141, 22);
            this.Prompt.Text = "اعلان سیستم";
            this.Prompt.Click += new System.EventHandler(this.Prompt_Click);
            // 
            // Display
            // 
            this.Display.Image = ((System.Drawing.Image)(resources.GetObject("Display.Image")));
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(141, 22);
            this.Display.Text = "نمایش برنامه";
            this.Display.Click += new System.EventHandler(this.Display_Click);
            // 
            // About
            // 
            this.About.Image = ((System.Drawing.Image)(resources.GetObject("About.Image")));
            this.About.Name = "About";
            this.About.Size = new System.Drawing.Size(141, 22);
            this.About.Text = "درباره سیستم";
            this.About.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(138, 6);
            // 
            // Exit
            // 
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(141, 22);
            this.Exit.Text = "خروج";
            this.Exit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 150);
            this.Controls.Add(this.ribForm);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "حسابداری خانواده";
            this.Load += new System.EventHandler(this.Main_Load);
            this.SizeChanged += new System.EventHandler(this.FrmMain_SizeChanged);
            this.ribForm.ResumeLayout(false);
            this.ribForm.PerformLayout();
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel5.ResumeLayout(false);
            this.ribbonPanel2.ResumeLayout(false);
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.contextNotify.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribForm;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem1;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem2;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem3;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem4;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel5;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem5;
        private DevComponents.DotNetBar.RibbonBar ribbonBar3;
        private DevComponents.DotNetBar.RibbonBar ribbonBar10;
        private DevComponents.DotNetBar.RibbonBar ribbonBar6;
        private DevComponents.DotNetBar.RibbonBar ribbonBar11;
        private DevComponents.DotNetBar.ButtonItem btnFamily;
        private DevComponents.DotNetBar.ButtonItem btnBanks;
        private DevComponents.DotNetBar.ButtonItem btnSalary;
        private DevComponents.DotNetBar.ButtonItem btnReport;
        private DevComponents.DotNetBar.ButtonItem btnAccount;
        private DevComponents.DotNetBar.ButtonItem btnNotation;
        private DevComponents.DotNetBar.ButtonItem btnPhone;
        private DevComponents.Editors.ComboItem txtBlue;
        private DevComponents.Editors.ComboItem txtBlack;
        private DevComponents.Editors.ComboItem txtSilver;
        private System.Windows.Forms.OpenFileDialog SetBackup;
        private System.Windows.Forms.FolderBrowserDialog FolderBrowser;
        private DevComponents.DotNetBar.ButtonItem btnCost;
        private DevComponents.DotNetBar.ButtonItem btnCoding;
        private DevComponents.DotNetBar.ButtonItem btnDocument;
        private DevComponents.DotNetBar.ButtonItem btnCheq;
        private DevComponents.DotNetBar.ButtonItem btnLoan;
        private DevComponents.DotNetBar.ButtonItem btnBackupRestore;
        private DevComponents.DotNetBar.ButtonItem btnBackup;
        private DevComponents.DotNetBar.ButtonItem btnRestore;
        private DevComponents.DotNetBar.ButtonItem btnSetting;
        private DevComponents.DotNetBar.ButtonItem btnSkin;
        private DevComponents.DotNetBar.ButtonItem btnBlack;
        private DevComponents.DotNetBar.ButtonItem btnBlue;
        private DevComponents.DotNetBar.ButtonItem btnSilver;
        private DevComponents.DotNetBar.ButtonItem btnAbout;
        private DevComponents.DotNetBar.Office2007StartButton office2007StartButton2;
        private DevComponents.DotNetBar.ButtonItem btnExit;
        private DevComponents.DotNetBar.ButtonItem btnSecurity;
        private System.Windows.Forms.NotifyIcon notifyIco;
        private System.Windows.Forms.ContextMenuStrip contextNotify;
        private System.Windows.Forms.ToolStripMenuItem Prompt;
        private System.Windows.Forms.ToolStripMenuItem Display;
        private System.Windows.Forms.ToolStripMenuItem About;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem Exit;
    }
}