﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FamilyAccount
{
    public partial class FrmLogin : Form
    {
        DataSet ds = null;
        ClassDB ado = new ClassDB();
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text.Equals("admin") && txtPassword.Text.Equals("admin"))
                this.Close();
            else
            {
                if (txtUsername.Text != "")
                {
                    if (txtPassword.Text != "")
                    {
                        ds = ado.select("select * from security where username='" + txtUsername.Text.Trim() + "' and password='" + ado.EncryptText(txtPassword.Text) + "'");
                        if (ds.Tables[0].Rows.Count == 1)
                            this.Close();
                        else
                        {
                            lblMesLogin.Text = ".ورود شما ناموفق بود. لطفأ دوباره سعی کنید";
                            txtUsername.Text = "";
                            txtPassword.Text = "";
                            txtUsername.Focus();
                            return;
                        }
                    }
                    else
                        txtPassword.Focus();
                }
                else
                    txtUsername.Focus();
            }
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ModalForgot.Close();
        }

        private void linkPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (txtUsername.Text != "")
            {
                ds = ado.select("select * from security where username='" + txtUsername.Text.Trim() + "'");
                if (ds.Tables[0].Rows.Count != 0)
                {
                    if (ds.Tables[0].Rows[0]["secureques"].ToString() != "")
                    {
                        txtsecureques.Text = ds.Tables[0].Rows[0]["secureques"].ToString();
                        txtquesanswer.Text = "";
                        ModalForgot.Show(this, getPassword);
                        txtquesanswer.Focus();
                    }
                    else
                        MessageBox.Show("نام کاربری موردنظر شما نامعتبر و یا فاقد سئوال امنیتی جهت دریافت رمز عبور می باشد", "نام کاربری نامعتبر", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                }
                else
                    lblMesLogin.Text = "نام کاربری معتبر در سیستم وجود ندارد";
            }
            else
                lblMesLogin.Text = "نام کاربری را جهت بازیابی کلمه عبور وارد نمائید";
        }

        private void btnRestorePass_Click(object sender, EventArgs e)
        {
            if (txtquesanswer.Text != "")
            {
                if (ds.Tables[0].Rows[0]["quesanswer"].ToString().Equals(ado.EncryptText(txtquesanswer.Text)))
                {
                    lblMesLogin.Text = ado.DecryptText(ds.Tables[0].Rows[0]["password"].ToString())+" :کلمه عبور شما عبارتست از";
                    ModalForgot.Close();
                }
                else
                {
                    MessageBox.Show("پاسخ سئوال فوق صحیح نمی باشد", "سئوال امنیتی", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    ModalForgot.Close();
                }
            }
        }

        private void txtquesanswer_Enter(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

        private void txtquesanswer_Leave(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

    }
}
