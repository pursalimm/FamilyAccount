﻿namespace FamilyAccount
{
    partial class FrmSecurity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmSecurity aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem5 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem6 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSecurity));
            this.btnSaveOk = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtquesanswer = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtconfirmpass = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtusername = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpassword = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.cbosecureques = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquesanswer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtconfirmpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtusername)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbosecureques)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSaveOk
            // 
            this.btnSaveOk.BackgroundImageStyle.Alpha = 100;
            this.btnSaveOk.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveOk.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSaveOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveOk.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSaveOk.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSaveOk.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSaveOk.Location = new System.Drawing.Point(70, 125);
            this.btnSaveOk.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSaveOk.Name = "btnSaveOk";
            this.btnSaveOk.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSaveOk.Size = new System.Drawing.Size(58, 25);
            this.btnSaveOk.TabIndex = 5;
            this.btnSaveOk.Tag = "0";
            this.btnSaveOk.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOk.TextStyle.Text = "تائید";
            this.btnSaveOk.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSaveOk.Click += new System.EventHandler(this.btnSaveOk_Click);
            // 
            // txtquesanswer
            // 
            this.txtquesanswer.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquesanswer.CaptionStyle.CaptionSize = 85;
            this.txtquesanswer.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquesanswer.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquesanswer.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtquesanswer.CaptionStyle.TextStyle.Text = "جواب سئوال";
            this.txtquesanswer.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquesanswer.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquesanswer.Location = new System.Drawing.Point(214, 125);
            this.txtquesanswer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtquesanswer.Name = "txtquesanswer";
            this.txtquesanswer.Size = new System.Drawing.Size(211, 27);
            this.txtquesanswer.TabIndex = 4;
            this.txtquesanswer.Tag = "0";
            this.txtquesanswer.ValidationStyle.AcceptsTab = true;
            this.txtquesanswer.ValidationStyle.PasswordChar = '\0';
            this.txtquesanswer.Value = "";
            this.txtquesanswer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            // 
            // txtconfirmpass
            // 
            this.txtconfirmpass.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtconfirmpass.CaptionStyle.CaptionSize = 85;
            this.txtconfirmpass.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtconfirmpass.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtconfirmpass.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtconfirmpass.CaptionStyle.TextStyle.Text = "تائید رمز عبور";
            this.txtconfirmpass.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconfirmpass.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtconfirmpass.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtconfirmpass.Location = new System.Drawing.Point(246, 67);
            this.txtconfirmpass.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtconfirmpass.Name = "txtconfirmpass";
            this.txtconfirmpass.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtconfirmpass.Size = new System.Drawing.Size(179, 27);
            this.txtconfirmpass.TabIndex = 2;
            this.txtconfirmpass.Tag = "0";
            this.txtconfirmpass.ValidationStyle.AcceptsTab = true;
            this.txtconfirmpass.ValidationStyle.PasswordChar = '\0';
            this.txtconfirmpass.ValidationStyle.UseSystemPasswordChar = true;
            this.txtconfirmpass.Value = "";
            this.txtconfirmpass.Leave += new System.EventHandler(this.txtpassword_Leave);
            this.txtconfirmpass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            this.txtconfirmpass.Enter += new System.EventHandler(this.txtpassword_Enter);
            // 
            // txtusername
            // 
            this.txtusername.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtusername.CaptionStyle.CaptionSize = 85;
            this.txtusername.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtusername.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtusername.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtusername.CaptionStyle.TextStyle.Text = "نام کاربری";
            this.txtusername.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtusername.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtusername.Location = new System.Drawing.Point(246, 9);
            this.txtusername.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(179, 27);
            this.txtusername.TabIndex = 0;
            this.txtusername.Tag = "0";
            this.txtusername.ValidationStyle.AcceptsTab = true;
            this.txtusername.ValidationStyle.PasswordChar = '\0';
            this.txtusername.Value = "";
            this.txtusername.Leave += new System.EventHandler(this.txtpassword_Leave);
            this.txtusername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            this.txtusername.Enter += new System.EventHandler(this.txtpassword_Enter);
            // 
            // txtpassword
            // 
            this.txtpassword.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpassword.CaptionStyle.CaptionSize = 85;
            this.txtpassword.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpassword.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpassword.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpassword.CaptionStyle.TextStyle.Text = "رمز عبور";
            this.txtpassword.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpassword.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpassword.Location = new System.Drawing.Point(246, 38);
            this.txtpassword.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtpassword.Size = new System.Drawing.Size(179, 27);
            this.txtpassword.TabIndex = 1;
            this.txtpassword.Tag = "0";
            this.txtpassword.ValidationStyle.AcceptsTab = true;
            this.txtpassword.ValidationStyle.PasswordChar = '\0';
            this.txtpassword.ValidationStyle.UseSystemPasswordChar = true;
            this.txtpassword.Value = "";
            this.txtpassword.Leave += new System.EventHandler(this.txtpassword_Leave);
            this.txtpassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            this.txtpassword.Enter += new System.EventHandler(this.txtpassword_Enter);
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.cbosecureques);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnSaveOk);
            this.elContainer1.Controls.Add(this.txtusername);
            this.elContainer1.Controls.Add(this.txtquesanswer);
            this.elContainer1.Controls.Add(this.txtpassword);
            this.elContainer1.Controls.Add(this.txtconfirmpass);
            this.elContainer1.Location = new System.Drawing.Point(8, 7);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(433, 161);
            this.elContainer1.TabIndex = 0;
            // 
            // cbosecureques
            // 
            // 
            // 
            // 
            this.cbosecureques.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosecureques.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosecureques.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosecureques.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosecureques.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbosecureques.CaptionStyle.CaptionSize = 85;
            this.cbosecureques.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosecureques.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbosecureques.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosecureques.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosecureques.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosecureques.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosecureques.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbosecureques.CaptionStyle.TextStyle.Text = "سئوال امنیتی";
            this.cbosecureques.CheckedDisplaySeparator = ',';
            this.cbosecureques.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosecureques.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbosecureques.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosecureques.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbosecureques.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbosecureques.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cbosecureques.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosecureques.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbosecureques.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosecureques.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosecureques.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            elListBoxItem1.Value = "رنگ مورد علاقه شما؟";
            elListBoxItem2.Value = "بهترین دوست شما در زندگی؟";
            elListBoxItem3.Value = "نام اولین معلم شما در ابتدایی؟";
            elListBoxItem4.Value = "نام حیوان مورد علاقه شما؟";
            elListBoxItem5.Value = "شهر مورد علاقه برای زندگی؟";
            elListBoxItem6.Value = "هدف مهم زندگی؟";
            this.cbosecureques.Items.Add(elListBoxItem1);
            this.cbosecureques.Items.Add(elListBoxItem2);
            this.cbosecureques.Items.Add(elListBoxItem3);
            this.cbosecureques.Items.Add(elListBoxItem4);
            this.cbosecureques.Items.Add(elListBoxItem5);
            this.cbosecureques.Items.Add(elListBoxItem6);
            this.cbosecureques.Location = new System.Drawing.Point(113, 96);
            this.cbosecureques.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbosecureques.Name = "cbosecureques";
            this.cbosecureques.Size = new System.Drawing.Size(312, 27);
            this.cbosecureques.TabIndex = 3;
            this.cbosecureques.Tag = "0";
            this.cbosecureques.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtusername_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(8, 125);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(58, 25);
            this.btnClose.TabIndex = 6;
            this.btnClose.Tag = "0";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "انصراف";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // FrmSecurity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 177);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSecurity";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "امنیت نرم افزار";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmSecurity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnSaveOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquesanswer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtconfirmpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtusername)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cbosecureques)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELButton btnSaveOk;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquesanswer;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtconfirmpass;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtusername;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpassword;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbosecureques;

    }
}