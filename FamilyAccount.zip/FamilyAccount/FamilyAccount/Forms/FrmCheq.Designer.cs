﻿namespace FamilyAccount
{
    partial class FrmCheq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmCheq aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCheq));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem5 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem6 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem7 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem8 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem9 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem10 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem11 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem12 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem13 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem14 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns2 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnIns1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtcheqid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.lblQuan = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtcsid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcheqnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtinmode = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcheqquan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cbocheqstate = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtcheqdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.txtcheqexpo = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.cbocheqtype = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.contextOperate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.lblsum = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cheqDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.idcs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqexpo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inmode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqstate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cheqnote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elButton6 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton8 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.backType = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnInsCH = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.cbotypeCH = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.rdochdate = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton3 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.rdochExpo = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccidCH = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcsidCH = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcheqquanmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cbostateCH = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtinmodeCH = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcheqquanmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqexpo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqtype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cheqDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backType)).BeginInit();
            this.backType.SuspendLayout();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbotypeCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochExpo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsidCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbostateCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmodeCH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.btnIns2);
            this.backContainer.Controls.Add(this.btnIns1);
            this.backContainer.Controls.Add(this.txtcheqid);
            this.backContainer.Controls.Add(this.lblQuan);
            this.backContainer.Controls.Add(this.txtcsid);
            this.backContainer.Controls.Add(this.txtcheqnote);
            this.backContainer.Controls.Add(this.txtaccid);
            this.backContainer.Controls.Add(this.txtinmode);
            this.backContainer.Controls.Add(this.txtcheqquan);
            this.backContainer.Controls.Add(this.cbocheqstate);
            this.backContainer.Controls.Add(this.txtcheqdate);
            this.backContainer.Controls.Add(this.txtcheqexpo);
            this.backContainer.Location = new System.Drawing.Point(6, 66);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(708, 190);
            this.backContainer.TabIndex = 1;
            this.backContainer.Tag = "0";
            // 
            // btnIns2
            // 
            this.btnIns2.BackgroundImageStyle.Alpha = 100;
            this.btnIns2.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnIns2.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns2.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns2.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns2.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns2.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns2.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.Location = new System.Drawing.Point(336, 37);
            this.btnIns2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns2.Name = "btnIns2";
            this.btnIns2.Size = new System.Drawing.Size(28, 27);
            this.btnIns2.TabIndex = 3;
            this.btnIns2.Tag = "0";
            this.btnIns2.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.Click += new System.EventHandler(this.btnIns2_Click);
            // 
            // btnIns1
            // 
            this.btnIns1.BackgroundImageStyle.Alpha = 100;
            this.btnIns1.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnIns1.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns1.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns1.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.Location = new System.Drawing.Point(24, 8);
            this.btnIns1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns1.Name = "btnIns1";
            this.btnIns1.Size = new System.Drawing.Size(28, 27);
            this.btnIns1.TabIndex = 1;
            this.btnIns1.Tag = "0";
            this.btnIns1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.Click += new System.EventHandler(this.btnIns1_Click);
            // 
            // txtcheqid
            // 
            this.txtcheqid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqid.CaptionStyle.CaptionSize = 100;
            this.txtcheqid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqid.CaptionStyle.TextStyle.Text = "شماره چک";
            this.txtcheqid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqid.Location = new System.Drawing.Point(73, 37);
            this.txtcheqid.Name = "txtcheqid";
            this.txtcheqid.Size = new System.Drawing.Size(209, 27);
            this.txtcheqid.TabIndex = 4;
            this.txtcheqid.Tag = "0";
            this.txtcheqid.ValidationStyle.AcceptsTab = true;
            this.txtcheqid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqid.ValidationStyle.PasswordChar = '\0';
            this.txtcheqid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqid.Value = 0;
            this.txtcheqid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // lblQuan
            // 
            this.lblQuan.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblQuan.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblQuan.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblQuan.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblQuan.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblQuan.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.Transparent;
            this.lblQuan.FlashStyle = paintStyle1;
            this.lblQuan.Location = new System.Drawing.Point(11, 125);
            this.lblQuan.Name = "lblQuan";
            this.lblQuan.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblQuan.Size = new System.Drawing.Size(691, 27);
            this.lblQuan.TabIndex = 9;
            this.lblQuan.TabStop = false;
            this.lblQuan.Tag = "0";
            this.lblQuan.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblQuan.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuan.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblQuan.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblQuan.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtcsid
            // 
            this.txtcsid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsid.CaptionStyle.CaptionSize = 95;
            this.txtcsid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsid.CaptionStyle.TextStyle.Text = "دسته چک";
            this.txtcsid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsid.Location = new System.Drawing.Point(365, 37);
            this.txtcsid.Name = "txtcsid";
            this.txtcsid.Size = new System.Drawing.Size(337, 27);
            this.txtcsid.TabIndex = 2;
            this.txtcsid.Tag = "0";
            this.txtcsid.ValidationStyle.AcceptsTab = true;
            this.txtcsid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtcsid.ValidationStyle.PasswordChar = '\0';
            this.txtcsid.ValidationStyle.ReadOnly = true;
            this.txtcsid.Value = "";
            this.txtcsid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            this.txtcsid.Enter += new System.EventHandler(this.txtaccid_Enter);
            // 
            // txtcheqnote
            // 
            this.txtcheqnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqnote.CaptionStyle.CaptionSize = 100;
            this.txtcheqnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqnote.CaptionStyle.TextStyle.Text = "توضیحات";
            this.txtcheqnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqnote.Location = new System.Drawing.Point(310, 155);
            this.txtcheqnote.Name = "txtcheqnote";
            this.txtcheqnote.Size = new System.Drawing.Size(392, 27);
            this.txtcheqnote.TabIndex = 10;
            this.txtcheqnote.Tag = "0";
            this.txtcheqnote.ValidationStyle.AcceptsTab = true;
            this.txtcheqnote.ValidationStyle.Multiline = true;
            this.txtcheqnote.ValidationStyle.PasswordChar = '\0';
            this.txtcheqnote.Value = "";
            this.txtcheqnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 95;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.Location = new System.Drawing.Point(53, 8);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(649, 27);
            this.txtaccid.TabIndex = 0;
            this.txtaccid.Tag = "1";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.ValidationStyle.ReadOnly = true;
            this.txtaccid.Value = "0";
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtinmode
            // 
            this.txtinmode.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtinmode.CaptionStyle.CaptionSize = 100;
            this.txtinmode.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtinmode.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtinmode.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmode.CaptionStyle.TextStyle.Text = "در وجه";
            this.txtinmode.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmode.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtinmode.Location = new System.Drawing.Point(8, 95);
            this.txtinmode.Name = "txtinmode";
            this.txtinmode.Size = new System.Drawing.Size(274, 27);
            this.txtinmode.TabIndex = 8;
            this.txtinmode.Tag = "1";
            this.txtinmode.ValidationStyle.AcceptsTab = true;
            this.txtinmode.ValidationStyle.PasswordChar = '\0';
            this.txtinmode.Value = "";
            this.txtinmode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtcheqquan
            // 
            this.txtcheqquan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqquan.CaptionStyle.CaptionSize = 100;
            this.txtcheqquan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqquan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqquan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquan.CaptionStyle.TextStyle.Text = "مبلغ چک";
            this.txtcheqquan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqquan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqquan.Location = new System.Drawing.Point(458, 95);
            this.txtcheqquan.Name = "txtcheqquan";
            this.txtcheqquan.Size = new System.Drawing.Size(244, 27);
            this.txtcheqquan.TabIndex = 7;
            this.txtcheqquan.Tag = "1";
            this.txtcheqquan.ValidationStyle.AcceptsTab = true;
            this.txtcheqquan.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcheqquan.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcheqquan.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqquan.ValidationStyle.PasswordChar = '\0';
            this.txtcheqquan.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqquan.Value = 0;
            this.txtcheqquan.TextChanged += new System.EventHandler(this.txtcheqquan_TextChanged);
            this.txtcheqquan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcheqquan_KeyPress);
            // 
            // cbocheqstate
            // 
            // 
            // 
            // 
            this.cbocheqstate.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbocheqstate.CaptionStyle.CaptionSize = 100;
            this.cbocheqstate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqstate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbocheqstate.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqstate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqstate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqstate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.CaptionStyle.TextStyle.Text = "وضعیت چک";
            this.cbocheqstate.CheckedDisplaySeparator = ',';
            this.cbocheqstate.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqstate.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbocheqstate.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqstate.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbocheqstate.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbocheqstate.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cbocheqstate.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbocheqstate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqstate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbocheqstate.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqstate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = ((byte)(0));
            elListBoxItem1.Value = "انتظار";
            elListBoxItem2.Key = ((byte)(1));
            elListBoxItem2.Value = "ضمانت";
            elListBoxItem3.Key = ((byte)(2));
            elListBoxItem3.Value = "وصول";
            elListBoxItem4.Key = ((byte)(3));
            elListBoxItem4.Value = "برگشتی";
            elListBoxItem5.Key = ((byte)(4));
            elListBoxItem5.Value = "باطل";
            this.cbocheqstate.Items.Add(elListBoxItem1);
            this.cbocheqstate.Items.Add(elListBoxItem2);
            this.cbocheqstate.Items.Add(elListBoxItem3);
            this.cbocheqstate.Items.Add(elListBoxItem4);
            this.cbocheqstate.Items.Add(elListBoxItem5);
            this.cbocheqstate.Location = new System.Drawing.Point(55, 155);
            this.cbocheqstate.Name = "cbocheqstate";
            this.cbocheqstate.Size = new System.Drawing.Size(227, 27);
            this.cbocheqstate.TabIndex = 11;
            this.cbocheqstate.Tag = "1";
            this.cbocheqstate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtcheqdate
            // 
            this.txtcheqdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtcheqdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqdate.CaptionStyle.CaptionSize = 100;
            this.txtcheqdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqdate.CaptionStyle.TextStyle.Text = "تاریخ سررسید";
            this.txtcheqdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqdate.Location = new System.Drawing.Point(73, 66);
            this.txtcheqdate.Name = "txtcheqdate";
            this.txtcheqdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtcheqdate.Size = new System.Drawing.Size(209, 27);
            this.txtcheqdate.TabIndex = 6;
            this.txtcheqdate.Tag = "1";
            this.txtcheqdate.ValidationStyle.AcceptsTab = true;
            this.txtcheqdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtcheqdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtcheqdate.ValidationStyle.PasswordChar = '\0';
            this.txtcheqdate.Value = "";
            this.txtcheqdate.Leave += new System.EventHandler(this.txtcheqdate_Leave);
            this.txtcheqdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // txtcheqexpo
            // 
            this.txtcheqexpo.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtcheqexpo.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqexpo.CaptionStyle.CaptionSize = 100;
            this.txtcheqexpo.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqexpo.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqexpo.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqexpo.CaptionStyle.TextStyle.Text = "تاریخ صدور";
            this.txtcheqexpo.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqexpo.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqexpo.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqexpo.Location = new System.Drawing.Point(502, 66);
            this.txtcheqexpo.Name = "txtcheqexpo";
            this.txtcheqexpo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtcheqexpo.Size = new System.Drawing.Size(200, 27);
            this.txtcheqexpo.TabIndex = 5;
            this.txtcheqexpo.Tag = "1";
            this.txtcheqexpo.ValidationStyle.AcceptsTab = true;
            this.txtcheqexpo.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtcheqexpo.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtcheqexpo.ValidationStyle.PasswordChar = '\0';
            this.txtcheqexpo.Value = "";
            this.txtcheqexpo.Leave += new System.EventHandler(this.txtcheqexpo_Leave);
            this.txtcheqexpo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // cbocheqtype
            // 
            // 
            // 
            // 
            this.cbocheqtype.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbocheqtype.CaptionStyle.CaptionSize = 100;
            this.cbocheqtype.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqtype.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbocheqtype.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqtype.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqtype.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbocheqtype.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.CaptionStyle.TextStyle.Text = "نوع چک";
            this.cbocheqtype.CheckedDisplaySeparator = ',';
            this.cbocheqtype.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbocheqtype.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbocheqtype.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbocheqtype.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbocheqtype.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles2.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles2.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbocheqtype.DropDownItemSelectionStyle = elListBoxSelectionStyles2;
            this.cbocheqtype.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbocheqtype.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbocheqtype.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbocheqtype.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbocheqtype.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem6.Key = ((byte)(0));
            elListBoxItem6.Value = "صادره";
            elListBoxItem7.Key = ((byte)(1));
            elListBoxItem7.Value = "دریافتی";
            this.cbocheqtype.Items.Add(elListBoxItem6);
            this.cbocheqtype.Items.Add(elListBoxItem7);
            this.cbocheqtype.Location = new System.Drawing.Point(492, 5);
            this.cbocheqtype.Name = "cbocheqtype";
            this.cbocheqtype.Size = new System.Drawing.Size(210, 27);
            this.cbocheqtype.TabIndex = 0;
            this.cbocheqtype.Tag = "1";
            this.cbocheqtype.SelectedIndexChanged += new System.EventHandler(this.cbocheqtype_SelectedIndexChanged);
            this.cbocheqtype.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(90, 7);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(11, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(249, 7);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(170, 7);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(329, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(408, 7);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // contextOperate
            // 
            this.contextOperate.Name = "contextOperate";
            this.contextOperate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextOperate.Size = new System.Drawing.Size(61, 4);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel2.Controls.Add(this.lblsum);
            this.elRichPanel2.Controls.Add(this.label1);
            this.elRichPanel2.Controls.Add(this.cheqDataGrid);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.FooterStyle.Height = 24;
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel2.Location = new System.Drawing.Point(6, 263);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 16, 1, 24);
            this.elRichPanel2.Size = new System.Drawing.Size(708, 285);
            this.elRichPanel2.TabIndex = 2;
            this.elRichPanel2.Tag = "0";
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblsum.ForeColor = System.Drawing.Color.Blue;
            this.lblsum.Location = new System.Drawing.Point(9, 266);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(0, 15);
            this.lblsum.TabIndex = 5;
            this.lblsum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "جمع کل:";
            // 
            // cheqDataGrid
            // 
            this.cheqDataGrid.AllowUserToAddRows = false;
            this.cheqDataGrid.AllowUserToDeleteRows = false;
            this.cheqDataGrid.AllowUserToResizeColumns = false;
            this.cheqDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cheqDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.cheqDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.cheqDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cheqDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cheqDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.cheqDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.cheqDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.cheqDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.idcs,
            this.cheqtype,
            this.cheqid,
            this.csid,
            this.accid,
            this.cheqexpo,
            this.cheqdate,
            this.cheqquan,
            this.inmode,
            this.cheqstate,
            this.cheqnote});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.cheqDataGrid.DefaultCellStyle = dataGridViewCellStyle4;
            this.cheqDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cheqDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.cheqDataGrid.Location = new System.Drawing.Point(1, 16);
            this.cheqDataGrid.MultiSelect = false;
            this.cheqDataGrid.Name = "cheqDataGrid";
            this.cheqDataGrid.ReadOnly = true;
            this.cheqDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.cheqDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.cheqDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.cheqDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.cheqDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.cheqDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.cheqDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.cheqDataGrid.ShowCellErrors = false;
            this.cheqDataGrid.ShowCellToolTips = false;
            this.cheqDataGrid.ShowEditingIcon = false;
            this.cheqDataGrid.ShowRowErrors = false;
            this.cheqDataGrid.Size = new System.Drawing.Size(706, 245);
            this.cheqDataGrid.TabIndex = 0;
            this.cheqDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.cheqDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cheqDataGrid_MouseClick);
            this.cheqDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cheqDataGrid_CellClick);
            this.cheqDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cheqDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // idcs
            // 
            this.idcs.DataPropertyName = "idcs";
            this.idcs.HeaderText = "کد";
            this.idcs.Name = "idcs";
            this.idcs.ReadOnly = true;
            this.idcs.Visible = false;
            // 
            // cheqtype
            // 
            this.cheqtype.DataPropertyName = "cheqtype";
            this.cheqtype.HeaderText = "نوع چک";
            this.cheqtype.Name = "cheqtype";
            this.cheqtype.ReadOnly = true;
            this.cheqtype.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cheqtype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cheqid
            // 
            this.cheqid.DataPropertyName = "cheqid";
            this.cheqid.HeaderText = "شماره چک";
            this.cheqid.Name = "cheqid";
            this.cheqid.ReadOnly = true;
            // 
            // csid
            // 
            this.csid.DataPropertyName = "csid";
            this.csid.HeaderText = "کد دسته چک";
            this.csid.Name = "csid";
            this.csid.ReadOnly = true;
            this.csid.Visible = false;
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            // 
            // cheqexpo
            // 
            this.cheqexpo.DataPropertyName = "cheqexpo";
            this.cheqexpo.HeaderText = "تاریخ صدور";
            this.cheqexpo.Name = "cheqexpo";
            this.cheqexpo.ReadOnly = true;
            // 
            // cheqdate
            // 
            this.cheqdate.DataPropertyName = "cheqdate";
            this.cheqdate.HeaderText = "تاریخ سررسید";
            this.cheqdate.Name = "cheqdate";
            this.cheqdate.ReadOnly = true;
            // 
            // cheqquan
            // 
            this.cheqquan.DataPropertyName = "cheqquan";
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = null;
            this.cheqquan.DefaultCellStyle = dataGridViewCellStyle3;
            this.cheqquan.HeaderText = "مبلغ چک";
            this.cheqquan.Name = "cheqquan";
            this.cheqquan.ReadOnly = true;
            // 
            // inmode
            // 
            this.inmode.DataPropertyName = "inmode";
            this.inmode.HeaderText = "در وجه";
            this.inmode.Name = "inmode";
            this.inmode.ReadOnly = true;
            this.inmode.Visible = false;
            // 
            // cheqstate
            // 
            this.cheqstate.DataPropertyName = "cheqstate";
            this.cheqstate.HeaderText = "وضعیت چک";
            this.cheqstate.Name = "cheqstate";
            this.cheqstate.ReadOnly = true;
            // 
            // cheqnote
            // 
            this.cheqnote.DataPropertyName = "cheqnote";
            this.cheqnote.HeaderText = "توضیحات";
            this.cheqnote.Name = "cheqnote";
            this.cheqnote.ReadOnly = true;
            this.cheqnote.Visible = false;
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.elButton6);
            this.elContainer2.Controls.Add(this.elButton8);
            this.elContainer2.Controls.Add(this.btnNew);
            this.elContainer2.Controls.Add(this.btnSave);
            this.elContainer2.Controls.Add(this.btnDelete);
            this.elContainer2.Controls.Add(this.btnAbort);
            this.elContainer2.Controls.Add(this.btnEdit);
            this.elContainer2.Controls.Add(this.btnClose);
            this.elContainer2.Location = new System.Drawing.Point(119, 554);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(489, 41);
            this.elContainer2.TabIndex = 3;
            this.elContainer2.Tag = "0";
            this.elContainer2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elButton6
            // 
            this.elButton6.Location = new System.Drawing.Point(0, 0);
            this.elButton6.Name = "elButton6";
            this.elButton6.Size = new System.Drawing.Size(0, 0);
            this.elButton6.TabIndex = 5;
            // 
            // elButton8
            // 
            this.elButton8.Location = new System.Drawing.Point(0, 0);
            this.elButton8.Name = "elButton8";
            this.elButton8.Size = new System.Drawing.Size(0, 0);
            this.elButton8.TabIndex = 5;
            // 
            // backType
            // 
            this.backType.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backType.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backType.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backType.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backType.Controls.Add(this.cbocheqtype);
            this.backType.Location = new System.Drawing.Point(6, 33);
            this.backType.Name = "backType";
            this.backType.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backType.Size = new System.Drawing.Size(708, 37);
            this.backType.TabIndex = 0;
            this.backType.Tag = "0";
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(6, 8, 708, 249);
            this.expandPanel.Location = new System.Drawing.Point(6, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(708, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 4;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.btnInsCH);
            this.BackSearch.Controls.Add(this.cbotypeCH);
            this.BackSearch.Controls.Add(this.rdochdate);
            this.BackSearch.Controls.Add(this.txtstartdate);
            this.BackSearch.Controls.Add(this.rdochExpo);
            this.BackSearch.Controls.Add(this.txtenddate);
            this.BackSearch.Controls.Add(this.txtaccidCH);
            this.BackSearch.Controls.Add(this.txtcsidCH);
            this.BackSearch.Controls.Add(this.txtcheqquanmax);
            this.BackSearch.Controls.Add(this.cbostateCH);
            this.BackSearch.Controls.Add(this.txtinmodeCH);
            this.BackSearch.Controls.Add(this.txtcheqquanmin);
            this.BackSearch.Location = new System.Drawing.Point(9, 33);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(692, 179);
            this.BackSearch.TabIndex = 23;
            // 
            // btnInsCH
            // 
            this.btnInsCH.BackgroundImageStyle.Alpha = 100;
            this.btnInsCH.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnInsCH.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCH.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsCH.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsCH.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsCH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsCH.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsCH.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsCH.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCH.Location = new System.Drawing.Point(287, 62);
            this.btnInsCH.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsCH.Name = "btnInsCH";
            this.btnInsCH.Size = new System.Drawing.Size(28, 27);
            this.btnInsCH.TabIndex = 3;
            this.btnInsCH.Tag = "0";
            this.btnInsCH.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsCH.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsCH.Click += new System.EventHandler(this.btnInsCH_Click);
            // 
            // cbotypeCH
            // 
            // 
            // 
            // 
            this.cbotypeCH.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbotypeCH.CaptionStyle.CaptionSize = 100;
            this.cbotypeCH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbotypeCH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbotypeCH.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbotypeCH.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbotypeCH.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbotypeCH.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbotypeCH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbotypeCH.CaptionStyle.TextStyle.Text = "نوع چک";
            this.cbotypeCH.CheckedDisplaySeparator = ',';
            this.cbotypeCH.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbotypeCH.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbotypeCH.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbotypeCH.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbotypeCH.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles3.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles3.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbotypeCH.DropDownItemSelectionStyle = elListBoxSelectionStyles3;
            this.cbotypeCH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbotypeCH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbotypeCH.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbotypeCH.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            elListBoxItem8.Key = ((byte)(0));
            elListBoxItem8.Value = "صادره";
            elListBoxItem9.Key = ((byte)(1));
            elListBoxItem9.Value = "دریافتی";
            this.cbotypeCH.Items.Add(elListBoxItem8);
            this.cbotypeCH.Items.Add(elListBoxItem9);
            this.cbotypeCH.Location = new System.Drawing.Point(475, 6);
            this.cbotypeCH.Name = "cbotypeCH";
            this.cbotypeCH.Size = new System.Drawing.Size(210, 27);
            this.cbotypeCH.TabIndex = 0;
            this.cbotypeCH.Tag = "1";
            this.cbotypeCH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // rdochdate
            // 
            this.rdochdate.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdochdate.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdochdate.Location = new System.Drawing.Point(182, 62);
            this.rdochdate.Name = "rdochdate";
            this.rdochdate.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdochdate.Size = new System.Drawing.Size(98, 27);
            this.rdochdate.TabIndex = 5;
            this.rdochdate.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdochdate.TextStyle.Text = "تاریخ سررسید";
            this.rdochdate.Value = false;
            this.rdochdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton3);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.CaptionSize = 70;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(6, 33);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(170, 27);
            this.txtstartdate.TabIndex = 6;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // elEntryBoxButton3
            // 
            this.elEntryBoxButton3.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton3.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton3.DropDownContextMenuStrip = this.contextDate;
            // 
            // rdochExpo
            // 
            this.rdochExpo.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdochExpo.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdochExpo.Location = new System.Drawing.Point(182, 33);
            this.rdochExpo.Name = "rdochExpo";
            this.rdochExpo.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdochExpo.Size = new System.Drawing.Size(98, 27);
            this.rdochExpo.TabIndex = 4;
            this.rdochExpo.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdochExpo.TextStyle.Text = "تاریخ صدور";
            this.rdochExpo.Value = false;
            this.rdochExpo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.CaptionSize = 70;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(7, 62);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(170, 27);
            this.txtenddate.TabIndex = 7;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtaccidCH
            // 
            this.txtaccidCH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccidCH.CaptionStyle.CaptionSize = 100;
            this.txtaccidCH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccidCH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccidCH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidCH.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccidCH.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtaccidCH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidCH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccidCH.Location = new System.Drawing.Point(316, 34);
            this.txtaccidCH.Name = "txtaccidCH";
            this.txtaccidCH.Size = new System.Drawing.Size(369, 27);
            this.txtaccidCH.TabIndex = 1;
            this.txtaccidCH.Tag = "1";
            this.txtaccidCH.ValidationStyle.AcceptsTab = true;
            this.txtaccidCH.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccidCH.ValidationStyle.PasswordChar = '\0';
            this.txtaccidCH.Value = "";
            this.txtaccidCH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtcsidCH
            // 
            this.txtcsidCH.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsidCH.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtcsidCH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsidCH.CaptionStyle.CaptionSize = 95;
            this.txtcsidCH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsidCH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsidCH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsidCH.CaptionStyle.TextStyle.Text = "سریال دسته چک";
            this.txtcsidCH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsidCH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsidCH.Location = new System.Drawing.Point(316, 62);
            this.txtcsidCH.Name = "txtcsidCH";
            this.txtcsidCH.Size = new System.Drawing.Size(370, 27);
            this.txtcsidCH.TabIndex = 2;
            this.txtcsidCH.Tag = "0";
            this.txtcsidCH.ValidationStyle.AcceptsTab = true;
            this.txtcsidCH.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtcsidCH.ValidationStyle.PasswordChar = '\0';
            this.txtcsidCH.Value = "";
            this.txtcsidCH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            this.txtcsidCH.Enter += new System.EventHandler(this.txtcsid_Enter);
            // 
            // txtcheqquanmax
            // 
            this.txtcheqquanmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqquanmax.CaptionStyle.CaptionSize = 100;
            this.txtcheqquanmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqquanmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqquanmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmax.CaptionStyle.TextStyle.Text = "مبلغ چک حداکثر";
            this.txtcheqquanmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqquanmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqquanmax.Location = new System.Drawing.Point(36, 118);
            this.txtcheqquanmax.Name = "txtcheqquanmax";
            this.txtcheqquanmax.Size = new System.Drawing.Size(244, 27);
            this.txtcheqquanmax.TabIndex = 10;
            this.txtcheqquanmax.Tag = "1";
            this.txtcheqquanmax.ValidationStyle.AcceptsTab = true;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcheqquanmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqquanmax.ValidationStyle.PasswordChar = '\0';
            this.txtcheqquanmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqquanmax.Value = 0;
            this.txtcheqquanmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcheqquan_KeyPress);
            // 
            // cbostateCH
            // 
            // 
            // 
            // 
            this.cbostateCH.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbostateCH.CaptionStyle.CaptionSize = 100;
            this.cbostateCH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbostateCH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbostateCH.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbostateCH.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbostateCH.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbostateCH.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbostateCH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbostateCH.CaptionStyle.TextStyle.Text = "وضعیت چک";
            this.cbostateCH.CheckedDisplaySeparator = ',';
            this.cbostateCH.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbostateCH.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbostateCH.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbostateCH.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbostateCH.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles4.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles4.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbostateCH.DropDownItemSelectionStyle = elListBoxSelectionStyles4;
            this.cbostateCH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbostateCH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbostateCH.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbostateCH.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem10.Key = ((byte)(0));
            elListBoxItem10.Value = "انتظار";
            elListBoxItem11.Key = ((byte)(1));
            elListBoxItem11.Value = "ضمانت";
            elListBoxItem12.Key = ((byte)(2));
            elListBoxItem12.Value = "وصول";
            elListBoxItem13.Key = ((byte)(3));
            elListBoxItem13.Value = "برگشتی";
            elListBoxItem14.Key = ((byte)(4));
            elListBoxItem14.Value = "باطل";
            this.cbostateCH.Items.Add(elListBoxItem10);
            this.cbostateCH.Items.Add(elListBoxItem11);
            this.cbostateCH.Items.Add(elListBoxItem12);
            this.cbostateCH.Items.Add(elListBoxItem13);
            this.cbostateCH.Items.Add(elListBoxItem14);
            this.cbostateCH.Location = new System.Drawing.Point(458, 146);
            this.cbostateCH.Name = "cbostateCH";
            this.cbostateCH.Size = new System.Drawing.Size(227, 27);
            this.cbostateCH.TabIndex = 11;
            this.cbostateCH.Tag = "1";
            this.cbostateCH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtinmodeCH
            // 
            this.txtinmodeCH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtinmodeCH.CaptionStyle.CaptionSize = 100;
            this.txtinmodeCH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtinmodeCH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtinmodeCH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmodeCH.CaptionStyle.TextStyle.Text = "در وجه";
            this.txtinmodeCH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinmodeCH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtinmodeCH.Location = new System.Drawing.Point(411, 90);
            this.txtinmodeCH.Name = "txtinmodeCH";
            this.txtinmodeCH.Size = new System.Drawing.Size(274, 27);
            this.txtinmodeCH.TabIndex = 8;
            this.txtinmodeCH.Tag = "1";
            this.txtinmodeCH.ValidationStyle.AcceptsTab = true;
            this.txtinmodeCH.ValidationStyle.PasswordChar = '\0';
            this.txtinmodeCH.Value = "";
            this.txtinmodeCH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccid_KeyPress);
            // 
            // txtcheqquanmin
            // 
            this.txtcheqquanmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcheqquanmin.CaptionStyle.CaptionSize = 100;
            this.txtcheqquanmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcheqquanmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcheqquanmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmin.CaptionStyle.TextStyle.Text = "مبلغ چک حداقل";
            this.txtcheqquanmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcheqquanmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcheqquanmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcheqquanmin.Location = new System.Drawing.Point(441, 118);
            this.txtcheqquanmin.Name = "txtcheqquanmin";
            this.txtcheqquanmin.Size = new System.Drawing.Size(244, 27);
            this.txtcheqquanmin.TabIndex = 9;
            this.txtcheqquanmin.Tag = "1";
            this.txtcheqquanmin.ValidationStyle.AcceptsTab = true;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtcheqquanmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcheqquanmin.ValidationStyle.PasswordChar = '\0';
            this.txtcheqquanmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcheqquanmin.Value = 0;
            this.txtcheqquanmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcheqquan_KeyPress);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(83, 216);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 13;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image10")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(8, 216);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 14;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmCheq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 603);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.backType);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elRichPanel2);
            this.Controls.Add(this.elContainer2);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCheq";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "چکهای بانکی";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmCheq_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqexpo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbocheqtype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.elRichPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cheqDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backType)).EndInit();
            this.backType.ResumeLayout(false);
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnInsCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbotypeCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdochExpo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsidCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbostateCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtinmodeCH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcheqquanmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private System.Windows.Forms.ContextMenuStrip contextOperate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqexpo;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqnote;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbocheqstate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtinmode;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqquan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView cheqDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbocheqtype;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton6;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton8;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsid;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblQuan;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backType;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqid;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcs;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqid;
        private System.Windows.Forms.DataGridViewTextBoxColumn csid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqexpo;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn inmode;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqstate;
        private System.Windows.Forms.DataGridViewTextBoxColumn cheqnote;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns1;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdochdate;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdochExpo;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqquanmax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtinmodeCH;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcheqquanmin;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbostateCH;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbotypeCH;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsidCH;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccidCH;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsCH;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label label1;
    }
}