﻿namespace FamilyAccount
{
    partial class FrmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmSetting aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetting));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.btnOk = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.ShowLogin = new Klik.Windows.Forms.v1.EntryLib.ELCheckBox();
            this.txteventTime = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.Startup = new Klik.Windows.Forms.v1.EntryLib.ELCheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txteventTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Startup)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // btnOk
            // 
            this.btnOk.BackgroundImageStyle.Alpha = 100;
            this.btnOk.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOk.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnOk.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnOk.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOk.Location = new System.Drawing.Point(8, 118);
            this.btnOk.Name = "btnOk";
            this.btnOk.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnOk.Size = new System.Drawing.Size(66, 27);
            this.btnOk.TabIndex = 6;
            this.btnOk.Tag = "True";
            this.btnOk.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.TextStyle.Text = "تائید";
            this.btnOk.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // ShowLogin
            // 
            this.ShowLogin.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.ShowLogin.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.ShowLogin.Location = new System.Drawing.Point(261, 40);
            this.ShowLogin.Name = "ShowLogin";
            this.ShowLogin.Size = new System.Drawing.Size(134, 23);
            this.ShowLogin.TabIndex = 7;
            this.ShowLogin.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowLogin.TextStyle.Text = " Login نمایش پنجره";
            this.ShowLogin.Value = false;
            // 
            // txteventTime
            // 
            this.txteventTime.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txteventTime.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txteventTime.CaptionStyle.CaptionSize = 225;
            this.txteventTime.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txteventTime.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txteventTime.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txteventTime.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txteventTime.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txteventTime.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteventTime.CaptionStyle.TextStyle.Text = "مدت زمان باقیمانده برای اعلان رویدادها";
            this.txteventTime.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteventTime.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txteventTime.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txteventTime.Location = new System.Drawing.Point(114, 69);
            this.txteventTime.Name = "txteventTime";
            this.txteventTime.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txteventTime.Size = new System.Drawing.Size(281, 27);
            this.txteventTime.TabIndex = 8;
            this.txteventTime.Tag = "0";
            this.txteventTime.ValidationStyle.AcceptsTab = true;
            this.txteventTime.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txteventTime.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txteventTime.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Numeric;
            this.txteventTime.ValidationStyle.NumericValidationStyle.Minimum = "1";
            this.txteventTime.ValidationStyle.PasswordChar = '\0';
            this.txteventTime.ValidationStyle.ReadOnly = true;
            this.txteventTime.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txteventTime.Value = 5;
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.Spin;
            // 
            // Startup
            // 
            this.Startup.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.Startup.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.Startup.Location = new System.Drawing.Point(224, 12);
            this.Startup.Name = "Startup";
            this.Startup.Size = new System.Drawing.Size(171, 23);
            this.Startup.TabIndex = 9;
            this.Startup.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startup.TextStyle.Text = "اجرای برنامه در شروع ویندوز";
            this.Startup.Value = false;
            // 
            // FrmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 154);
            this.ControlBox = false;
            this.Controls.Add(this.Startup);
            this.Controls.Add(this.txteventTime);
            this.Controls.Add(this.ShowLogin);
            this.Controls.Add(this.btnOk);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSetting";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "تنظیمات نرم افزار";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmSetting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txteventTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Startup)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnOk;
        private Klik.Windows.Forms.v1.EntryLib.ELCheckBox ShowLogin;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txteventTime;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELCheckBox Startup;
    }
}