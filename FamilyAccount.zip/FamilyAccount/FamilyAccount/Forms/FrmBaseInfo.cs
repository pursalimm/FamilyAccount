﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FamilyAccount
{
    public partial class FrmBaseInfo : Form
    {
        string idSel = "";
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public FrmBaseInfo()
        {
            InitializeComponent();
        }

        public static FrmBaseInfo Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmBaseInfo();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: ado.ClearControl(Tab0);
                    txtbankname.Enabled = true;
                    txtbankname.Focus();
                    break;
                case 1: ado.ClearControl(Tab1);
                    txtaccname.Enabled = true;
                    txtaccname.Focus();
                    break;
                case 2: ado.ClearControl(Tab2);
                    txtsalname.Enabled = true;
                    txtsalname.Focus();
                    break;
                case 3: ado.ClearControl(Tab3);
                    txtcostname.Enabled = true;
                    txtcostname.Focus();
                    break;
                case 4: ado.ClearControl(Tab4);
                    txtactname.Enabled = true;
                    txtactname.Focus();
                    break;
            }
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: if (ado.ValidateControl(Tab0)) return;
                    cmd.CommandText = "insert into basebank values(@bankname)";
                    cmd.Parameters.Add("@bankname", SqlDbType.NVarChar).Value = txtbankname.Text;
                    break;
                case 1: if (ado.ValidateControl(Tab1)) return;
                    cmd.CommandText = "insert into baseacc values(@accname)";
                    cmd.Parameters.Add("@accname", SqlDbType.NVarChar).Value = txtaccname.Text;
                    break;
                case 2: if (ado.ValidateControl(Tab2)) return;
                    cmd.CommandText = "insert into basesal values(@salname)";
                    cmd.Parameters.Add("@salname", SqlDbType.NVarChar).Value = txtsalname.Text;
                    break;
                case 3: if (ado.ValidateControl(Tab3)) return;
                    cmd.CommandText = "insert into basecost values(@costname)";
                    cmd.Parameters.Add("@costname", SqlDbType.NVarChar).Value = txtcostname.Text;
                    break;
                case 4: if (ado.ValidateControl(Tab4)) return;
                    cmd.CommandText = "insert into baseact values(@actname)";
                    cmd.Parameters.Add("@actname", SqlDbType.NVarChar).Value = txtactname.Text;
                    break;
            }
            if (cmd.CommandText != "")
            {
                if (ado.insert(cmd, CommandType.Text, cmd.CommandText))
                    RefreshDataGrid();
                btnAbort_Click(sender, e);
            }
        }

        public void RefreshDataGrid()
        {
            DataSet ds;
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0:
                    ds = ado.select("select * from basebank");
                    bbankDataGrid.DataSource = ds.Tables[0];
                    break;
                case 1:
                    ds = ado.select("select * from baseacc");
                    baccDataGrid.DataSource = ds.Tables[0];
                    break;
                case 2:
                    ds = ado.select("select * from basesal");
                    bsalDataGrid.DataSource = ds.Tables[0];
                    break;
                case 3:
                    ds = ado.select("select * from basecost");
                    bcostDataGrid.DataSource = ds.Tables[0];
                    break;
                case 4:
                    ds = ado.select("select * from baseact");
                    bactDataGrid.DataSource = ds.Tables[0];
                    break;
            }
        }

        private void FrmBaseInfo_Load(object sender, EventArgs e)
        {
            DataSet ds;
            ds = ado.select("select * from basebank");
            bbankDataGrid.DataSource = ds.Tables[0];
            ds = ado.select("select * from baseacc");
            baccDataGrid.DataSource = ds.Tables[0];
            ds = ado.select("select * from basesal");
            bsalDataGrid.DataSource = ds.Tables[0];
            ds = ado.select("select * from basecost");
            bcostDataGrid.DataSource = ds.Tables[0];
            ds = ado.select("select * from baseact");
            bactDataGrid.DataSource = ds.Tables[0];
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: if (ado.ValidateControl(Tab0)) return;
                    cmd.CommandText = "update basebank set bankname=@bankname where bbid=@bbid";
                    cmd.Parameters.Add("@bbid", SqlDbType.Int).Value = idSel;
                    cmd.Parameters.Add("@bankname", SqlDbType.NVarChar).Value = txtbankname.Text;
                    break;
                case 1: if (ado.ValidateControl(Tab1)) return;
                    cmd.CommandText = "update baseacc set accname=@accname where baid=@baid";
                    cmd.Parameters.Add("@baid", SqlDbType.Int).Value = idSel;
                    cmd.Parameters.Add("@accname", SqlDbType.NVarChar).Value = txtaccname.Text;
                    break;
                case 2: if (ado.ValidateControl(Tab2)) return;
                    cmd.CommandText = "update basesal set salname=@salname where bsid=@bsid";
                    cmd.Parameters.Add("@bsid", SqlDbType.Int).Value = idSel;
                    cmd.Parameters.Add("@salname", SqlDbType.NVarChar).Value = txtsalname.Text;
                    break;
                case 3: if (ado.ValidateControl(Tab3)) return;
                    cmd.CommandText = "update basecost set costname=@costname where bcid=@bcid";
                    cmd.Parameters.Add("@bcid", SqlDbType.Int).Value = idSel;
                    cmd.Parameters.Add("@costname", SqlDbType.NVarChar).Value = txtcostname.Text;
                    break;
                case 4: if (ado.ValidateControl(Tab4)) return;
                    cmd.CommandText = "update baseact set actname=@actname where baid=@baid";
                    cmd.Parameters.Add("@baid", SqlDbType.Int).Value = idSel;
                    cmd.Parameters.Add("@actname", SqlDbType.NVarChar).Value = txtactname.Text;
                    break;
            }
            if (cmd.CommandText != "")
            {
                if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                    RefreshDataGrid();
                btnAbort_Click(sender, e);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0:
                    cmd.CommandText = "delete from basebank where bbid=@bbid";
                    cmd.Parameters.Add("@bbid", SqlDbType.Int).Value = idSel;
                    break;
                case 1:
                    cmd.CommandText = "delete from baseacc where baid=@baid";
                    cmd.Parameters.Add("@baid", SqlDbType.Int).Value = idSel;
                    break;
                case 2:
                    cmd.CommandText = "delete from basesal where bsid=@bsid";
                    cmd.Parameters.Add("@bsid", SqlDbType.Int).Value = idSel;
                    break;
                case 3:
                    cmd.CommandText = "delete from basecost where bcid=@bcid";
                    cmd.Parameters.Add("@bcid", SqlDbType.Int).Value = idSel;
                    break;
                case 4:
                    cmd.CommandText = "delete from baseact where baid=@baid";
                    cmd.Parameters.Add("@baid", SqlDbType.Int).Value = idSel;
                    break;
            }
            if (cmd.CommandText != "")
            {
                if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
                    if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                        RefreshDataGrid();
                btnAbort_Click(sender, e);
            }
        }

        private void txtpid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void tabBase_SelectedTabPageChanged(object sender, EventArgs e)
        {
            idSel = "";
            btnAbort_Click(sender, e);
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: ado.ClearControl(Tab0);
                    txtbankname.Enabled = false;
                    break;
                case 1: ado.ClearControl(Tab1);
                    txtaccname.Enabled = false;
                    break;
                case 2: ado.ClearControl(Tab2);
                    txtsalname.Enabled = false;
                    break;
                case 3: ado.ClearControl(Tab3);
                    txtcostname.Enabled = false;
                    break;
                case 4: ado.ClearControl(Tab4);
                    txtactname.Enabled = false;
                    break;
            }
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
        }

        #region Select Edit Delete
        private void bbankDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bbankDataGrid.RowCount > 0)
            {
                if (bbankDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    txtbankname.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    txtbankname.Enabled = false;
                }
            }
        }

        private void baccDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (baccDataGrid.RowCount > 0)
            {
                if (baccDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    txtaccname.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    txtaccname.Enabled = false;
                }
            }
        }

        private void bsalDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bsalDataGrid.RowCount > 0)
            {
                if (bsalDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    txtsalname.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    txtsalname.Enabled = false;
                }
            }
        }

        private void bcostDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bcostDataGrid.RowCount > 0)
            {
                if (bcostDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    txtcostname.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    txtcostname.Enabled = false;
                }
            }
        }

        private void bactDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (bactDataGrid.RowCount > 0)
            {
                if (bactDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    txtactname.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    txtactname.Enabled = false;
                }
            }
        }
        #endregion

        #region Select Row
        private void SelectedData()
        {
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0:
                    idSel = bbankDataGrid["bbid", bbankDataGrid.CurrentRow.Index].Value.ToString();
                    txtbankname.Text = bbankDataGrid["bankname", bbankDataGrid.CurrentRow.Index].Value.ToString();
                    break;
                case 1:
                    idSel = baccDataGrid["baid", baccDataGrid.CurrentRow.Index].Value.ToString();
                    txtaccname.Text = baccDataGrid["accname", baccDataGrid.CurrentRow.Index].Value.ToString();
                    break;
                case 2:
                    idSel = bsalDataGrid["bsid", bsalDataGrid.CurrentRow.Index].Value.ToString();
                    txtsalname.Text = bsalDataGrid["salname", bsalDataGrid.CurrentRow.Index].Value.ToString();
                    break;
                case 3:
                    idSel = bcostDataGrid["bcid", bcostDataGrid.CurrentRow.Index].Value.ToString();
                    txtcostname.Text = bcostDataGrid["costname", bcostDataGrid.CurrentRow.Index].Value.ToString();
                    break;
                case 4:
                    idSel = bactDataGrid["baida", bactDataGrid.CurrentRow.Index].Value.ToString();
                    txtactname.Text = bactDataGrid["actname", bactDataGrid.CurrentRow.Index].Value.ToString();
                    break;
            }
        }
        #endregion

        #region KeyDown MouseClick
        private void bbankDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bbankDataGrid.RowCount > 0)
            {
                SelectedData();
                if (bbankDataGrid.CurrentRow.Index == 0)
                    bbankDataGrid[0, 0].Selected = true;
                else
                    bbankDataGrid[0, bbankDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void bbankDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && bbankDataGrid.RowCount > 0)
                SelectedData();
        }

        private void baccDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && baccDataGrid.RowCount > 0)
            {
                SelectedData();
                if (baccDataGrid.CurrentRow.Index == 0)
                    baccDataGrid[0, 0].Selected = true;
                else
                    baccDataGrid[0, baccDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void baccDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && baccDataGrid.RowCount > 0)
                SelectedData();
        }

        private void bsalDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bsalDataGrid.RowCount > 0)
            {
                SelectedData();
                if (bsalDataGrid.CurrentRow.Index == 0)
                    bsalDataGrid[0, 0].Selected = true;
                else
                    bsalDataGrid[0, bsalDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void bsalDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && bsalDataGrid.RowCount > 0)
                SelectedData();
        }

        private void bcostDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bcostDataGrid.RowCount > 0)
            {
                SelectedData();
                if (bcostDataGrid.CurrentRow.Index == 0)
                    bcostDataGrid[0, 0].Selected = true;
                else
                    bcostDataGrid[0, bcostDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void bcostDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && bcostDataGrid.RowCount > 0)
                SelectedData();
        }

        private void bactDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bactDataGrid.RowCount > 0)
            {
                SelectedData();
                if (bactDataGrid.CurrentRow.Index == 0)
                    bactDataGrid[0, 0].Selected = true;
                else
                    bactDataGrid[0, bactDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void bactDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && bactDataGrid.RowCount > 0)
                SelectedData();
        }
        #endregion
    }
}
