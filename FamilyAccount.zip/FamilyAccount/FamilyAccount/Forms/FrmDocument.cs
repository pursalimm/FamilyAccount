﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmDocument : Form
    {
        string idSel = "";
        string selectedkeymem = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmDocument()
        {
            InitializeComponent();
        }

        public static FrmDocument Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmDocument();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOpenPic_Click(object sender, EventArgs e)
        {
            if (openPic.ShowDialog() == DialogResult.OK)
                picdocpic.ImageLocation = openPic.FileName;
        }

        private void btnRemovePic_Click(object sender, EventArgs e)
        {
            picdocpic.Image = (Image)Properties.Resources.nullDoc;
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            picdocpic.Image = (Image)Properties.Resources.nullDoc;
            txtdocdate.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into documents values(@memid,@docdate,@docnote,@docpic)";
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@docdate", SqlDbType.NVarChar).Value = txtdocdate.Text;
            cmd.Parameters.Add("@docnote", SqlDbType.NText).Value = txtdocnote.Text;
            cmd.Parameters.Add("@docpic", SqlDbType.Image).Value = ado.ImageToByte(picdocpic.Image);
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update documents set memid=@memid,docdate=@docdate,docnote=@docnote,docpic=@docpic where docid=@docid";
            cmd.Parameters.Add("@docid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@docdate", SqlDbType.NVarChar).Value = txtdocdate.Text;
            cmd.Parameters.Add("@docnote", SqlDbType.NText).Value = txtdocnote.Text;
            cmd.Parameters.Add("@docpic", SqlDbType.Image).Value = ado.ImageToByte(picdocpic.Image);
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from documents where docid=@docid";
            cmd.Parameters.Add("@docid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmDocument_Load(object sender, EventArgs e)
        {
            familyTableAdapter.Fill(accountDataSet.family);
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtdocid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from documents");
            docDataGrid.DataSource = ds.Tables[0];
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
            picdocpic.Image = (Image)Properties.Resources.nullDoc;
        }

        private void docDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (docDataGrid.RowCount > 0)
            {
                if (docDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void picdocpic_DoubleClick(object sender, EventArgs e)
        {
            picdocpic.Image.Save(Application.StartupPath + "\\image.jpg");
            System.Diagnostics.Process.Start(@"C:\Windows\system32\rundll32.exe", @"C:\Windows\system32\shimgvw.dll,ImageView_Fullscreen " + Application.StartupPath + "\\image.jpg");
        }

        private void SelectedData()
        {
            idSel = docDataGrid["docid", docDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeymem = docDataGrid["memid", docDataGrid.CurrentRow.Index].Value.ToString();
            txtmemid.Text = docDataGrid["memid", docDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtdocdate.Text = docDataGrid["docdate", docDataGrid.CurrentRow.Index].Value.ToString();
            txtdocnote.Text = docDataGrid["docnote", docDataGrid.CurrentRow.Index].Value.ToString();
            picdocpic.Image = ado.ByteToImage((byte[])docDataGrid["docpic", docDataGrid.CurrentRow.Index].Value);
        }

        private void docDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && docDataGrid.RowCount > 0)
            {
                SelectedData();
                if (docDataGrid.CurrentRow.Index == 0)
                    docDataGrid[0, 0].Selected = true;
                else
                    docDataGrid[0, docDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void docDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && docDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtdocdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtdocdate);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymem = dgvr.Cells[0].Value.ToString();
                txtmemid.Text = dgvr.Cells[1].Value.ToString();
                txtmemidD.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtmemid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT do.docid, do.memid, do.docdate, do.docnote, do.docpic FROM documents AS do INNER JOIN family AS fa ON do.memid = fa.memid ";
            if (txtmemidD.Text.Trim().Length != 0)
                query += "AND fa.name like (N'%" + txtmemidD.Text + "%')";
            if (txtdocnoteD.Text.Trim().Length != 0)
                query += "AND do.docnote like (N'%" + txtdocnoteD.Text + "%')";
            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND do.docdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND do.docdate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND do.docdate < '" + txtenddate.Text + "'";

            DataSet ds = ado.select(query);
            docDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT do.docid, do.memid, do.docdate, do.docnote, do.docpic FROM documents AS do INNER JOIN family AS fa ON do.memid = fa.memid ");
            docDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }
    }
}
