﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;

namespace FamilyAccount
{
    public partial class FrmLoan : Form
    {
        string idSel = "";
        string selectedkeymemid = "";
        string selectedkeyaccid = "";
        DataSet ds;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.AccountConnectionString);
        public DataGridViewRow dgvr;
        public FrmLoan()
        {
            InitializeComponent();
        }

        public static FrmLoan Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmLoan();
            }
            return aForm;
        }

        private void btnSponser_Click(object sender, EventArgs e)
        {
            FrmSponser fs = new FrmSponser(idSel);
            fs.ShowDialog();
        }

        private void PaymentPrude()
        {
            cmd.CommandType = CommandType.Text;
            for (int i = 0; i < int.Parse(txtpaynum.Text); i++)
            {
                try
                {
                    cmd.Parameters.Clear();
                    cmd.CommandText = "insert into pay_settle(loanid,dateusan,payquan,setstate) values(@loanid,@dateusan,@payquan,@setstate)";
                    cmd.Parameters.Add("@loanid", SqlDbType.Int).Value = idSel;
                    if (i == 0)
                    {
                        cmd.Parameters.Add("@dateusan", SqlDbType.NVarChar).Value = txtpaydate.Text;
                        cmd.Parameters.Add("@payquan", SqlDbType.Money).Value = txtpayfirstquan.Value.ToString();
                    }
                    else
                    {
                        cmd.Parameters.Add("@dateusan", SqlDbType.NVarChar).Value = ado.IncDate(txtpaydate.Text, i, int.Parse(txtspace.Text));
                        cmd.Parameters.Add("@payquan", SqlDbType.Money).Value = txtpayothquan.Value.ToString();
                    }
                    cmd.Parameters.Add("@setstate", SqlDbType.NVarChar).Value = "انتظار";
                    cmd.Connection = cnn;
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    cmd.Connection = null;
                }
                catch (Exception err)
                {
                    MessageBox.Show("عملیات درج اطلاعات با مشکل مواجه شده است ، لطفا مجددا سعی نمائید", "خطای درج اطلاعات", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    cnn.Close();
                    return;
                }
            }
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            if (cboloanbacktype.SelectedIndex == 0)
            {
                MessageBox.Show("بازپرداخت این وام به صورت راس مدت می باشد", "نوع بازپرداخت", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            DataSet ds = ado.select("select * from pay_settle where loanid='" + idSel + "'");
            if (ds.Tables[0].Rows.Count == 0)
                PaymentPrude();
            FrmPayment fp = new FrmPayment(idSel);
            fp.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            btnSponser.Enabled = false;
            btnPayment.Enabled = false;
            ado.ClearControl(backContainer);
            backContainer.Enabled = true;
            backtype.Enabled = true;
            cboloanbacktype.Enabled = true;
            txtmemid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            if (ado.ValidateControl(grpRas)) return;
            if (ado.ValidateControl(grpAghsat)) return;
            cmd.Parameters.Clear();
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymemid;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = selectedkeyaccid;
            cmd.Parameters.Add("@loandate", SqlDbType.NVarChar).Value = txtloandate.Text;
            cmd.Parameters.Add("@loantype", SqlDbType.NVarChar).Value = cboloantype.Text;
            cmd.Parameters.Add("@loanquan", SqlDbType.Money).Value = txtloanquan.Value.ToString();
            cmd.Parameters.Add("@loanrate", SqlDbType.Float).Value = txtloanrate.Value.ToString();
            cmd.Parameters.Add("@loanback", SqlDbType.Money).Value = txtloanback.Value.ToString();
            cmd.Parameters.Add("@loanbacktype", SqlDbType.NVarChar).Value = cboloanbacktype.Text;
            cmd.Parameters.Add("@loantime", SqlDbType.Int).Value = txtloantime.Value;
            cmd.Parameters.Add("@loanbackdate", SqlDbType.NVarChar).Value = txtloanbackdate.Text;
            cmd.Parameters.Add("@loannote", SqlDbType.NText).Value = txtloannote.Text;
            cmd.Parameters.Add("@payfirstquan", SqlDbType.Money).Value = txtpayfirstquan.Value.ToString();
            cmd.Parameters.Add("@payothquan", SqlDbType.Money).Value = txtpayothquan.Value.ToString();
            cmd.Parameters.Add("@paynum", SqlDbType.Int).Value = txtpaynum.Text;
            cmd.Parameters.Add("@mspace", SqlDbType.Int).Value = txtspace.Text;
            cmd.Parameters.Add("@paydate", SqlDbType.NVarChar).Value = txtpaydate.Text;
            if (MessageBox.Show("پس از ثبت اطلاعات بازپرداخت تسهیلات غیر قابل ویرایش می باشد", "ثبت اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.insert(cmd, CommandType.StoredProcedure, "spInsertLoan"))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            if (ado.ValidateControl(grpRas)) return;
            if (ado.ValidateControl(grpAghsat)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update loan set memid=@memid,accid=@accid,loandate=@loandate,loantype=@loantype,loanquan=@loanquan,loanrate=@loanrate,loanback=@loanback,loanbacktype=@loanbacktype,loantime=@loantime,loanbackdate=@loanbackdate,loannote=@loannote,payfirstquan=@payfirstquan,payothquan=@payothquan,paynum=@paynum,mspace=@mspace,paydate=@paydate where loanid=@loanid";
            cmd.Parameters.Add("@loanid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymemid;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = selectedkeyaccid;
            cmd.Parameters.Add("@loandate", SqlDbType.NVarChar).Value = txtloandate.Text;
            cmd.Parameters.Add("@loantype", SqlDbType.NVarChar).Value = cboloantype.Text;
            cmd.Parameters.Add("@loanquan", SqlDbType.Money).Value = txtloanquan.Value.ToString();
            cmd.Parameters.Add("@loanrate", SqlDbType.Float).Value = txtloanrate.Value.ToString();
            cmd.Parameters.Add("@loanback", SqlDbType.Money).Value = txtloanback.Value.ToString();
            cmd.Parameters.Add("@loanbacktype", SqlDbType.NVarChar).Value = cboloanbacktype.Text;
            cmd.Parameters.Add("@loantime", SqlDbType.Int).Value = txtloantime.Value;
            cmd.Parameters.Add("@loanbackdate", SqlDbType.NVarChar).Value = txtloanbackdate.Text;
            cmd.Parameters.Add("@loannote", SqlDbType.NText).Value = txtloannote.Text;
            cmd.Parameters.Add("@payfirstquan", SqlDbType.Money).Value = txtpayfirstquan.Value.ToString();
            cmd.Parameters.Add("@payothquan", SqlDbType.Money).Value = txtpayothquan.Value.ToString();
            cmd.Parameters.Add("@paynum", SqlDbType.Int).Value = txtpaynum.Text;
            cmd.Parameters.Add("@mspace", SqlDbType.Int).Value = txtspace.Text;
            cmd.Parameters.Add("@paydate", SqlDbType.NVarChar).Value = txtpaydate.Text;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from loan where loanid=@loanid";
            cmd.Parameters.Add("@loanid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmLoan_Load(object sender, EventArgs e)
        {
            familyTableAdapter.Fill(accountDataSet.family);
            backContainer.Enabled = false;
            ado.SetFarsiLanguage();
            GridRefresh();
        }

        private void txtloanquan_TextChanged(object sender, EventArgs e)
        {
            if (txtloanquan.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtloanquan.Text) == null) return;
                if (ado.ExtractNumbers(txtloanquan.Text).Length == 13) ProcessTabKey(true);
                lblLoanquan.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtloanquan.Text))) + " ریال";
            }
            else
                lblLoanquan.Text = "";
        }

        private void txtloanid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from loan");
            loanDataGrid.DataSource = ds.Tables[0];
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            btnSponser.Enabled = true;
            btnPayment.Enabled = true;
            ado.ClearControl(backContainer);
            ado.ClearControl(backtype);
            backContainer.Enabled = false;
            backtype.Enabled = false;
        }

        private void txtloandate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtloandate);
        }

        private void txtloanquan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void txtloanrate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if ((char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar)))
                e.Handled = true;
        }

        private void txtmemid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT fa.memid, fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                    + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                    + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                    + "ON bnk.bbid = bb.bbid");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT fa.memid, fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                                + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                                + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                                + "ON bnk.bbid = bb.bbid");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymemid = dgvr.Cells[0].Value.ToString();
                selectedkeyaccid = dgvr.Cells[2].Value.ToString();
                txtmemid.Text = dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[1].Value.ToString() + " - " + dgvr.Cells[4].Value.ToString() + " شعبه " + dgvr.Cells[5].Value.ToString() + " کد " + dgvr.Cells[3].Value.ToString();
                txtaccidS.Text = dgvr.Cells[2].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void SelectedData()
        {
            idSel = loanDataGrid["loanid", loanDataGrid.CurrentRow.Index].FormattedValue.ToString();
            ds = ado.select("SELECT fa.memid, fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname "
                                                + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                                + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                                + "ON bnk.bbid = bb.bbid");
            selectedkeymemid = ds.Tables[0].Rows[0]["memid"].ToString();
            txtmemid.Text = ds.Tables[0].Rows[0]["accid"].ToString() + " - " + ds.Tables[0].Rows[0]["name"].ToString() + " - " + ds.Tables[0].Rows[0]["bankname"].ToString() + " شعبه " + ds.Tables[0].Rows[0]["branchname"].ToString() + " کد " + ds.Tables[0].Rows[0]["branchid"].ToString();
            selectedkeyaccid = loanDataGrid["accid", loanDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtloandate.Text = loanDataGrid["loandate", loanDataGrid.CurrentRow.Index].Value.ToString();
            cboloantype.Text = loanDataGrid["loantype", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloanquan.Text = loanDataGrid["loanquan", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloanrate.Text = loanDataGrid["loanrate", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloanback.Text = loanDataGrid["loanback", loanDataGrid.CurrentRow.Index].Value.ToString();
            cboloanbacktype.Text = loanDataGrid["loanbacktype", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloantime.Text = loanDataGrid["loantime", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloanbackdate.Text = loanDataGrid["loanbackdate", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtloannote.Text = loanDataGrid["loannote", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtpayfirstquan.Text = loanDataGrid["payfirstquan", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtpayothquan.Text = loanDataGrid["payothquan", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtpaynum.Text = loanDataGrid["paynum", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtspace.Text = loanDataGrid["mspace", loanDataGrid.CurrentRow.Index].Value.ToString();
            txtpaydate.Text = loanDataGrid["paydate", loanDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void cboloanbacktype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboloanbacktype.SelectedIndex == 0)
            {
                //backtype.Enabled = true;
                txtloantime.Tag = txtloanbackdate.Tag = "1";
                txtpayfirstquan.Tag = txtpayothquan.Tag = txtpaydate.Tag = txtpaynum.Tag = "0";
                grpRas.Enabled = true;
                grpAghsat.Enabled = false;
                ado.ClearControl(grpRas);
                ado.ClearControl(grpAghsat);
                txtloantime.Focus();
            }
            else
            {
                //backtype.Enabled = true;
                txtloantime.Tag = txtloanbackdate.Tag = "0";
                txtpayfirstquan.Tag = txtpayothquan.Tag = txtpaydate.Tag = txtpaynum.Tag = "1";
                grpRas.Enabled = false;
                grpAghsat.Enabled = true;
                ado.ClearControl(grpRas);
                ado.ClearControl(grpAghsat);
                txtpayfirstquan.Focus();
            }
        }

        private void loanDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (loanDataGrid.RowCount > 0)
            {
                if (loanDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                    cboloanbacktype.Enabled = false;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
                backtype.Enabled = false;
            }
        }

        private void loanDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && loanDataGrid.RowCount > 0)
            {
                SelectedData();
                if (loanDataGrid.CurrentRow.Index == 0)
                    loanDataGrid[0, 0].Selected = true;
                else
                    loanDataGrid[0, loanDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void loanDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && loanDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtpaydate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtpaydate);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT lo.loanid, lo.memid, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbacktype, lo.loantime, lo.loanbackdate, lo.loannote, lo.payfirstquan, lo.payothquan, lo.paynum, lo.mspace, lo.paydate FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid ";
            if (cbobacktypeS.Text.Trim().Length != 0)
                query += "AND lo.loanbacktype like (N'%" + cbobacktypeS.Text + "%')";
            if (txtmemidS.Text.Trim().Length != 0)
                query += "AND fa.name like (N'%" + txtmemidS.Text + "%')";
            if (txtaccidS.Text.Trim().Length != 0)
                query += "AND lo.accid= '" + txtaccidS.Text + "'";
            if (cboloantypeS.Text.Trim().Length != 0)
                query += "AND lo.loantype like (N'%" + cboloantypeS.Text + "%')";

            if (rdoloanquan.Checked == true)
            {
                if (txtminMoney.Value.ToString() != "0" && txtmaxMoney.Value.ToString() != "0")
                    query += "AND lo.loanquan between " + txtminMoney.Value.ToString() + " and " + txtmaxMoney.Value.ToString();
                else if (txtminMoney.Value.ToString() != "0")
                    query += "AND lo.loanquan > " + txtminMoney.Value.ToString();
                else if (txtmaxMoney.Value.ToString() != "0")
                    query += "AND lo.loanquan < " + txtmaxMoney.Value.ToString();
            }
            else if (rdoquanback.Checked == true)
            {
                if (txtminMoney.Value.ToString() != "0" && txtmaxMoney.Value.ToString() != "0")
                    query += "AND lo.loanback between " + txtminMoney.Value.ToString() + " and " + txtmaxMoney.Value.ToString();
                else if (txtminMoney.Value.ToString() != "0")
                    query += "AND lo.loanback > " + txtminMoney.Value.ToString();
                else if (txtmaxMoney.Value.ToString() != "0")
                    query += "AND lo.loanback < " + txtmaxMoney.Value.ToString();
            }

            if (rdodateL.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND lo.loandate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND lo.loandate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND lo.loandate < '" + txtenddate.Text + "'";
            }
            else if (rdoquanback.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND lo.loanbackdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND lo.loanbackdate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND lo.loanbackdate < '" + txtenddate.Text + "'";
            }

            DataSet ds = ado.select(query);
            loanDataGrid.DataSource = ds.Tables[0];
            selectedkeymemid = string.Empty;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT lo.loanid, lo.memid, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbacktype, lo.loantime, lo.loanbackdate, lo.loannote, lo.payfirstquan, lo.payothquan, lo.paynum, lo.mspace, lo.paydate FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid ");
            loanDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
            ado.ClearControl(grpMoney);
            ado.ClearControl(grpDate);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
            ado.ClearControl(grpMoney);
            ado.ClearControl(grpDate);
        }

        private void txtloanbackdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtloanbackdate);
        }

        private void FrmLoan_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F12)
            {
                Form ff = FrmCal.Instance();
                ff.Show();
                ff.Activate();
            }
        }
    }
}
