﻿namespace FamilyAccount
{
    partial class FrmFamily
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmFamily aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem9 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem10 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem11 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem12 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFamily));
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtmothername = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpostalcode = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpublicid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtshenasid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbirthdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.txtfathername = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.cbodepend = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmatchdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.elContainer3 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elButton1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.contextMenuPic = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnOpenPic = new System.Windows.Forms.ToolStripMenuItem();
            this.btnRemovePic = new System.Windows.Forms.ToolStripMenuItem();
            this.picpicture = new System.Windows.Forms.PictureBox();
            this.cbomatchstate = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.cbosex = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.dataPanel = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.FamilyDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.memid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fathername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mothername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shenasid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publicid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postalcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.depend = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.matchstate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.matchdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.openPic = new System.Windows.Forms.OpenFileDialog();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.txtmothername)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpostalcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpublicid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtshenasid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbirthdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtfathername)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbodepend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatchdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).BeginInit();
            this.elContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).BeginInit();
            this.contextMenuPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picpicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbomatchstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbosex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataPanel)).BeginInit();
            this.dataPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FamilyDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtmothername
            // 
            this.txtmothername.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmothername.CaptionStyle.CaptionSize = 110;
            this.txtmothername.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmothername.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmothername.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmothername.CaptionStyle.TextStyle.Text = "نام مادر";
            this.txtmothername.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmothername.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmothername.Location = new System.Drawing.Point(175, 38);
            this.txtmothername.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmothername.Name = "txtmothername";
            this.txtmothername.Size = new System.Drawing.Size(197, 27);
            this.txtmothername.TabIndex = 3;
            this.txtmothername.Tag = "0";
            this.txtmothername.ValidationStyle.AcceptsTab = true;
            this.txtmothername.ValidationStyle.PasswordChar = '\0';
            this.txtmothername.Value = "";
            this.txtmothername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtpostalcode
            // 
            this.txtpostalcode.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpostalcode.CaptionStyle.CaptionSize = 110;
            this.txtpostalcode.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpostalcode.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpostalcode.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpostalcode.CaptionStyle.TextStyle.Text = "کد پستی";
            this.txtpostalcode.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpostalcode.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpostalcode.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpostalcode.Location = new System.Drawing.Point(165, 96);
            this.txtpostalcode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtpostalcode.Name = "txtpostalcode";
            this.txtpostalcode.Size = new System.Drawing.Size(206, 27);
            this.txtpostalcode.TabIndex = 7;
            this.txtpostalcode.Tag = "0";
            this.txtpostalcode.ValidationStyle.AcceptsTab = true;
            this.txtpostalcode.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtpostalcode.ValidationStyle.MaskValidationStyle.Mask = "0000000000";
            this.txtpostalcode.ValidationStyle.PasswordChar = '\0';
            this.txtpostalcode.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtpostalcode.Value = "          ";
            this.txtpostalcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtpublicid
            // 
            this.txtpublicid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpublicid.CaptionStyle.CaptionSize = 110;
            this.txtpublicid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpublicid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpublicid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpublicid.CaptionStyle.TextStyle.Text = "شماره ملی";
            this.txtpublicid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpublicid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpublicid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpublicid.Location = new System.Drawing.Point(453, 96);
            this.txtpublicid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtpublicid.Name = "txtpublicid";
            this.txtpublicid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtpublicid.Size = new System.Drawing.Size(206, 27);
            this.txtpublicid.TabIndex = 6;
            this.txtpublicid.Tag = "0";
            this.txtpublicid.ValidationStyle.AcceptsTab = true;
            this.txtpublicid.ValidationStyle.MaskValidationStyle.Mask = "0000000000";
            this.txtpublicid.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Numeric;
            this.txtpublicid.ValidationStyle.PasswordChar = '\0';
            this.txtpublicid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtpublicid.Value = "          ";
            this.txtpublicid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtshenasid
            // 
            this.txtshenasid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtshenasid.CaptionStyle.CaptionSize = 110;
            this.txtshenasid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtshenasid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtshenasid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtshenasid.CaptionStyle.TextStyle.Text = "شماره شناسنامه";
            this.txtshenasid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtshenasid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtshenasid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtshenasid.Location = new System.Drawing.Point(165, 67);
            this.txtshenasid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtshenasid.Name = "txtshenasid";
            this.txtshenasid.Size = new System.Drawing.Size(206, 27);
            this.txtshenasid.TabIndex = 5;
            this.txtshenasid.Tag = "0";
            this.txtshenasid.ValidationStyle.AcceptsTab = true;
            this.txtshenasid.ValidationStyle.MaskValidationStyle.Mask = "0000000000";
            this.txtshenasid.ValidationStyle.PasswordChar = '\0';
            this.txtshenasid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtshenasid.Value = "          ";
            this.txtshenasid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtbirthdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbirthdate.CaptionStyle.CaptionSize = 110;
            this.txtbirthdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbirthdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbirthdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbirthdate.CaptionStyle.TextStyle.Text = "تاریخ تولد";
            this.txtbirthdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbirthdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbirthdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbirthdate.Location = new System.Drawing.Point(453, 67);
            this.txtbirthdate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtbirthdate.Size = new System.Drawing.Size(206, 27);
            this.txtbirthdate.TabIndex = 4;
            this.txtbirthdate.Tag = "0";
            this.txtbirthdate.ValidationStyle.AcceptsTab = true;
            this.txtbirthdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtbirthdate.ValidationStyle.PasswordChar = '\0';
            this.txtbirthdate.Value = "";
            this.txtbirthdate.Leave += new System.EventHandler(this.txtbirthdate_Leave);
            this.txtbirthdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // txtfathername
            // 
            this.txtfathername.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtfathername.CaptionStyle.CaptionSize = 110;
            this.txtfathername.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtfathername.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtfathername.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtfathername.CaptionStyle.TextStyle.Text = "نام پدر";
            this.txtfathername.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfathername.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtfathername.Location = new System.Drawing.Point(462, 38);
            this.txtfathername.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtfathername.Name = "txtfathername";
            this.txtfathername.Size = new System.Drawing.Size(197, 27);
            this.txtfathername.TabIndex = 2;
            this.txtfathername.Tag = "0";
            this.txtfathername.ValidationStyle.AcceptsTab = true;
            this.txtfathername.ValidationStyle.PasswordChar = '\0';
            this.txtfathername.Value = "";
            this.txtfathername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.cbodepend);
            this.backContainer.Controls.Add(this.txtname);
            this.backContainer.Controls.Add(this.txtmatchdate);
            this.backContainer.Controls.Add(this.elContainer3);
            this.backContainer.Controls.Add(this.cbomatchstate);
            this.backContainer.Controls.Add(this.cbosex);
            this.backContainer.Controls.Add(this.txtfathername);
            this.backContainer.Controls.Add(this.txtbirthdate);
            this.backContainer.Controls.Add(this.txtshenasid);
            this.backContainer.Controls.Add(this.txtmothername);
            this.backContainer.Controls.Add(this.txtpublicid);
            this.backContainer.Controls.Add(this.txtpostalcode);
            this.backContainer.Enabled = false;
            this.backContainer.Location = new System.Drawing.Point(7, 6);
            this.backContainer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(667, 189);
            this.backContainer.TabIndex = 0;
            this.backContainer.Tag = "0";
            // 
            // cbodepend
            // 
            // 
            // 
            // 
            this.cbodepend.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbodepend.ButtonStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbodepend.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbodepend.CaptionStyle.CaptionSize = 110;
            this.cbodepend.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbodepend.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbodepend.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbodepend.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbodepend.CaptionStyle.TextStyle.Text = "نوع وابستگی";
            this.cbodepend.CheckedDisplaySeparator = ',';
            this.cbodepend.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbodepend.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbodepend.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbodepend.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            elListBoxSelectionStyles4.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles4.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbodepend.DropDownItemSelectionStyle = elListBoxSelectionStyles4;
            this.cbodepend.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbodepend.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbodepend.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbodepend.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbodepend.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem9.Value = "سرپرست";
            elListBoxItem10.Value = "همسر";
            elListBoxItem11.Value = "فرزند";
            elListBoxItem12.Value = "سایر";
            this.cbodepend.Items.Add(elListBoxItem9);
            this.cbodepend.Items.Add(elListBoxItem10);
            this.cbodepend.Items.Add(elListBoxItem11);
            this.cbodepend.Items.Add(elListBoxItem12);
            this.cbodepend.Location = new System.Drawing.Point(453, 154);
            this.cbodepend.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbodepend.Name = "cbodepend";
            this.cbodepend.Size = new System.Drawing.Size(206, 27);
            this.cbodepend.TabIndex = 14;
            this.cbodepend.Tag = "1";
            this.cbodepend.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtname
            // 
            this.txtname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtname.CaptionStyle.CaptionSize = 110;
            this.txtname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtname.CaptionStyle.TextStyle.Text = "نام و نام خانوادگی";
            this.txtname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtname.Location = new System.Drawing.Point(407, 9);
            this.txtname.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(252, 27);
            this.txtname.TabIndex = 0;
            this.txtname.Tag = "1";
            this.txtname.ValidationStyle.AcceptsTab = true;
            this.txtname.ValidationStyle.PasswordChar = '\0';
            this.txtname.Value = "";
            this.txtname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // txtmatchdate
            // 
            this.txtmatchdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtmatchdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmatchdate.CaptionStyle.CaptionSize = 110;
            this.txtmatchdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmatchdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmatchdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmatchdate.CaptionStyle.TextStyle.Text = "تاریخ ازدواج";
            this.txtmatchdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmatchdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmatchdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtmatchdate.Location = new System.Drawing.Point(165, 125);
            this.txtmatchdate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtmatchdate.Name = "txtmatchdate";
            this.txtmatchdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtmatchdate.Size = new System.Drawing.Size(206, 27);
            this.txtmatchdate.TabIndex = 9;
            this.txtmatchdate.Tag = "0";
            this.txtmatchdate.ValidationStyle.AcceptsTab = true;
            this.txtmatchdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtmatchdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtmatchdate.ValidationStyle.PasswordChar = '\0';
            this.txtmatchdate.Value = "";
            this.txtmatchdate.Visible = false;
            this.txtmatchdate.Leave += new System.EventHandler(this.txtmatchdate_Leave);
            this.txtmatchdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // elContainer3
            // 
            this.elContainer3.Controls.Add(this.elButton1);
            this.elContainer3.Controls.Add(this.picpicture);
            this.elContainer3.Location = new System.Drawing.Point(8, 9);
            this.elContainer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer3.Name = "elContainer3";
            this.elContainer3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer3.Size = new System.Drawing.Size(115, 133);
            this.elContainer3.TabIndex = 12;
            this.elContainer3.Tag = "0";
            this.elContainer3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // elButton1
            // 
            this.elButton1.BackgroundImageStyle.Alpha = 100;
            this.elButton1.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.elButton1.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elButton1.BackgroundImageStyle.ImageSize = new System.Drawing.Size(18, 18);
            this.elButton1.ButtonStyle = Klik.Windows.Forms.v1.EntryLib.ButtonStyles.DropDownButton;
            this.elButton1.DropDownContextMenuStrip = this.contextMenuPic;
            this.elButton1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.Location = new System.Drawing.Point(0, 111);
            this.elButton1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elButton1.Name = "elButton1";
            this.elButton1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.elButton1.Size = new System.Drawing.Size(115, 21);
            this.elButton1.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.TabIndex = 0;
            this.elButton1.Tag = "0";
            this.elButton1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton1.TextStyle.Text = "تصویر";
            this.elButton1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuPic
            // 
            this.contextMenuPic.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnOpenPic,
            this.btnRemovePic});
            this.contextMenuPic.Name = "contextMenuStrip1";
            this.contextMenuPic.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuPic.Size = new System.Drawing.Size(126, 48);
            // 
            // btnOpenPic
            // 
            this.btnOpenPic.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenPic.Image")));
            this.btnOpenPic.Name = "btnOpenPic";
            this.btnOpenPic.Size = new System.Drawing.Size(125, 22);
            this.btnOpenPic.Text = "تغییر تصویر";
            this.btnOpenPic.Click += new System.EventHandler(this.btnOpenPic_Click);
            // 
            // btnRemovePic
            // 
            this.btnRemovePic.Image = ((System.Drawing.Image)(resources.GetObject("btnRemovePic.Image")));
            this.btnRemovePic.Name = "btnRemovePic";
            this.btnRemovePic.Size = new System.Drawing.Size(125, 22);
            this.btnRemovePic.Text = "حذف تصویر";
            this.btnRemovePic.Click += new System.EventHandler(this.btnRemovePic_Click);
            // 
            // picpicture
            // 
            this.picpicture.BackColor = System.Drawing.Color.Transparent;
            this.picpicture.Dock = System.Windows.Forms.DockStyle.Top;
            this.picpicture.Image = ((System.Drawing.Image)(resources.GetObject("picpicture.Image")));
            this.picpicture.Location = new System.Drawing.Point(4, 3);
            this.picpicture.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.picpicture.Name = "picpicture";
            this.picpicture.Size = new System.Drawing.Size(107, 109);
            this.picpicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picpicture.TabIndex = 69;
            this.picpicture.TabStop = false;
            this.picpicture.DoubleClick += new System.EventHandler(this.picpicture_DoubleClick);
            // 
            // cbomatchstate
            // 
            // 
            // 
            // 
            this.cbomatchstate.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbomatchstate.ButtonStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbomatchstate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbomatchstate.CaptionStyle.CaptionSize = 110;
            this.cbomatchstate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbomatchstate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbomatchstate.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbomatchstate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbomatchstate.CaptionStyle.TextStyle.Text = "وضعیت تاهل";
            this.cbomatchstate.CheckedDisplaySeparator = ',';
            this.cbomatchstate.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbomatchstate.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbomatchstate.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbomatchstate.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbomatchstate.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cbomatchstate.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbomatchstate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbomatchstate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbomatchstate.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbomatchstate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = false;
            elListBoxItem1.Value = "مجرد";
            elListBoxItem2.Key = true;
            elListBoxItem2.Value = "متاهل";
            this.cbomatchstate.Items.Add(elListBoxItem1);
            this.cbomatchstate.Items.Add(elListBoxItem2);
            this.cbomatchstate.Location = new System.Drawing.Point(453, 125);
            this.cbomatchstate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbomatchstate.Name = "cbomatchstate";
            this.cbomatchstate.Size = new System.Drawing.Size(206, 27);
            this.cbomatchstate.TabIndex = 8;
            this.cbomatchstate.Tag = "0";
            this.cbomatchstate.SelectedIndexChanged += new System.EventHandler(this.cbomatchstate_SelectedIndexChanged);
            this.cbomatchstate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // cbosex
            // 
            // 
            // 
            // 
            this.cbosex.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosex.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbosex.CaptionStyle.CaptionSize = 110;
            this.cbosex.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosex.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbosex.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosex.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosex.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosex.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosex.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cbosex.CaptionStyle.TextStyle.Text = "جنسیت";
            this.cbosex.CheckedDisplaySeparator = ',';
            this.cbosex.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosex.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbosex.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosex.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbosex.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles2.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles2.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbosex.DropDownItemSelectionStyle = elListBoxSelectionStyles2;
            this.cbosex.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbosex.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosex.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbosex.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosex.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem3.Key = false;
            elListBoxItem3.Value = "زن";
            elListBoxItem4.Key = true;
            elListBoxItem4.Value = "مرد";
            this.cbosex.Items.Add(elListBoxItem3);
            this.cbosex.Items.Add(elListBoxItem4);
            this.cbosex.Location = new System.Drawing.Point(197, 9);
            this.cbosex.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbosex.Name = "cbosex";
            this.cbosex.Size = new System.Drawing.Size(174, 27);
            this.cbosex.TabIndex = 1;
            this.cbosex.Tag = "0";
            this.cbosex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmemid_KeyPress);
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(98, 404);
            this.elContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(11, 6);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(249, 6);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(172, 6);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(410, 6);
            this.btnNew.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // dataPanel
            // 
            this.dataPanel.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.dataPanel.Controls.Add(this.FamilyDataGrid);
            this.dataPanel.Expanded = true;
            this.dataPanel.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.dataPanel.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.dataPanel.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.dataPanel.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.dataPanel.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.dataPanel.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.dataPanel.HeaderStyle.Height = 18;
            this.dataPanel.Location = new System.Drawing.Point(7, 201);
            this.dataPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataPanel.Name = "dataPanel";
            this.dataPanel.Padding = new System.Windows.Forms.Padding(1, 18, 1, 16);
            this.dataPanel.Size = new System.Drawing.Size(667, 195);
            this.dataPanel.TabIndex = 1;
            this.dataPanel.Tag = "0";
            // 
            // FamilyDataGrid
            // 
            this.FamilyDataGrid.AllowUserToAddRows = false;
            this.FamilyDataGrid.AllowUserToDeleteRows = false;
            this.FamilyDataGrid.AllowUserToResizeColumns = false;
            this.FamilyDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FamilyDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.FamilyDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.FamilyDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.FamilyDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FamilyDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.FamilyDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.FamilyDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.memid,
            this.name,
            this.fathername,
            this.mothername,
            this.sex,
            this.birthdate,
            this.shenasid,
            this.publicid,
            this.postalcode,
            this.depend,
            this.matchstate,
            this.matchdate,
            this.picture});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FamilyDataGrid.DefaultCellStyle = dataGridViewCellStyle10;
            this.FamilyDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FamilyDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.FamilyDataGrid.Location = new System.Drawing.Point(1, 18);
            this.FamilyDataGrid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.FamilyDataGrid.MultiSelect = false;
            this.FamilyDataGrid.Name = "FamilyDataGrid";
            this.FamilyDataGrid.ReadOnly = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FamilyDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.FamilyDataGrid.RowHeadersVisible = false;
            this.FamilyDataGrid.RowHeadersWidth = 30;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FamilyDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.FamilyDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.FamilyDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FamilyDataGrid.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Blue;
            this.FamilyDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.FamilyDataGrid.ShowCellErrors = false;
            this.FamilyDataGrid.ShowCellToolTips = false;
            this.FamilyDataGrid.ShowEditingIcon = false;
            this.FamilyDataGrid.ShowRowErrors = false;
            this.FamilyDataGrid.Size = new System.Drawing.Size(665, 161);
            this.FamilyDataGrid.TabIndex = 0;
            this.FamilyDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.FamilyDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FamilyDataGrid_MouseClick);
            this.FamilyDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FamilyDataGrid_CellClick);
            this.FamilyDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FamilyDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.FillWeight = 42.33836F;
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.HeaderText = "کد";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Visible = false;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.FillWeight = 50F;
            this.name.HeaderText = "نام و نام خانوادگی";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // fathername
            // 
            this.fathername.DataPropertyName = "fathername";
            this.fathername.FillWeight = 94.32621F;
            this.fathername.HeaderText = "نام پدر";
            this.fathername.Name = "fathername";
            this.fathername.ReadOnly = true;
            this.fathername.Visible = false;
            // 
            // mothername
            // 
            this.mothername.DataPropertyName = "mothername";
            this.mothername.FillWeight = 110.0871F;
            this.mothername.HeaderText = "نام مادر";
            this.mothername.Name = "mothername";
            this.mothername.ReadOnly = true;
            this.mothername.Visible = false;
            // 
            // sex
            // 
            this.sex.DataPropertyName = "sex";
            this.sex.FillWeight = 82.9235F;
            this.sex.HeaderText = "جنسیت";
            this.sex.Name = "sex";
            this.sex.ReadOnly = true;
            this.sex.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.sex.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.sex.Visible = false;
            // 
            // birthdate
            // 
            this.birthdate.DataPropertyName = "birthdate";
            this.birthdate.FillWeight = 53.20517F;
            this.birthdate.HeaderText = "تاریخ تولد";
            this.birthdate.Name = "birthdate";
            this.birthdate.ReadOnly = true;
            // 
            // shenasid
            // 
            this.shenasid.DataPropertyName = "shenasid";
            this.shenasid.FillWeight = 142.6722F;
            this.shenasid.HeaderText = "شماره شناسنامه";
            this.shenasid.Name = "shenasid";
            this.shenasid.ReadOnly = true;
            this.shenasid.Visible = false;
            // 
            // publicid
            // 
            this.publicid.DataPropertyName = "publicid";
            this.publicid.FillWeight = 115.2054F;
            this.publicid.HeaderText = "شماره ملی";
            this.publicid.Name = "publicid";
            this.publicid.ReadOnly = true;
            this.publicid.Visible = false;
            // 
            // postalcode
            // 
            this.postalcode.DataPropertyName = "postalcode";
            this.postalcode.FillWeight = 93.606F;
            this.postalcode.HeaderText = "کد پستی";
            this.postalcode.Name = "postalcode";
            this.postalcode.ReadOnly = true;
            this.postalcode.Visible = false;
            // 
            // depend
            // 
            this.depend.DataPropertyName = "depend";
            this.depend.FillWeight = 45.93081F;
            this.depend.HeaderText = "وابستگی";
            this.depend.Name = "depend";
            this.depend.ReadOnly = true;
            // 
            // matchstate
            // 
            this.matchstate.DataPropertyName = "matchstate";
            this.matchstate.FillWeight = 32.17878F;
            this.matchstate.HeaderText = "وضعیت تاهل";
            this.matchstate.Name = "matchstate";
            this.matchstate.ReadOnly = true;
            this.matchstate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.matchstate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // matchdate
            // 
            this.matchdate.DataPropertyName = "matchdate";
            this.matchdate.FillWeight = 62.31283F;
            this.matchdate.HeaderText = "تاریخ ازدواج";
            this.matchdate.Name = "matchdate";
            this.matchdate.ReadOnly = true;
            // 
            // picture
            // 
            this.picture.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.picture.DataPropertyName = "picture";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle9.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle9.NullValue")));
            this.picture.DefaultCellStyle = dataGridViewCellStyle9;
            this.picture.FillWeight = 32.57407F;
            this.picture.HeaderText = "تصویر";
            this.picture.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.picture.Name = "picture";
            this.picture.ReadOnly = true;
            this.picture.Width = 44;
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // FrmFamily
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 452);
            this.ControlBox = false;
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.dataPanel);
            this.Controls.Add(this.elContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmFamily";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اطلاعات اعضای خانواده";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmFamily_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtmothername)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpostalcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpublicid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtshenasid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbirthdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtfathername)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cbodepend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatchdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).EndInit();
            this.elContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).EndInit();
            this.contextMenuPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picpicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbomatchstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbosex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataPanel)).EndInit();
            this.dataPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FamilyDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmothername;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpostalcode;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpublicid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtshenasid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbirthdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtfathername;
        private System.Windows.Forms.PictureBox picpicture;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer3;
        private System.Windows.Forms.OpenFileDialog openPic;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbosex;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbomatchstate;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton1;
        private System.Windows.Forms.ContextMenuStrip contextMenuPic;
        private System.Windows.Forms.ToolStripMenuItem btnOpenPic;
        private System.Windows.Forms.ToolStripMenuItem btnRemovePic;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmatchdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel dataPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView FamilyDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtname;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELComboBox cbodepend;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn fathername;
        private System.Windows.Forms.DataGridViewTextBoxColumn mothername;
        private System.Windows.Forms.DataGridViewTextBoxColumn sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn shenasid;
        private System.Windows.Forms.DataGridViewTextBoxColumn publicid;
        private System.Windows.Forms.DataGridViewTextBoxColumn postalcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn depend;
        private System.Windows.Forms.DataGridViewTextBoxColumn matchstate;
        private System.Windows.Forms.DataGridViewTextBoxColumn matchdate;
        private System.Windows.Forms.DataGridViewImageColumn picture;
    }
}



