﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Collections;
using DevComponents.DotNetBar;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmMain : Form
    {
        ClassDB ado = new ClassDB();
        PersianDate pd = PersianDateConverter.ToPersianDate(DateTime.Now);
        public FrmMain()
        {
            string s = Guid.NewGuid().ToString();
            InitializeComponent();
        }

        #region Activate Window
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == FamilyAccount.ClassDB.NativeMethods.WM_SHOWME)
                ShowMe();
            base.WndProc(ref m);
        }

        private void ShowMe()
        {
            if (WindowState == FormWindowState.Minimized)
                WindowState = FormWindowState.Normal;
            bool top = TopMost;
            TopMost = true;
            TopMost = top;
        }
        #endregion

        #region Show Close Form
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnFamily_Click(object sender, EventArgs e)
        {
            Form ff = FrmFamily.Instance();
            ff.Show();
            ff.Activate();
        }

        private void btnCoding_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fb = FrmBaseInfo.Instance();
            fb.Show();
            fb.Activate();
        }

        private void btnSalary_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fs = FrmSalary.Instance();
            fs.Show();
            fs.Activate();
        }

        private void btnCost_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fcost = FrmCost.Instance();
            fcost.Show();
            fcost.Activate();
        }

        private void btnDocument_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fd = FrmDocument.Instance();
            fd.Show();
            fd.Activate();
        }

        private void btnBanks_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fb = FrmBanks.Instance();
            fb.Show();
            fb.Activate();
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fa = FrmAccount.Instance();
            fa.Show();
            fa.Activate();
        }

        private void btnLoan_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fl = FrmLoan.Instance();
            fl.Show();
            fl.Activate();
        }

        private void btnCheq_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fc = FrmCheq.Instance();
            fc.Show();
            fc.Activate();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fr = FrmReport.Instance();
            fr.Show();
            fr.Activate();
        }

        private void btnPhone_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fp = FrmPhone.Instance();
            fp.Show();
            fp.Activate();
        }

        private void btnNotation_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            Form fn = FrmNotation.Instance();
            fn.Show();
            fn.Activate();
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.ExistSupervisor == false)
            {
                MessageBox.Show("تاکنون هیچ سرپرست خانواری در سیستم ثبت نشده است ، لطفا اطلاعات سرپرست خانواده را ثبت نمائید", "سرپرست خانواده", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading); 
                return;
            }
            Form fs = FrmSetting.Instance();
            fs.Show();
            fs.Activate();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            Form ab = FrmAbout.Instance();
            ab.Show();
            ab.Activate();
        }

        private void btnSecurity_Click(object sender, EventArgs e)
        {
            FrmInputbox ibox = new FrmInputbox("کلمه عبور را وارد نمائید", "ورود اطلاعات", "");
            ibox.txtEnteredText.EditBoxStyle.TextAlign = HorizontalAlignment.Right;
            ibox.txtEnteredText.ValidationStyle.UseSystemPasswordChar = true;
            ado.SetEnglishLanguage();
            if (ibox.ShowDialog() == DialogResult.OK)
            {
                DataSet ds = ado.select("select * from security");
                if ((ds.Tables[0].Rows[0]["password"].ToString() == "" && ibox.EnteredText.Equals("admin")) || (ado.DecryptText(ds.Tables[0].Rows[0]["password"].ToString()) != "" && ibox.EnteredText.Equals(ado.DecryptText(ds.Tables[0].Rows[0]["password"].ToString()))))
                {
                    Form fs = FrmSecurity.Instance();
                    fs.Show();
                    fs.Activate();
                }
                else
                    MessageBox.Show("کلمه عبور وارد شده نادرست می باشد.لطفا مجددا سعی نمائید", "کلمه عبور", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            }
            ado.SetFarsiLanguage();
        }
        #endregion

        private void btnBackup_Click(object sender, EventArgs e)
        {
            if (FolderBrowser.ShowDialog() == DialogResult.OK)
                ado.Backup(FolderBrowser.SelectedPath + pd.ToString("s").Substring(0, 10) + ".bak");
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            if (SetBackup.ShowDialog() == DialogResult.OK)
            {
                ado.Restore(SetBackup.FileName);
                DataSet ds = ado.select("select memid,name from family where depend='سرپرست'");
                if (ds.Tables[0].Rows.Count == 1)
                {
                    Properties.Settings.Default.ExistSupervisor = true;
                    Properties.Settings.Default.Save();
                }
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            Program.splashForm.Refresh();
            System.Threading.Thread.Sleep(3000);
            DataSet ds = ado.select("select * from security where password is not null");
            if (ds.Tables[0].Rows.Count == 0)
                Properties.Settings.Default.ShowLogin = false;
            Program.splashForm.Close();

            //1 lines remove after project complete
            //Properties.Settings.Default.Reset();

            if (Properties.Settings.Default.ShowLogin)
            {
                FrmLogin fl = new FrmLogin();
                fl.ShowDialog();
            }

            this.Text = "حسابداری خانواده" +"                                               "+ pd.ToString("D");
            this.Location = new Point((Screen.PrimaryScreen.WorkingArea.Width/2) - (this.Width/2) , 20);
            //ArrayList items = ribForm.RibbonStrip.GetItems("", typeof(SystemCaptionItem));
            //foreach (SystemCaptionItem sci in items)
            //{
            //    if (!sci.IsSystemIcon)
            //    {
            //        sci.Visible = false;
            //        break;
            //    }
            //}
        }

        private void btnBlack_Click(object sender, EventArgs e)
        {
            ribForm.Office2007ColorTable = DevComponents.DotNetBar.Rendering.eOffice2007ColorScheme.Black;
        }

        private void btnBlue_Click(object sender, EventArgs e)
        {
            ribForm.Office2007ColorTable = DevComponents.DotNetBar.Rendering.eOffice2007ColorScheme.Blue;
        }

        private void btnSilver_Click(object sender, EventArgs e)
        {
            ribForm.Office2007ColorTable = DevComponents.DotNetBar.Rendering.eOffice2007ColorScheme.Silver;
        }

        private void Prompt_Click(object sender, EventArgs e)
        {
            Form fp = FrmPrompt.Instance();
            fp.Show();
        }

        private void Display_Click(object sender, EventArgs e)
        {
            this.Visible = true;
            this.WindowState = FormWindowState.Normal;
        }

        private void FrmMain_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
                this.Visible = false;
        }
    }
}
