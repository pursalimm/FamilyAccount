﻿namespace FamilyAccount
{
    partial class FrmDocument
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmDocument aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDocument));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer3 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elButton1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.contextMenuPic = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnOpenPic = new System.Windows.Forms.ToolStripMenuItem();
            this.btnRemovePic = new System.Windows.Forms.ToolStripMenuItem();
            this.picdocpic = new System.Windows.Forms.PictureBox();
            this.txtdocnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtdocdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.docDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.docid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.familyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.docdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docnote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.docpic = new System.Windows.Forms.DataGridViewImageColumn();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.openPic = new System.Windows.Forms.OpenFileDialog();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.familyTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtmemidD = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton3 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtdocnoteD = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).BeginInit();
            this.elContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).BeginInit();
            this.contextMenuPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picdocpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.docDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocnoteD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtmemid);
            this.backContainer.Controls.Add(this.elContainer3);
            this.backContainer.Controls.Add(this.txtdocnote);
            this.backContainer.Controls.Add(this.txtdocdate);
            this.backContainer.Location = new System.Drawing.Point(8, 33);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(663, 229);
            this.backContainer.TabIndex = 0;
            this.backContainer.Tag = "0";
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(387, 167);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 2;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // txtmemid
            // 
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemid.CaptionStyle.CaptionSize = 75;
            this.txtmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemid.CaptionStyle.TextStyle.Text = "صاحب سند";
            this.txtmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemid.Location = new System.Drawing.Point(417, 167);
            this.txtmemid.Name = "txtmemid";
            this.txtmemid.Size = new System.Drawing.Size(238, 27);
            this.txtmemid.TabIndex = 1;
            this.txtmemid.Tag = "1";
            this.txtmemid.ValidationStyle.AcceptsTab = true;
            this.txtmemid.ValidationStyle.PasswordChar = '\0';
            this.txtmemid.ValidationStyle.ReadOnly = true;
            this.txtmemid.Value = "";
            this.txtmemid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            this.txtmemid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // elContainer3
            // 
            this.elContainer3.Controls.Add(this.elButton1);
            this.elContainer3.Controls.Add(this.picdocpic);
            this.elContainer3.Location = new System.Drawing.Point(7, 7);
            this.elContainer3.Name = "elContainer3";
            this.elContainer3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer3.Size = new System.Drawing.Size(151, 183);
            this.elContainer3.TabIndex = 4;
            this.elContainer3.Tag = "0";
            this.elContainer3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            // 
            // elButton1
            // 
            this.elButton1.BackgroundImageStyle.Alpha = 100;
            this.elButton1.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.elButton1.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.elButton1.BackgroundImageStyle.ImageSize = new System.Drawing.Size(20, 20);
            this.elButton1.ButtonStyle = Klik.Windows.Forms.v1.EntryLib.ButtonStyles.DropDownButton;
            this.elButton1.Cursor = System.Windows.Forms.Cursors.Default;
            this.elButton1.DropDownContextMenuStrip = this.contextMenuPic;
            this.elButton1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elButton1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elButton1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elButton1.Location = new System.Drawing.Point(0, 161);
            this.elButton1.Name = "elButton1";
            this.elButton1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.elButton1.Size = new System.Drawing.Size(151, 22);
            this.elButton1.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F);
            this.elButton1.TabIndex = 0;
            this.elButton1.Tag = "0";
            this.elButton1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elButton1.TextStyle.Text = "تصویر";
            this.elButton1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuPic
            // 
            this.contextMenuPic.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnOpenPic,
            this.btnRemovePic});
            this.contextMenuPic.Name = "contextMenuStrip1";
            this.contextMenuPic.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextMenuPic.Size = new System.Drawing.Size(126, 48);
            // 
            // btnOpenPic
            // 
            this.btnOpenPic.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenPic.Image")));
            this.btnOpenPic.Name = "btnOpenPic";
            this.btnOpenPic.Size = new System.Drawing.Size(125, 22);
            this.btnOpenPic.Text = "تغییر تصویر";
            this.btnOpenPic.Click += new System.EventHandler(this.btnOpenPic_Click);
            // 
            // btnRemovePic
            // 
            this.btnRemovePic.Image = ((System.Drawing.Image)(resources.GetObject("btnRemovePic.Image")));
            this.btnRemovePic.Name = "btnRemovePic";
            this.btnRemovePic.Size = new System.Drawing.Size(125, 22);
            this.btnRemovePic.Text = "حذف تصویر";
            this.btnRemovePic.Click += new System.EventHandler(this.btnRemovePic_Click);
            // 
            // picdocpic
            // 
            this.picdocpic.BackColor = System.Drawing.Color.Transparent;
            this.picdocpic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picdocpic.Image = ((System.Drawing.Image)(resources.GetObject("picdocpic.Image")));
            this.picdocpic.Location = new System.Drawing.Point(4, 3);
            this.picdocpic.Name = "picdocpic";
            this.picdocpic.Size = new System.Drawing.Size(143, 177);
            this.picdocpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picdocpic.TabIndex = 69;
            this.picdocpic.TabStop = false;
            this.picdocpic.DoubleClick += new System.EventHandler(this.picdocpic_DoubleClick);
            // 
            // txtdocnote
            // 
            this.txtdocnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtdocnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtdocnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtdocnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocnote.CaptionStyle.TextStyle.Text = "شرح سند";
            this.txtdocnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtdocnote.Location = new System.Drawing.Point(7, 196);
            this.txtdocnote.Name = "txtdocnote";
            this.txtdocnote.Size = new System.Drawing.Size(649, 27);
            this.txtdocnote.TabIndex = 3;
            this.txtdocnote.Tag = "1";
            this.txtdocnote.ValidationStyle.AcceptsTab = true;
            this.txtdocnote.ValidationStyle.PasswordChar = '\0';
            this.txtdocnote.Value = "";
            this.txtdocnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // txtdocdate
            // 
            this.txtdocdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtdocdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtdocdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtdocdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtdocdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocdate.CaptionStyle.TextStyle.Text = "تاریخ ثبت";
            this.txtdocdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtdocdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdocdate.Location = new System.Drawing.Point(473, 138);
            this.txtdocdate.Name = "txtdocdate";
            this.txtdocdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtdocdate.Size = new System.Drawing.Size(182, 27);
            this.txtdocdate.TabIndex = 0;
            this.txtdocdate.Tag = "1";
            this.txtdocdate.ValidationStyle.AcceptsTab = true;
            this.txtdocdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtdocdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtdocdate.ValidationStyle.PasswordChar = '\0';
            this.txtdocdate.Value = "";
            this.txtdocdate.Leave += new System.EventHandler(this.txtdocdate_Leave);
            this.txtdocdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.Controls.Add(this.docDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.Location = new System.Drawing.Point(8, 265);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(663, 198);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // docDataGrid
            // 
            this.docDataGrid.AllowUserToAddRows = false;
            this.docDataGrid.AllowUserToDeleteRows = false;
            this.docDataGrid.AllowUserToResizeColumns = false;
            this.docDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.docDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.docDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.docDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.docDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.docDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.docDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.docDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.docDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.docid,
            this.memid,
            this.docdate,
            this.docnote,
            this.docpic});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.docDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.docDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.docDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.docDataGrid.Location = new System.Drawing.Point(1, 16);
            this.docDataGrid.MultiSelect = false;
            this.docDataGrid.Name = "docDataGrid";
            this.docDataGrid.ReadOnly = true;
            this.docDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.docDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.docDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.docDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.docDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.docDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.docDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.docDataGrid.ShowCellErrors = false;
            this.docDataGrid.ShowCellToolTips = false;
            this.docDataGrid.ShowEditingIcon = false;
            this.docDataGrid.ShowRowErrors = false;
            this.docDataGrid.Size = new System.Drawing.Size(661, 166);
            this.docDataGrid.TabIndex = 0;
            this.docDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.docDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.docDataGrid_MouseClick);
            this.docDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.docDataGrid_CellClick);
            this.docDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.docDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // docid
            // 
            this.docid.DataPropertyName = "docid";
            this.docid.HeaderText = "کد";
            this.docid.Name = "docid";
            this.docid.ReadOnly = true;
            this.docid.Visible = false;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.DataSource = this.familyBindingSource;
            this.memid.DisplayMember = "name";
            this.memid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.memid.HeaderText = "صاحب سند";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.memid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.memid.ValueMember = "memid";
            // 
            // familyBindingSource
            // 
            this.familyBindingSource.DataMember = "family";
            this.familyBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // docdate
            // 
            this.docdate.DataPropertyName = "docdate";
            this.docdate.HeaderText = "تاریخ ثبت";
            this.docdate.Name = "docdate";
            this.docdate.ReadOnly = true;
            // 
            // docnote
            // 
            this.docnote.DataPropertyName = "docnote";
            this.docnote.HeaderText = "شرح سند";
            this.docnote.Name = "docnote";
            this.docnote.ReadOnly = true;
            // 
            // docpic
            // 
            this.docpic.DataPropertyName = "docpic";
            this.docpic.HeaderText = "تصویر";
            this.docpic.Name = "docpic";
            this.docpic.ReadOnly = true;
            this.docpic.Visible = false;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(95, 470);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // familyTableAdapter
            // 
            this.familyTableAdapter.ClearBeforeFill = true;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(8, 8, 663, 254);
            this.expandPanel.Location = new System.Drawing.Point(8, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(663, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 5;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.txtmemidD);
            this.BackSearch.Controls.Add(this.txtenddate);
            this.BackSearch.Controls.Add(this.txtdocnoteD);
            this.BackSearch.Controls.Add(this.txtstartdate);
            this.BackSearch.Location = new System.Drawing.Point(10, 34);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(644, 177);
            this.BackSearch.TabIndex = 21;
            // 
            // txtmemidD
            // 
            this.txtmemidD.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemidD.CaptionStyle.CaptionSize = 70;
            this.txtmemidD.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemidD.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemidD.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemidD.CaptionStyle.TextStyle.Text = "صاحب سند";
            this.txtmemidD.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemidD.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemidD.Location = new System.Drawing.Point(391, 9);
            this.txtmemidD.Name = "txtmemidD";
            this.txtmemidD.Size = new System.Drawing.Size(244, 27);
            this.txtmemidD.TabIndex = 0;
            this.txtmemidD.Tag = "1";
            this.txtmemidD.ValidationStyle.AcceptsTab = true;
            this.txtmemidD.ValidationStyle.PasswordChar = '\0';
            this.txtmemidD.Value = "";
            this.txtmemidD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton3);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.CaptionSize = 70;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(465, 93);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(170, 27);
            this.txtenddate.TabIndex = 3;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // elEntryBoxButton3
            // 
            this.elEntryBoxButton3.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton3.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton3.DropDownContextMenuStrip = this.contextDate;
            // 
            // txtdocnoteD
            // 
            this.txtdocnoteD.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtdocnoteD.CaptionStyle.CaptionSize = 70;
            this.txtdocnoteD.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtdocnoteD.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtdocnoteD.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtdocnoteD.CaptionStyle.TextStyle.Text = "شرح سند";
            this.txtdocnoteD.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdocnoteD.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtdocnoteD.Location = new System.Drawing.Point(17, 37);
            this.txtdocnoteD.Name = "txtdocnoteD";
            this.txtdocnoteD.Size = new System.Drawing.Size(618, 27);
            this.txtdocnoteD.TabIndex = 1;
            this.txtdocnoteD.Tag = "1";
            this.txtdocnoteD.ValidationStyle.AcceptsTab = true;
            this.txtdocnoteD.ValidationStyle.PasswordChar = '\0';
            this.txtdocnoteD.Value = "";
            this.txtdocnoteD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.CaptionSize = 70;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(465, 65);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(170, 27);
            this.txtstartdate.TabIndex = 2;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdocid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(82, 218);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 11;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(7, 218);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 6;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmDocument
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 518);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.elRichPanel1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmDocument";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اسناد مالی و اداری";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmDocument_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).EndInit();
            this.elContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elButton1)).EndInit();
            this.contextMenuPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picdocpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.docDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdocnoteD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtdocdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtdocnote;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer3;
        private System.Windows.Forms.PictureBox picdocpic;
        private System.Windows.Forms.OpenFileDialog openPic;
        private System.Windows.Forms.ContextMenuStrip contextMenuPic;
        private System.Windows.Forms.ToolStripMenuItem btnOpenPic;
        private System.Windows.Forms.ToolStripMenuItem btnRemovePic;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView docDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemid;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource familyBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter familyTableAdapter;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn docid;
        private System.Windows.Forms.DataGridViewComboBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn docdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn docnote;
        private System.Windows.Forms.DataGridViewImageColumn docpic;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemidD;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtdocnoteD;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
    }
}