﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    public partial class FrmSetcheq : Form
    {
        string idSel = "";
        string accountID = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public FrmSetcheq(string accID)
        {
            InitializeComponent();
            accountID = accID;
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from cheqset where accid='"+accountID+"'");
            SetDataGrid.DataSource = ds.Tables[0];
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backSet.Enabled = true;
            ado.ClearControl(backSet);
            txtaccid.Text = accountID;
            txtaccid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backSet)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into cheqset values(@accid,@csseries,@csdate,@csfirst,@csend)";
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@csseries", SqlDbType.NVarChar).Value = txtcsseries.Text;
            cmd.Parameters.Add("@csdate", SqlDbType.NVarChar).Value = txtcsdate.Text;
            cmd.Parameters.Add("@csfirst", SqlDbType.NVarChar).Value = txtcsfirst.Text;
            cmd.Parameters.Add("@csend", SqlDbType.NVarChar).Value = txtcsend.Text;
            if (ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backSet);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backSet)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update cheqset set accid=@accid,@csseries=@csseries,csdate=@csdate,csfirst=@csfirst,csend=@csend where csid=@csid";
            cmd.Parameters.Add("@csid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@csseries", SqlDbType.NVarChar).Value = txtcsseries.Text;
            cmd.Parameters.Add("@csdate", SqlDbType.NVarChar).Value = txtcsdate.Text;
            cmd.Parameters.Add("@csfirst", SqlDbType.NVarChar).Value = txtcsfirst.Text;
            cmd.Parameters.Add("@csend", SqlDbType.NVarChar).Value = txtcsend.Text;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backSet);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from cheqset where csid=@csid";
            cmd.Parameters.Add("@csid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backSet);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backSet.Enabled = false;
            ado.ClearControl(backSet);
            txtaccid.Text = accountID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void txtcsdate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void SelectedData()
        {
            idSel = SetDataGrid["csidS", SetDataGrid.CurrentRow.Index].Value.ToString();
            txtaccid.Text = SetDataGrid["accid", SetDataGrid.CurrentRow.Index].Value.ToString();
            txtcsseries.Text = SetDataGrid["csseries", SetDataGrid.CurrentRow.Index].Value.ToString();
            txtcsdate.Text = SetDataGrid["csdate", SetDataGrid.CurrentRow.Index].Value.ToString();
            txtcsfirst.Text = SetDataGrid["csfirst", SetDataGrid.CurrentRow.Index].Value.ToString();
            txtcsend.Text = SetDataGrid["csend", SetDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void SetDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (SetDataGrid.RowCount > 0)
            {
                if (SetDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backSet.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backSet.Enabled = false;
                }
            }
        }

        private void SetDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && SetDataGrid.RowCount > 0)
            {
                SelectedData();
                if (SetDataGrid.CurrentRow.Index == 0)
                    SetDataGrid[0, 0].Selected = true;
                else
                    SetDataGrid[0, SetDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void SetDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && SetDataGrid.RowCount > 0)
                SelectedData();
        }

        private void FrmSetcheq_Load(object sender, EventArgs e)
        {
            txtaccid.Text = accountID;
            GridRefresh();
            ado.SetFarsiLanguage();
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
        }

        private void txtcsdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtcsdate);
        }

        private void txtaccid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }


    }
}
