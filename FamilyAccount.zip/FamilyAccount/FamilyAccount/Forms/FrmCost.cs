﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmCost : Form
    {
        string idSel = "";
        string selectedkeybcid = string.Empty;
        string selectedkeymem = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmCost()
        {
            InitializeComponent();
        }

        public static FrmCost Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmCost();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtbcid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into cost values(@bcid,@memid,@costdate,@costnote,@costquan)";
            cmd.Parameters.Add("@bcid", SqlDbType.Int).Value = selectedkeybcid;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@costdate", SqlDbType.NVarChar).Value = txtcostdate.Text;
            cmd.Parameters.Add("@costnote", SqlDbType.NText).Value = txtcostnote.Text;
            cmd.Parameters.Add("@costquan", SqlDbType.Money).Value = txtcostquan.Value;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update cost set bcid=@bcid,memid=@memid,costdate=@costdate,costnote=@costnote,costquan=@costquan where cid=@cid";
            cmd.Parameters.Add("@cid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@bcid", SqlDbType.Int).Value = selectedkeybcid;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@costdate", SqlDbType.NVarChar).Value = txtcostdate.Text;
            cmd.Parameters.Add("@costnote", SqlDbType.NText).Value = txtcostnote.Text;
            cmd.Parameters.Add("@costquan", SqlDbType.Money).Value = txtcostquan.Value;
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from cost where cid=@cid";
            cmd.Parameters.Add("@cid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2,MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmCost_Load(object sender, EventArgs e)
        {
            familyTableAdapter.Fill(accountDataSet.family);
            basecostTableAdapter.Fill(accountDataSet.basecost);
            GridRefresh(); 
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtcid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("SELECT * from cost");
            costDataGrid.DataSource = ds.Tables[0];
            if (costDataGrid.RowCount > 0)
            {
                double sum = 0;
                foreach (DataGridViewRow row in costDataGrid.Rows)
                    sum += Convert.ToDouble(row.Cells["costquan"].Value);
                lblsum.Text = sum.ToString("C0");
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
            lblCostquan.Text = "";
        }

        private void costDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (costDataGrid.RowCount > 0)
            {
                if (costDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void SelectedData()
        {
            idSel = costDataGrid["cid", costDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybcid = costDataGrid["bcid", costDataGrid.CurrentRow.Index].Value.ToString();
            txtbcid.Text = costDataGrid["bcid", costDataGrid.CurrentRow.Index].FormattedValue.ToString();
            selectedkeymem = costDataGrid["memid", costDataGrid.CurrentRow.Index].Value.ToString();
            txtmemid.Text = costDataGrid["memid", costDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtcostdate.Text = costDataGrid["costdate", costDataGrid.CurrentRow.Index].Value.ToString();
            txtcostnote.Text = costDataGrid["costnote", costDataGrid.CurrentRow.Index].Value.ToString();
            txtcostquan.Text = costDataGrid["costquan", costDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void costDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && costDataGrid.RowCount > 0)
            {
                SelectedData();
                if (costDataGrid.CurrentRow.Index == 0)
                    costDataGrid[0, 0].Selected = true;
                else
                    costDataGrid[0, costDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void costDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && costDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtcostquan_TextChanged(object sender, EventArgs e)
        {
            if (txtcostquan.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcostquan.Text) == null) return;
                if (ado.ExtractNumbers(txtcostquan.Text).Length == 13) ProcessTabKey(true);
                lblCostquan.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcostquan.Text))) + " ریال";
            }
            else
                lblCostquan.Text = "";
        }

        private void txtcostdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtcostdate);
        }

        private void txtcostquan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void btnIns1_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from basecost");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from basecost");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybcid = dgvr.Cells[0].Value.ToString();
                txtbcid.Text = dgvr.Cells[1].Value.ToString();
                txtbcidC.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnIns2_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymem = dgvr.Cells[0].Value.ToString();
                txtmemid.Text = dgvr.Cells[1].Value.ToString();
                txtmemidC.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtbcid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT co.cid, co.bcid, co.memid, co.costdate, co.costnote, co.costquan FROM cost AS co INNER JOIN basecost AS bc ON co.bcid = bc.bcid INNER JOIN family AS fa ON co.memid = fa.memid WHERE (co.cid <> 0) ";
            if (txtbcidC.Text.Trim().Length != 0)
                query += "AND bc.costname like (N'%" + txtbcidC.Text + "%')";
            if (txtmemidC.Text.Trim().Length != 0)
                query += "AND fa.name like (N'%" + txtmemidC.Text + "%')";
            if (txtcostnote.Text.Trim().Length != 0)
                query += "AND co.costnote like (N'%" + txtcostnote.Text + "%')";
            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND co.costdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND co.costdate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND co.costdate < '" + txtenddate.Text + "'";

            if (txtcostmin.Value.ToString() != "0" && txtcostmax.Value.ToString() != "0")
                query += "AND costquan between " + txtcostmin.Value.ToString() + " and " + txtcostmax.Value.ToString();
            else if (txtcostmin.Value.ToString() != "0")
                query += "AND costquan > " + txtcostmin.Value.ToString();
            else if (txtcostmax.Value.ToString() != "0")
                query += "AND costquan < " + txtcostmax.Value.ToString();

            DataSet ds = ado.select(query);
            costDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT co.cid, co.bcid, co.memid, co.costdate, co.costnote, co.costquan FROM cost AS co INNER JOIN basecost AS bc ON co.bcid = bc.bcid INNER JOIN family AS fa ON co.memid = fa.memid WHERE (co.cid <> 0) ");
            costDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }
    }
}
