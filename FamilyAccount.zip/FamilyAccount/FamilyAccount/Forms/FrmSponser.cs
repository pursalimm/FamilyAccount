﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FamilyAccount
{
    public partial class FrmSponser : Form
    {
        string idSel = "";
        string loanCode = string.Empty;
        string selectedpid = string.Empty;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmSponser(string loan)
        {
            InitializeComponent();
            loanCode = loan;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtptname.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            if (ado.ValidateControl(backContainer)) return;
            cmd.CommandText = "insert into sponser values(@loanid,@ptname,@pthome,@ptwork,@ptmobile,@ptadres)";
            cmd.Parameters.Add("@loanid", SqlDbType.Int).Value = loanCode;
            cmd.Parameters.Add("@ptname", SqlDbType.NVarChar).Value = txtptname.Text;
            cmd.Parameters.Add("@pthome", SqlDbType.NVarChar).Value = txtpthome.Text;
            cmd.Parameters.Add("@ptwork", SqlDbType.NVarChar).Value = txtptwork.Text;
            cmd.Parameters.Add("@ptmobile", SqlDbType.NVarChar).Value = txtptmobile.Text;
            cmd.Parameters.Add("@ptadres", SqlDbType.NText).Value = txtptadres.Text;
            if (ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            if (ado.ValidateControl(backContainer)) return;
            cmd.CommandText = "update sponser set loanid=@loanid,ptname=@ptname,pthome=@pthome,ptwork=@ptwork,ptmobile=@ptmobile,ptadres=@ptadres where pid=@pid";
            cmd.Parameters.Add("@pid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@loanid", SqlDbType.Int).Value = loanCode;
            cmd.Parameters.Add("@ptname", SqlDbType.NVarChar).Value = txtptname.Text;
            cmd.Parameters.Add("@pthome", SqlDbType.NVarChar).Value = txtpthome.Text;
            cmd.Parameters.Add("@ptwork", SqlDbType.NVarChar).Value = txtptwork.Text;
            cmd.Parameters.Add("@ptmobile", SqlDbType.NVarChar).Value = txtptmobile.Text;
            cmd.Parameters.Add("@ptadres", SqlDbType.NText).Value = txtptadres.Text;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from sponser where pid=@pid";
            cmd.Parameters.Add("@pid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SelectedData()
        {
            idSel = personDataGrid["pid", personDataGrid.CurrentRow.Index].Value.ToString();
            txtptname.Text = personDataGrid["ptname", personDataGrid.CurrentRow.Index].Value.ToString();
            txtpthome.Text = personDataGrid["pthome", personDataGrid.CurrentRow.Index].Value.ToString();
            txtptwork.Text = personDataGrid["ptwork", personDataGrid.CurrentRow.Index].Value.ToString();
            txtptmobile.Text = personDataGrid["ptmobile", personDataGrid.CurrentRow.Index].Value.ToString();
            txtptadres.Text = personDataGrid["ptadres", personDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void personDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && personDataGrid.RowCount > 0)
            {
                SelectedData();
                if (personDataGrid.CurrentRow.Index == 0)
                    personDataGrid[0, 0].Selected = true;
                else
                    personDataGrid[0, personDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void personDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && personDataGrid.RowCount > 0)
                SelectedData();
        }

        private void personDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (personDataGrid.RowCount > 0)
            {
                if (personDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from sponser where loanid='" + loanCode + "'");
            personDataGrid.DataSource = ds.Tables[0];
        }

        private void txtptname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void FrmSponser_Load(object sender, EventArgs e)
        {
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT DISTINCT ptname FROM sponser");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT DISTINCT ptname FROM sponser");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
                txtptname.Text = dgvr.Cells[0].Value.ToString();
            ProcessTabKey(true);
        }
    }
}
