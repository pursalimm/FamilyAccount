﻿namespace FamilyAccount
{
    partial class FrmAcccard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAcccard));
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.acccardDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.cid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.familyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.cardid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.settlenum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cvv2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstpass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.secondpass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtsettlenum = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsecondpass = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtfirstpass = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcvv2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcardid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.familyTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acccardDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsettlenum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecondpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfirstpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcvv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcardid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel1.Controls.Add(this.acccardDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel1.Location = new System.Drawing.Point(7, 163);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(589, 195);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // acccardDataGrid
            // 
            this.acccardDataGrid.AllowUserToAddRows = false;
            this.acccardDataGrid.AllowUserToDeleteRows = false;
            this.acccardDataGrid.AllowUserToResizeColumns = false;
            this.acccardDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.acccardDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.acccardDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.acccardDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.acccardDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.acccardDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acccardDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.acccardDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.acccardDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.cid,
            this.accid,
            this.memid,
            this.cardid,
            this.settlenum,
            this.cvv2,
            this.firstpass,
            this.secondpass});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.acccardDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.acccardDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.acccardDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.acccardDataGrid.Location = new System.Drawing.Point(1, 16);
            this.acccardDataGrid.MultiSelect = false;
            this.acccardDataGrid.Name = "acccardDataGrid";
            this.acccardDataGrid.ReadOnly = true;
            this.acccardDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.acccardDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.acccardDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.acccardDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.acccardDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.acccardDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.acccardDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.acccardDataGrid.ShowCellErrors = false;
            this.acccardDataGrid.ShowCellToolTips = false;
            this.acccardDataGrid.ShowEditingIcon = false;
            this.acccardDataGrid.ShowRowErrors = false;
            this.acccardDataGrid.Size = new System.Drawing.Size(587, 163);
            this.acccardDataGrid.TabIndex = 0;
            this.acccardDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.acccardDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.acccardDataGrid_MouseClick);
            this.acccardDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.acccardDataGrid_CellClick);
            this.acccardDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.acccardDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            this.Select.Width = 19;
            // 
            // cid
            // 
            this.cid.DataPropertyName = "cid";
            this.cid.HeaderText = "شماره";
            this.cid.Name = "cid";
            this.cid.ReadOnly = true;
            this.cid.Visible = false;
            this.cid.Width = 66;
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            this.accid.Width = 104;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.DataSource = this.familyBindingSource;
            this.memid.DisplayMember = "name";
            this.memid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.memid.HeaderText = "صاحب کارت";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.memid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.memid.ValueMember = "memid";
            this.memid.Width = 93;
            // 
            // familyBindingSource
            // 
            this.familyBindingSource.DataMember = "family";
            this.familyBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cardid
            // 
            this.cardid.DataPropertyName = "cardid";
            this.cardid.HeaderText = "شماره کارت";
            this.cardid.Name = "cardid";
            this.cardid.ReadOnly = true;
            this.cardid.Width = 94;
            // 
            // settlenum
            // 
            this.settlenum.DataPropertyName = "settlenum";
            this.settlenum.HeaderText = "شناسه واریز";
            this.settlenum.Name = "settlenum";
            this.settlenum.ReadOnly = true;
            this.settlenum.Width = 99;
            // 
            // cvv2
            // 
            this.cvv2.DataPropertyName = "cvv2";
            this.cvv2.HeaderText = "CVV2";
            this.cvv2.Name = "cvv2";
            this.cvv2.ReadOnly = true;
            this.cvv2.Visible = false;
            this.cvv2.Width = 60;
            // 
            // firstpass
            // 
            this.firstpass.DataPropertyName = "firstpass";
            this.firstpass.HeaderText = "رمز اول";
            this.firstpass.Name = "firstpass";
            this.firstpass.ReadOnly = true;
            this.firstpass.Visible = false;
            this.firstpass.Width = 71;
            // 
            // secondpass
            // 
            this.secondpass.DataPropertyName = "secondpass";
            this.secondpass.HeaderText = "رمز دوم";
            this.secondpass.Name = "secondpass";
            this.secondpass.ReadOnly = true;
            this.secondpass.Visible = false;
            this.secondpass.Width = 72;
            // 
            // txtsettlenum
            // 
            this.txtsettlenum.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsettlenum.CaptionStyle.CaptionSize = 90;
            this.txtsettlenum.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsettlenum.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsettlenum.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsettlenum.CaptionStyle.TextStyle.Text = "شناسه واریز";
            this.txtsettlenum.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsettlenum.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsettlenum.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsettlenum.Location = new System.Drawing.Point(9, 62);
            this.txtsettlenum.Name = "txtsettlenum";
            this.txtsettlenum.Size = new System.Drawing.Size(224, 27);
            this.txtsettlenum.TabIndex = 4;
            this.txtsettlenum.Tag = "0";
            this.txtsettlenum.ValidationStyle.AcceptsTab = true;
            this.txtsettlenum.ValidationStyle.PasswordChar = '\0';
            this.txtsettlenum.Value = "";
            this.txtsettlenum.Leave += new System.EventHandler(this.txtcardid_Leave);
            this.txtsettlenum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtsettlenum.Enter += new System.EventHandler(this.txtcardid_Enter);
            // 
            // txtsecondpass
            // 
            this.txtsecondpass.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsecondpass.CaptionStyle.CaptionSize = 90;
            this.txtsecondpass.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsecondpass.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsecondpass.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsecondpass.CaptionStyle.TextStyle.Text = "رمز دوم";
            this.txtsecondpass.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsecondpass.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsecondpass.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsecondpass.Location = new System.Drawing.Point(54, 118);
            this.txtsecondpass.Name = "txtsecondpass";
            this.txtsecondpass.Size = new System.Drawing.Size(178, 27);
            this.txtsecondpass.TabIndex = 7;
            this.txtsecondpass.Tag = "0";
            this.txtsecondpass.ValidationStyle.AcceptsTab = true;
            this.txtsecondpass.ValidationStyle.MaskValidationStyle.Mask = "00000";
            this.txtsecondpass.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Numeric;
            this.txtsecondpass.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsecondpass.ValidationStyle.PasswordChar = '\0';
            this.txtsecondpass.ValidationStyle.UseSystemPasswordChar = true;
            this.txtsecondpass.Value = "";
            this.txtsecondpass.Leave += new System.EventHandler(this.txtcardid_Leave);
            this.txtsecondpass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtsecondpass.Enter += new System.EventHandler(this.txtcardid_Enter);
            // 
            // txtfirstpass
            // 
            this.txtfirstpass.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtfirstpass.CaptionStyle.CaptionSize = 90;
            this.txtfirstpass.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtfirstpass.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtfirstpass.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstpass.CaptionStyle.TextStyle.Text = "رمز اول";
            this.txtfirstpass.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstpass.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtfirstpass.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtfirstpass.Location = new System.Drawing.Point(402, 118);
            this.txtfirstpass.Name = "txtfirstpass";
            this.txtfirstpass.Size = new System.Drawing.Size(178, 27);
            this.txtfirstpass.TabIndex = 6;
            this.txtfirstpass.Tag = "0";
            this.txtfirstpass.ValidationStyle.AcceptsTab = true;
            this.txtfirstpass.ValidationStyle.MaskValidationStyle.Mask = "0000";
            this.txtfirstpass.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Numeric;
            this.txtfirstpass.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtfirstpass.ValidationStyle.PasswordChar = '\0';
            this.txtfirstpass.ValidationStyle.UseSystemPasswordChar = true;
            this.txtfirstpass.Value = "";
            this.txtfirstpass.Leave += new System.EventHandler(this.txtcardid_Leave);
            this.txtfirstpass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtfirstpass.Enter += new System.EventHandler(this.txtcardid_Enter);
            // 
            // txtcvv2
            // 
            this.txtcvv2.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcvv2.CaptionStyle.CaptionSize = 90;
            this.txtcvv2.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcvv2.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcvv2.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcvv2.CaptionStyle.TextStyle.Text = "رمز اینترنتی";
            this.txtcvv2.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcvv2.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcvv2.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcvv2.Location = new System.Drawing.Point(382, 90);
            this.txtcvv2.Name = "txtcvv2";
            this.txtcvv2.Size = new System.Drawing.Size(198, 27);
            this.txtcvv2.TabIndex = 5;
            this.txtcvv2.Tag = "0";
            this.txtcvv2.ValidationStyle.AcceptsTab = true;
            this.txtcvv2.ValidationStyle.PasswordChar = '\0';
            this.txtcvv2.ValidationStyle.UseSystemPasswordChar = true;
            this.txtcvv2.Value = "";
            this.txtcvv2.Leave += new System.EventHandler(this.txtcardid_Leave);
            this.txtcvv2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtcvv2.Enter += new System.EventHandler(this.txtcardid_Enter);
            // 
            // txtcardid
            // 
            this.txtcardid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcardid.CaptionStyle.CaptionSize = 90;
            this.txtcardid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcardid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcardid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcardid.CaptionStyle.TextStyle.Text = "شماره کارت";
            this.txtcardid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcardid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcardid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcardid.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.txtcardid.Location = new System.Drawing.Point(357, 62);
            this.txtcardid.Name = "txtcardid";
            this.txtcardid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtcardid.Size = new System.Drawing.Size(223, 27);
            this.txtcardid.TabIndex = 3;
            this.txtcardid.Tag = "1";
            this.txtcardid.ValidationStyle.AcceptsTab = true;
            this.txtcardid.ValidationStyle.DateTimeValidationStyle.EntryType = Klik.Windows.Forms.v1.EntryLib.DateTimeEntryTypes.Masked;
            this.txtcardid.ValidationStyle.MaskValidationStyle.Mask = "0000000000000000";
            this.txtcardid.ValidationStyle.PasswordChar = '\0';
            this.txtcardid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtcardid.Value = "                ";
            this.txtcardid.Leave += new System.EventHandler(this.txtcardid_Leave);
            this.txtcardid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtcardid.Enter += new System.EventHandler(this.txtcardid_Enter);
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtaccid);
            this.backContainer.Controls.Add(this.txtmemid);
            this.backContainer.Controls.Add(this.txtsettlenum);
            this.backContainer.Controls.Add(this.txtcardid);
            this.backContainer.Controls.Add(this.txtcvv2);
            this.backContainer.Controls.Add(this.txtsecondpass);
            this.backContainer.Controls.Add(this.txtfirstpass);
            this.backContainer.Location = new System.Drawing.Point(7, 6);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(589, 150);
            this.backContainer.TabIndex = 1;
            this.backContainer.Tag = "0";
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(313, 34);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 2;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 90;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccid.Location = new System.Drawing.Point(342, 6);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(238, 27);
            this.txtaccid.TabIndex = 0;
            this.txtaccid.Tag = "0";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.ValidationStyle.ReadOnly = true;
            this.txtaccid.Value = "";
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtaccid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // txtmemid
            // 
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemid.CaptionStyle.CaptionSize = 85;
            this.txtmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemid.CaptionStyle.TextStyle.Text = "دارنده کارت";
            this.txtmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemid.Location = new System.Drawing.Point(342, 34);
            this.txtmemid.Name = "txtmemid";
            this.txtmemid.Size = new System.Drawing.Size(238, 27);
            this.txtmemid.TabIndex = 1;
            this.txtmemid.Tag = "1";
            this.txtmemid.ValidationStyle.AcceptsTab = true;
            this.txtmemid.ValidationStyle.PasswordChar = '\0';
            this.txtmemid.ValidationStyle.ReadOnly = true;
            this.txtmemid.Value = "";
            this.txtmemid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirstpass_KeyPress);
            this.txtmemid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(59, 364);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // familyTableAdapter
            // 
            this.familyTableAdapter.ClearBeforeFill = true;
            // 
            // FrmAcccard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 412);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elRichPanel1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmAcccard";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "کارت های اعتباری (عابر بانک)";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmAcccard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acccardDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsettlenum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecondpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfirstpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcvv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcardid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcardid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsettlenum;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsecondpass;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtfirstpass;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcvv2;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView acccardDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource familyBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter familyTableAdapter;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn cid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewComboBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn cardid;
        private System.Windows.Forms.DataGridViewTextBoxColumn settlenum;
        private System.Windows.Forms.DataGridViewTextBoxColumn cvv2;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstpass;
        private System.Windows.Forms.DataGridViewTextBoxColumn secondpass;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
    }
}