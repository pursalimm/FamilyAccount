﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FamilyAccount
{
    public partial class FrmAbout : Form
    {
        public FrmAbout()
        {
            InitializeComponent();
        }

        public static FrmAbout Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmAbout();
            }
            return aForm;
        }

        private void FrmAbout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
