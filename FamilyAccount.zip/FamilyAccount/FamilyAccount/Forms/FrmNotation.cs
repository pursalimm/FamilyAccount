﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmNotation : Form
    {
        string idSel = "";
        string selectedkeybaid = "";
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmNotation()
        {
            InitializeComponent();
        }

        public static FrmNotation Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmNotation();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtstartdate.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into notation values(@baid,@startdate,@time,@note)";
            cmd.Parameters.Add("@baid", SqlDbType.Int).Value = selectedkeybaid;
            cmd.Parameters.Add("@startdate", SqlDbType.NVarChar).Value = txtstartdate.Text;
            cmd.Parameters.Add("@time", SqlDbType.NVarChar).Value = txttime.Text;
            cmd.Parameters.Add("@note", SqlDbType.NText).Value = txtnote.Text;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update notation set baid=@baid,startdate=@startdate,time=@time,note=@note where nid=@nid";
            cmd.Parameters.Add("@nid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@baid", SqlDbType.Int).Value = selectedkeybaid;
            cmd.Parameters.Add("@startdate", SqlDbType.NVarChar).Value = txtstartdate.Text;
            cmd.Parameters.Add("@time", SqlDbType.NVarChar).Value = txttime.Text;
            cmd.Parameters.Add("@note", SqlDbType.NText).Value = txtnote.Text;
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from notation where nid=@nid";
            cmd.Parameters.Add("@nid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmNotation_Load(object sender, EventArgs e)
        {
            baseactTableAdapter.Fill(accountDataSet.baseact);
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtnotedate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from notation");
            noteDataGrid.DataSource = ds.Tables[0];
        }

        private void noteDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (noteDataGrid.RowCount > 0)
            {
                if (noteDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void SelectedData()
        {
            idSel = noteDataGrid["nid", noteDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybaid = noteDataGrid["baid", noteDataGrid.CurrentRow.Index].Value.ToString();
            txtbaid.Text = noteDataGrid["baid", noteDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtstartdate.Text = noteDataGrid["startdate", noteDataGrid.CurrentRow.Index].Value.ToString();
            txttime.Text = noteDataGrid["time", noteDataGrid.CurrentRow.Index].Value.ToString();
            txtnote.Text = noteDataGrid["note", noteDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void noteDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && noteDataGrid.RowCount > 0)
            {
                SelectedData();
                if (noteDataGrid.CurrentRow.Index == 0)
                    noteDataGrid[0, 0].Selected = true;
                else
                    noteDataGrid[0, noteDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void noteDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && noteDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from baseact");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from baseact");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybaid = dgvr.Cells[0].Value.ToString();
                txtbaid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtbaid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }
    }
}
