﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace FamilyAccount
{
    public partial class FrmSplash : Form
    {
        public FrmSplash()
        {
            InitializeComponent();
        }

        private GraphicsPath gpath = new GraphicsPath();
        private void FrmSplash_Load(object sender, EventArgs e)
        {
            Rectangle rc;//
            Image MYBGimage = this.BackgroundImage;
            Bitmap MYBGbmp = new Bitmap(MYBGimage);
            for (int i = 0; i < MYBGbmp.Width; i++)
            {
                for (int j = 0; j < MYBGbmp.Height; j++)
                {
                    rc = new Rectangle(i, j, 1, 1);
                    if (MYBGbmp.GetPixel(i, j).ToArgb() != Color.White.ToArgb())
                    {
                        gpath.AddRectangle(rc);
                    }
                }
            }
            this.Region = new Region(gpath);
        }
    }
}
