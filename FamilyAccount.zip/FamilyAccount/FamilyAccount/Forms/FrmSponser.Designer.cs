﻿namespace FamilyAccount
{
    partial class FrmSponser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSponser));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtptadres = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtptwork = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtpthome = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtptmobile = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtptname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elRichPanel6 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.personDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectP = new System.Windows.Forms.DataGridViewButtonColumn();
            this.pid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ptname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pthome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ptwork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ptmobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ptadres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptadres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptwork)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpthome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptmobile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel6)).BeginInit();
            this.elRichPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.personDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtptadres);
            this.backContainer.Controls.Add(this.txtptwork);
            this.backContainer.Controls.Add(this.txtpthome);
            this.backContainer.Controls.Add(this.txtptmobile);
            this.backContainer.Controls.Add(this.txtptname);
            this.backContainer.Location = new System.Drawing.Point(9, 7);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(549, 128);
            this.backContainer.TabIndex = 1;
            this.backContainer.Tag = "0";
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(232, 6);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 19;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // txtptadres
            // 
            this.txtptadres.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtptadres.CaptionStyle.CaptionSize = 110;
            this.txtptadres.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtptadres.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtptadres.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtptadres.CaptionStyle.TextStyle.Text = "آدرس";
            this.txtptadres.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtptadres.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtptadres.Location = new System.Drawing.Point(7, 93);
            this.txtptadres.Name = "txtptadres";
            this.txtptadres.Size = new System.Drawing.Size(534, 27);
            this.txtptadres.TabIndex = 18;
            this.txtptadres.Tag = "0";
            this.txtptadres.ValidationStyle.AcceptsTab = true;
            this.txtptadres.ValidationStyle.PasswordChar = '\0';
            this.txtptadres.ValidationStyle.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtptadres.Value = "";
            this.txtptadres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtptname_KeyPress);
            // 
            // txtptwork
            // 
            this.txtptwork.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtptwork.CaptionStyle.CaptionSize = 110;
            this.txtptwork.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtptwork.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtptwork.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtptwork.CaptionStyle.TextStyle.Text = "تلفن محل کار";
            this.txtptwork.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtptwork.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtptwork.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtptwork.Location = new System.Drawing.Point(7, 35);
            this.txtptwork.Name = "txtptwork";
            this.txtptwork.Size = new System.Drawing.Size(203, 27);
            this.txtptwork.TabIndex = 16;
            this.txtptwork.Tag = "0";
            this.txtptwork.ValidationStyle.AcceptsTab = true;
            this.txtptwork.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtptwork.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtptwork.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txtptwork.ValidationStyle.PasswordChar = '\0';
            this.txtptwork.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtptwork.Value = "        ";
            this.txtptwork.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtptname_KeyPress);
            // 
            // txtpthome
            // 
            this.txtpthome.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpthome.CaptionStyle.CaptionSize = 110;
            this.txtpthome.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpthome.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpthome.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtpthome.CaptionStyle.TextStyle.Text = "تلفن منزل";
            this.txtpthome.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpthome.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpthome.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpthome.Location = new System.Drawing.Point(338, 35);
            this.txtpthome.Name = "txtpthome";
            this.txtpthome.Size = new System.Drawing.Size(203, 27);
            this.txtpthome.TabIndex = 15;
            this.txtpthome.Tag = "0";
            this.txtpthome.ValidationStyle.AcceptsTab = true;
            this.txtpthome.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txtpthome.ValidationStyle.PasswordChar = '\0';
            this.txtpthome.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtpthome.Value = "        ";
            this.txtpthome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtptname_KeyPress);
            // 
            // txtptmobile
            // 
            this.txtptmobile.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtptmobile.CaptionStyle.CaptionSize = 110;
            this.txtptmobile.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtptmobile.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtptmobile.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtptmobile.CaptionStyle.TextStyle.Text = "تلفن همراه";
            this.txtptmobile.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtptmobile.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtptmobile.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtptmobile.Location = new System.Drawing.Point(338, 64);
            this.txtptmobile.Name = "txtptmobile";
            this.txtptmobile.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtptmobile.Size = new System.Drawing.Size(203, 27);
            this.txtptmobile.TabIndex = 17;
            this.txtptmobile.Tag = "0";
            this.txtptmobile.ValidationStyle.AcceptsTab = true;
            this.txtptmobile.ValidationStyle.MaskValidationStyle.Mask = "00000000000";
            this.txtptmobile.ValidationStyle.PasswordChar = '\0';
            this.txtptmobile.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtptmobile.Value = "           ";
            this.txtptmobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtptname_KeyPress);
            // 
            // txtptname
            // 
            this.txtptname.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtptname.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtptname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtptname.CaptionStyle.CaptionSize = 105;
            this.txtptname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtptname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtptname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtptname.CaptionStyle.TextStyle.Text = "نام و نام خانوادگی";
            this.txtptname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtptname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtptname.Location = new System.Drawing.Point(261, 6);
            this.txtptname.Name = "txtptname";
            this.txtptname.Size = new System.Drawing.Size(280, 27);
            this.txtptname.TabIndex = 14;
            this.txtptname.Tag = "1";
            this.txtptname.ValidationStyle.AcceptsTab = true;
            this.txtptname.ValidationStyle.PasswordChar = '\0';
            this.txtptname.Value = "";
            this.txtptname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtptname_KeyPress);
            // 
            // elRichPanel6
            // 
            this.elRichPanel6.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel6.Controls.Add(this.personDataGrid);
            this.elRichPanel6.Expanded = true;
            this.elRichPanel6.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel6.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel6.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel6.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel6.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel6.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel6.Location = new System.Drawing.Point(9, 137);
            this.elRichPanel6.Name = "elRichPanel6";
            this.elRichPanel6.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel6.Size = new System.Drawing.Size(549, 250);
            this.elRichPanel6.TabIndex = 7;
            this.elRichPanel6.Tag = "0";
            // 
            // personDataGrid
            // 
            this.personDataGrid.AllowUserToAddRows = false;
            this.personDataGrid.AllowUserToDeleteRows = false;
            this.personDataGrid.AllowUserToResizeColumns = false;
            this.personDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.personDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.personDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.personDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.personDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.personDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.personDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.personDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.personDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectP,
            this.pid,
            this.loanid,
            this.ptname,
            this.pthome,
            this.ptwork,
            this.ptmobile,
            this.ptadres});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.personDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.personDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.personDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.personDataGrid.Location = new System.Drawing.Point(1, 16);
            this.personDataGrid.MultiSelect = false;
            this.personDataGrid.Name = "personDataGrid";
            this.personDataGrid.ReadOnly = true;
            this.personDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.personDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.personDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.personDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.personDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.personDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.personDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.personDataGrid.ShowCellErrors = false;
            this.personDataGrid.ShowCellToolTips = false;
            this.personDataGrid.ShowEditingIcon = false;
            this.personDataGrid.ShowRowErrors = false;
            this.personDataGrid.Size = new System.Drawing.Size(547, 218);
            this.personDataGrid.TabIndex = 0;
            this.personDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.personDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.personDataGrid_MouseClick);
            this.personDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.personDataGrid_CellClick);
            this.personDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.personDataGrid_KeyDown);
            // 
            // SelectP
            // 
            this.SelectP.HeaderText = "";
            this.SelectP.Name = "SelectP";
            this.SelectP.ReadOnly = true;
            this.SelectP.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SelectP.Text = "انتخاب";
            this.SelectP.UseColumnTextForButtonValue = true;
            // 
            // pid
            // 
            this.pid.DataPropertyName = "pid";
            this.pid.HeaderText = "کد";
            this.pid.Name = "pid";
            this.pid.ReadOnly = true;
            this.pid.Visible = false;
            // 
            // loanid
            // 
            this.loanid.DataPropertyName = "loanid";
            this.loanid.HeaderText = "کد ضامن";
            this.loanid.Name = "loanid";
            this.loanid.ReadOnly = true;
            this.loanid.Visible = false;
            // 
            // ptname
            // 
            this.ptname.DataPropertyName = "ptname";
            this.ptname.HeaderText = "نام و نام خانوادگی";
            this.ptname.Name = "ptname";
            this.ptname.ReadOnly = true;
            // 
            // pthome
            // 
            this.pthome.DataPropertyName = "pthome";
            this.pthome.HeaderText = "تلفن منزل";
            this.pthome.Name = "pthome";
            this.pthome.ReadOnly = true;
            // 
            // ptwork
            // 
            this.ptwork.DataPropertyName = "ptwork";
            this.ptwork.HeaderText = "تلفن محل کار";
            this.ptwork.Name = "ptwork";
            this.ptwork.ReadOnly = true;
            // 
            // ptmobile
            // 
            this.ptmobile.DataPropertyName = "ptmobile";
            this.ptmobile.HeaderText = "تلفن همراه";
            this.ptmobile.Name = "ptmobile";
            this.ptmobile.ReadOnly = true;
            // 
            // ptadres
            // 
            this.ptadres.DataPropertyName = "ptadres";
            this.ptadres.HeaderText = "آدرس";
            this.ptadres.Name = "ptadres";
            this.ptadres.ReadOnly = true;
            this.ptadres.Visible = false;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(39, 394);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 8;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // FrmSponser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 442);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.elRichPanel6);
            this.Controls.Add(this.backContainer);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSponser";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ضامن تسهیلات";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmSponser_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptadres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptwork)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpthome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptmobile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtptname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel6)).EndInit();
            this.elRichPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.personDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtptadres;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtptwork;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpthome;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtptmobile;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtptname;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel6;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView personDataGrid;
        private System.Windows.Forms.DataGridViewButtonColumn SelectP;
        private System.Windows.Forms.DataGridViewTextBoxColumn pid;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanid;
        private System.Windows.Forms.DataGridViewTextBoxColumn ptname;
        private System.Windows.Forms.DataGridViewTextBoxColumn pthome;
        private System.Windows.Forms.DataGridViewTextBoxColumn ptwork;
        private System.Windows.Forms.DataGridViewTextBoxColumn ptmobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn ptadres;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
    }
}