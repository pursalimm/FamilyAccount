﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FamilyAccount
{
    public partial class FrmPhone : Form
    {
        string idSel = "";
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public FrmPhone()
        {
            InitializeComponent();
        }

        public static FrmPhone Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmPhone();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtfname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtname.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into phone values(@name,@relation,@citycode,@hometel,@worktel,@mobile,@fax,@email,@site,@adres)";
            cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
            cmd.Parameters.Add("@relation", SqlDbType.NVarChar).Value = cborelation.Text;
            cmd.Parameters.Add("@citycode", SqlDbType.NVarChar).Value = txtcitycode.Text;
            cmd.Parameters.Add("@hometel", SqlDbType.NVarChar).Value = txthometel.Text;
            cmd.Parameters.Add("@worktel", SqlDbType.NVarChar).Value = txtworktel.Text;
            cmd.Parameters.Add("@mobile", SqlDbType.NVarChar).Value = txtmobile.Text;
            cmd.Parameters.Add("@fax", SqlDbType.NVarChar).Value = txtfax.Text;
            cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@site", SqlDbType.NVarChar).Value = txtsite.Text;
            cmd.Parameters.Add("@adres", SqlDbType.NText).Value = txtadres.Text;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update phone set name=@name,relation=@relation,citycode=@citycode,hometel=@hometel,worktel=@worktel,mobile=@mobile,fax=@fax,email=@email,site=@site,adres=@adres where phid=@phid";
            cmd.Parameters.Add("@phid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
            cmd.Parameters.Add("@relation", SqlDbType.NVarChar).Value = cborelation.Text;
            cmd.Parameters.Add("@citycode", SqlDbType.NVarChar).Value = txtcitycode.Text;
            cmd.Parameters.Add("@hometel", SqlDbType.NVarChar).Value = txthometel.Text;
            cmd.Parameters.Add("@worktel", SqlDbType.NVarChar).Value = txtworktel.Text;
            cmd.Parameters.Add("@mobile", SqlDbType.NVarChar).Value = txtmobile.Text;
            cmd.Parameters.Add("@fax", SqlDbType.NVarChar).Value = txtfax.Text;
            cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = txtemail.Text;
            cmd.Parameters.Add("@site", SqlDbType.NVarChar).Value = txtsite.Text;
            cmd.Parameters.Add("@adres", SqlDbType.NText).Value = txtadres.Text;
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from phone where phid=@phid";
            cmd.Parameters.Add("@phid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmPhone_Load(object sender, EventArgs e)
        {
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from phone");
            phoneDataGrid.DataSource = ds.Tables[0];
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void phoneDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (phoneDataGrid.RowCount > 0)
            {
                if (phoneDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void SelectedData()
        {
            idSel = phoneDataGrid["phid", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtname.Text = phoneDataGrid["name", phoneDataGrid.CurrentRow.Index].Value.ToString();
            cborelation.Text = phoneDataGrid["relation", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtcitycode.Text = phoneDataGrid["citycode", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txthometel.Text = phoneDataGrid["hometel", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtworktel.Text = phoneDataGrid["worktel", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtmobile.Text = phoneDataGrid["mobile", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtfax.Text = phoneDataGrid["fax", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtemail.Text = phoneDataGrid["email", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtsite.Text = phoneDataGrid["site", phoneDataGrid.CurrentRow.Index].Value.ToString();
            txtadres.Text = phoneDataGrid["adres", phoneDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void phoneDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && phoneDataGrid.RowCount > 0)
            {
                SelectedData();
                if (phoneDataGrid.CurrentRow.Index == 0)
                    phoneDataGrid[0, 0].Selected = true;
                else
                    phoneDataGrid[0, phoneDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void phoneDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && phoneDataGrid.RowCount > 0)
                SelectedData();
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "select phid, name,relation,citycode,hometel,worktel,mobile,fax,email,site,adres from phone where phid<>0";
            if (txtnamePH.Text.Trim().Length != 0)
                query += "AND name like (N'%" + txtnamePH.Text + "%')";
            if (cboRelationPH.Text.Trim().Length != 0)
                query += "AND relation like (N'%" + cboRelationPH.Text + "%')";
            DataSet ds = ado.select(query);
            phoneDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select phid,name,relation,citycode,hometel,worktel,mobile,fax,email,site,adres from phone where phid<>0");
            phoneDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }
    }
}
