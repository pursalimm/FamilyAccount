﻿namespace FamilyAccount
{
    partial class FrmSalary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmSalary aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSalary));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle5 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtbsid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.lblSaltotal = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtsalnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsaltotal = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsaldate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.salaryDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.salid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.basesalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.saldate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salnote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saltotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.basesalTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.basesalTableAdapter();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtbsidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsalmin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsalnoteS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsalmax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lblsum = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbsid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSaltotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsaltotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsaldate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salaryDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basesalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtbsidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnoteS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtbsid);
            this.backContainer.Controls.Add(this.lblSaltotal);
            this.backContainer.Controls.Add(this.txtsalnote);
            this.backContainer.Controls.Add(this.txtsaltotal);
            this.backContainer.Controls.Add(this.txtsaldate);
            this.backContainer.Location = new System.Drawing.Point(8, 33);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(671, 162);
            this.backContainer.TabIndex = 0;
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(379, 8);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 1;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // txtbsid
            // 
            this.txtbsid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbsid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbsid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbsid.CaptionStyle.CaptionSize = 65;
            this.txtbsid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbsid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbsid.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbsid.CaptionStyle.TextStyle.Text = "نوع درآمد";
            this.txtbsid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbsid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbsid.Location = new System.Drawing.Point(408, 8);
            this.txtbsid.Name = "txtbsid";
            this.txtbsid.Size = new System.Drawing.Size(250, 27);
            this.txtbsid.TabIndex = 0;
            this.txtbsid.Tag = "1";
            this.txtbsid.ValidationStyle.AcceptsTab = true;
            this.txtbsid.ValidationStyle.PasswordChar = '\0';
            this.txtbsid.ValidationStyle.ReadOnly = true;
            this.txtbsid.Value = "";
            this.txtbsid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            this.txtbsid.Enter += new System.EventHandler(this.txtbsid_Enter);
            // 
            // lblSaltotal
            // 
            this.lblSaltotal.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle5.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle5.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle5.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle5.SolidColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.FlashStyle = paintStyle5;
            this.lblSaltotal.Location = new System.Drawing.Point(9, 126);
            this.lblSaltotal.Name = "lblSaltotal";
            this.lblSaltotal.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblSaltotal.Size = new System.Drawing.Size(649, 27);
            this.lblSaltotal.TabIndex = 5;
            this.lblSaltotal.TabStop = false;
            this.lblSaltotal.Tag = "0";
            this.lblSaltotal.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaltotal.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblSaltotal.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblSaltotal.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtsalnote
            // 
            this.txtsalnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalnote.CaptionStyle.CaptionSize = 70;
            this.txtsalnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalnote.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsalnote.CaptionStyle.TextStyle.Text = "شرح درآمد";
            this.txtsalnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalnote.Location = new System.Drawing.Point(9, 66);
            this.txtsalnote.Name = "txtsalnote";
            this.txtsalnote.Size = new System.Drawing.Size(649, 27);
            this.txtsalnote.TabIndex = 3;
            this.txtsalnote.Tag = "1";
            this.txtsalnote.ValidationStyle.AcceptsTab = true;
            this.txtsalnote.ValidationStyle.PasswordChar = '\0';
            this.txtsalnote.Value = "";
            this.txtsalnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // txtsaltotal
            // 
            this.txtsaltotal.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsaltotal.CaptionStyle.CaptionSize = 70;
            this.txtsaltotal.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsaltotal.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsaltotal.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaltotal.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaltotal.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaltotal.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsaltotal.CaptionStyle.TextStyle.Text = "مبلغ درآمد";
            this.txtsaltotal.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsaltotal.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsaltotal.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsaltotal.Location = new System.Drawing.Point(451, 95);
            this.txtsaltotal.Name = "txtsaltotal";
            this.txtsaltotal.Size = new System.Drawing.Size(207, 27);
            this.txtsaltotal.TabIndex = 4;
            this.txtsaltotal.Tag = "1";
            this.txtsaltotal.ValidationStyle.AcceptsTab = true;
            this.txtsaltotal.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtsaltotal.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsaltotal.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsaltotal.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsaltotal.ValidationStyle.PasswordChar = '\0';
            this.txtsaltotal.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsaltotal.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtsaltotal.TextChanged += new System.EventHandler(this.txtsaltotal_TextChanged);
            this.txtsaltotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsaltotal_KeyPress);
            // 
            // txtsaldate
            // 
            this.txtsaldate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtsaldate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsaldate.CaptionStyle.CaptionSize = 70;
            this.txtsaldate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsaldate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsaldate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaldate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaldate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsaldate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsaldate.CaptionStyle.TextStyle.Text = "تاریخ ثبت";
            this.txtsaldate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsaldate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsaldate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsaldate.Location = new System.Drawing.Point(487, 37);
            this.txtsaldate.Name = "txtsaldate";
            this.txtsaldate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtsaldate.Size = new System.Drawing.Size(171, 27);
            this.txtsaldate.TabIndex = 2;
            this.txtsaldate.Tag = "1";
            this.txtsaldate.ValidationStyle.AcceptsTab = true;
            this.txtsaldate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtsaldate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtsaldate.ValidationStyle.PasswordChar = '\0';
            this.txtsaldate.Value = "";
            this.txtsaldate.Leave += new System.EventHandler(this.txtsaldate_Leave);
            this.txtsaldate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Circle;
            this.elRichPanel1.Controls.Add(this.lblsum);
            this.elRichPanel1.Controls.Add(this.label1);
            this.elRichPanel1.Controls.Add(this.salaryDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.Location = new System.Drawing.Point(8, 199);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 24);
            this.elRichPanel1.Size = new System.Drawing.Size(671, 255);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // salaryDataGrid
            // 
            this.salaryDataGrid.AllowUserToAddRows = false;
            this.salaryDataGrid.AllowUserToDeleteRows = false;
            this.salaryDataGrid.AllowUserToResizeColumns = false;
            this.salaryDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.salaryDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.salaryDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.salaryDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.salaryDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.salaryDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.salaryDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.salaryDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.salaryDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.salid,
            this.bsid,
            this.saldate,
            this.salnote,
            this.saltotal});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.salaryDataGrid.DefaultCellStyle = dataGridViewCellStyle28;
            this.salaryDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.salaryDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.salaryDataGrid.Location = new System.Drawing.Point(1, 16);
            this.salaryDataGrid.MultiSelect = false;
            this.salaryDataGrid.Name = "salaryDataGrid";
            this.salaryDataGrid.ReadOnly = true;
            this.salaryDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.salaryDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.salaryDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.salaryDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.salaryDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.salaryDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.salaryDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.salaryDataGrid.ShowCellErrors = false;
            this.salaryDataGrid.ShowCellToolTips = false;
            this.salaryDataGrid.ShowEditingIcon = false;
            this.salaryDataGrid.ShowRowErrors = false;
            this.salaryDataGrid.Size = new System.Drawing.Size(669, 215);
            this.salaryDataGrid.TabIndex = 0;
            this.salaryDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.salaryDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.salaryDataGrid_MouseClick);
            this.salaryDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.salaryDataGrid_CellClick);
            this.salaryDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.salaryDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // salid
            // 
            this.salid.DataPropertyName = "salid";
            this.salid.HeaderText = "کد";
            this.salid.Name = "salid";
            this.salid.ReadOnly = true;
            this.salid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.salid.Visible = false;
            // 
            // bsid
            // 
            this.bsid.DataPropertyName = "bsid";
            this.bsid.DataSource = this.basesalBindingSource;
            this.bsid.DisplayMember = "salname";
            this.bsid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.bsid.HeaderText = "نوع درآمد";
            this.bsid.Name = "bsid";
            this.bsid.ReadOnly = true;
            this.bsid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.bsid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.bsid.ValueMember = "bsid";
            // 
            // basesalBindingSource
            // 
            this.basesalBindingSource.DataMember = "basesal";
            this.basesalBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // saldate
            // 
            this.saldate.DataPropertyName = "saldate";
            this.saldate.HeaderText = "تاریخ ثبت";
            this.saldate.Name = "saldate";
            this.saldate.ReadOnly = true;
            // 
            // salnote
            // 
            this.salnote.DataPropertyName = "salnote";
            this.salnote.HeaderText = "شرح درآمد";
            this.salnote.Name = "salnote";
            this.salnote.ReadOnly = true;
            // 
            // saltotal
            // 
            this.saltotal.DataPropertyName = "saltotal";
            dataGridViewCellStyle27.Format = "C0";
            dataGridViewCellStyle27.NullValue = null;
            this.saltotal.DefaultCellStyle = dataGridViewCellStyle27;
            this.saltotal.HeaderText = "مبلغ درآمد";
            this.saltotal.Name = "saltotal";
            this.saltotal.ReadOnly = true;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(100, 461);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BackgroundStyle.GradientStartColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // basesalTableAdapter
            // 
            this.basesalTableAdapter.ClearBeforeFill = true;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(8, 8, 671, 187);
            this.expandPanel.Location = new System.Drawing.Point(8, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(671, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 3;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.txtbsidS);
            this.BackSearch.Controls.Add(this.txtsalmin);
            this.BackSearch.Controls.Add(this.txtsalnoteS);
            this.BackSearch.Controls.Add(this.txtsalmax);
            this.BackSearch.Controls.Add(this.txtstartdate);
            this.BackSearch.Controls.Add(this.txtenddate);
            this.BackSearch.Location = new System.Drawing.Point(9, 31);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(653, 122);
            this.BackSearch.TabIndex = 9;
            // 
            // txtbsidS
            // 
            this.txtbsidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbsidS.CaptionStyle.CaptionSize = 105;
            this.txtbsidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbsidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbsidS.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsidS.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsidS.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbsidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbsidS.CaptionStyle.TextStyle.Text = "نوع درآمد";
            this.txtbsidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbsidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbsidS.Location = new System.Drawing.Point(396, 5);
            this.txtbsidS.Name = "txtbsidS";
            this.txtbsidS.Size = new System.Drawing.Size(250, 27);
            this.txtbsidS.TabIndex = 0;
            this.txtbsidS.Tag = "1";
            this.txtbsidS.ValidationStyle.AcceptsTab = true;
            this.txtbsidS.ValidationStyle.PasswordChar = '\0';
            this.txtbsidS.Value = "";
            this.txtbsidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // txtsalmin
            // 
            this.txtsalmin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalmin.CaptionStyle.CaptionSize = 105;
            this.txtsalmin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalmin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalmin.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmin.CaptionStyle.TextStyle.Text = "مبلغ درآمد حداقل";
            this.txtsalmin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalmin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsalmin.Location = new System.Drawing.Point(409, 61);
            this.txtsalmin.Name = "txtsalmin";
            this.txtsalmin.Size = new System.Drawing.Size(237, 27);
            this.txtsalmin.TabIndex = 2;
            this.txtsalmin.Tag = "1";
            this.txtsalmin.ValidationStyle.AcceptsTab = true;
            this.txtsalmin.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtsalmin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsalmin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsalmin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsalmin.ValidationStyle.PasswordChar = '\0';
            this.txtsalmin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsalmin.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtsalmin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsaltotal_KeyPress);
            // 
            // txtsalnoteS
            // 
            this.txtsalnoteS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalnoteS.CaptionStyle.CaptionSize = 105;
            this.txtsalnoteS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalnoteS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalnoteS.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnoteS.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnoteS.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalnoteS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalnoteS.CaptionStyle.TextStyle.Text = "شرح درآمد";
            this.txtsalnoteS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalnoteS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalnoteS.Location = new System.Drawing.Point(7, 33);
            this.txtsalnoteS.Name = "txtsalnoteS";
            this.txtsalnoteS.Size = new System.Drawing.Size(639, 27);
            this.txtsalnoteS.TabIndex = 1;
            this.txtsalnoteS.Tag = "1";
            this.txtsalnoteS.ValidationStyle.AcceptsTab = true;
            this.txtsalnoteS.ValidationStyle.PasswordChar = '\0';
            this.txtsalnoteS.Value = "";
            this.txtsalnoteS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // txtsalmax
            // 
            this.txtsalmax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsalmax.CaptionStyle.CaptionSize = 105;
            this.txtsalmax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsalmax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsalmax.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsalmax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmax.CaptionStyle.TextStyle.Text = "مبلغ درامد حداکثر";
            this.txtsalmax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalmax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsalmax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsalmax.Location = new System.Drawing.Point(409, 89);
            this.txtsalmax.Name = "txtsalmax";
            this.txtsalmax.Size = new System.Drawing.Size(237, 27);
            this.txtsalmax.TabIndex = 3;
            this.txtsalmax.Tag = "1";
            this.txtsalmax.ValidationStyle.AcceptsTab = true;
            this.txtsalmax.ValidationStyle.MaskValidationStyle.PromptChar = '\0';
            this.txtsalmax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsalmax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsalmax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtsalmax.ValidationStyle.PasswordChar = '\0';
            this.txtsalmax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsalmax.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtsalmax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsaltotal_KeyPress);
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.CaptionSize = 70;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(105, 61);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(170, 27);
            this.txtstartdate.TabIndex = 4;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.CaptionSize = 70;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(105, 89);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(170, 27);
            this.txtenddate.TabIndex = 5;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsalid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(84, 156);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 7;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(9, 156);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 8;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "جمع کل:";
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblsum.ForeColor = System.Drawing.Color.Blue;
            this.lblsum.Location = new System.Drawing.Point(9, 236);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(0, 15);
            this.lblsum.TabIndex = 3;
            this.lblsum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmSalary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 508);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.backContainer);
            this.Controls.Add(this.elRichPanel1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSalary";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "درآمدهای سرپرست خانوار";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmSalary_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbsid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSaltotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsaltotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsaldate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salaryDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basesalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtbsidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalnoteS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsalmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalnote;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsaltotal;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsaldate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView salaryDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblSaltotal;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbsid;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource basesalBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.basesalTableAdapter basesalTableAdapter;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn salid;
        private System.Windows.Forms.DataGridViewComboBoxColumn bsid;
        private System.Windows.Forms.DataGridViewTextBoxColumn saldate;
        private System.Windows.Forms.DataGridViewTextBoxColumn salnote;
        private System.Windows.Forms.DataGridViewTextBoxColumn saltotal;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalmax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbsidS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalnoteS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsalmin;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label label1;
    }
}