﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using PrintDataGrid;

namespace FamilyAccount
{
    public partial class FrmReport : Form
    {
        string selectedkeyloan = string.Empty;
        string selectedkeybaid = string.Empty;
        string selectedkeybankid = string.Empty;
        string selectedkeyaccid = string.Empty;
        string selectedkeycsid = string.Empty;
        string selectedkeymem = string.Empty;
        string selectedkeybcid = string.Empty;
        string selectedkeybsid = string.Empty;
        string query = string.Empty;
        DataSet ds;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        public DataGridViewRow dgvr;
        SqlCommand cmd = new SqlCommand();
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.AccountConnectionString);
        public FrmReport()
        {
            InitializeComponent();
        }

        public static FrmReport Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmReport();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region GenerateDate
        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btncurmonth_Click(object sender, EventArgs e)
        {
            pd = new PersianDate(DateTime.Now);
            txtstartdate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, "01");
            txtenddate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, pd.MonthDays);
            ado.DateValidation(txtstartdate);
            ado.DateValidation(txtenddate);
        }

        private void btncuryear_Click(object sender, EventArgs e)
        {
            pd = new PersianDate(DateTime.Now);
            pd.Month = 12;      //Eslah Shavad
            txtstartdate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, "01", "01");
            txtenddate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, "12", pd.MonthDays-1);
            ado.DateValidation(txtstartdate);
            ado.DateValidation(txtenddate);
        }

        private void btncurday_Click(object sender, EventArgs e)
        {
            pd = new PersianDate(DateTime.Now);
            txtstartdate.Text = pd.ToString("d");
            txtenddate.Text = pd.ToString("d");
            ado.DateValidation(txtstartdate);
            ado.DateValidation(txtenddate);
        }

        private void rdo1_CheckedChanged(object sender, EventArgs e)
        {
            pd = new PersianDate(DateTime.Now);
            Klik.Windows.Forms.v1.EntryLib.ELRadioButton rd = (Klik.Windows.Forms.v1.EntryLib.ELRadioButton)sender;
            pd.Month = int.Parse(rd.Tag.ToString());
            txtstartdate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, "01");
            if (pd.Month == 12)
                txtenddate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, pd.MonthDays - 1);
            else
                txtenddate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, pd.MonthDays);
            ado.DateValidation(txtstartdate);
            ado.DateValidation(txtenddate);
        }

        private void btncurweek_Click(object sender, EventArgs e)
        {
            int count = 0;
            pd = new PersianDate(DateTime.Now);
            while (pd.DayOfWeek.ToString() != "Saturday")
            {
                pd.Day--;
                count--;
            }
            DateTime date = DateTime.Now.AddDays(count);
            pd = new PersianDate(date);
            txtstartdate.Text = string.Format("{0:d2}/{1:d2}/{2:d2}", pd.Year, pd.Month, pd.Day);
            txtenddate.Text = pd.ToDateTime().AddDays(6).ToPersianDate().ToString("d");
            ado.DateValidation(txtstartdate);
            ado.DateValidation(txtenddate);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }
        #endregion

        private void cborelation_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void FrmReport_Load(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
            pd = new PersianDate(DateTime.Now);
            btnClear_Click(sender, e);
        }

        private void tabBase_SelectedTabPageChanged(object sender, EventArgs e)
        {
            btnClear_Click(sender, e);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            double sum1 = 0, sum2 = 0;
            repDataGrid.Columns.Clear();
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: ado.ClearControl(Tab0);
                    ado.ClearControl(grpDate);
                    ds = ado.select("SELECT fa.name, ac.accid, ac.custid, ac.accdate, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                + "banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid ");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        foreach (DataGridViewRow rw in repDataGrid.Rows)
                            sum1 += Convert.ToDouble(rw.Cells["store"].Value);

                        DataRow row = ds.Tables[0].NewRow();
                        row["name"] = "جمع کـــــل";
                        row["store"] = sum1;
                        ds.Tables[0].Rows.Add(row);
                        repDataGrid.DataSource = ds.Tables[0];

                        repDataGrid.Columns[0].HeaderText = "نام صاحب حساب";
                        repDataGrid.Columns[1].HeaderText = "شماره حساب";
                        repDataGrid.Columns[2].HeaderText = "شماره مشتری";
                        repDataGrid.Columns[3].HeaderText = "تاریخ افتتاح";
                        repDataGrid.Columns[4].HeaderText = "کد شعبه";
                        repDataGrid.Columns[5].HeaderText = "عنوان بانک";
                        repDataGrid.Columns[6].HeaderText = "نام بانک";
                        repDataGrid.Columns[7].HeaderText = "موجودی";
                        repDataGrid.Columns[8].HeaderText = "نوع حساب";
                    }
                    break;
                case 1: ado.ClearControl(Tab1);
                    ado.ClearControl(grpDate);
                    ds = ado.select("SELECT fa.name, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbackdate,lo.loanbacktype FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        foreach (DataGridViewRow rw in repDataGrid.Rows)
                        {
                            sum1 += Convert.ToDouble(rw.Cells["loanquan"].Value);
                            sum2 += Convert.ToDouble(rw.Cells["loanback"].Value);
                        }

                        DataRow row = ds.Tables[0].NewRow();
                        row["name"] = "جمع کـــــل";
                        row["loanquan"] = sum1;
                        row["loanback"] = sum2;
                        ds.Tables[0].Rows.Add(row);
                        repDataGrid.DataSource = ds.Tables[0];

                        repDataGrid.Columns[0].HeaderText = "دریافت کننده";
                        repDataGrid.Columns[1].HeaderText = "شماره حساب";
                        repDataGrid.Columns[2].HeaderText = "تاریخ دریافت";
                        repDataGrid.Columns[3].HeaderText = "نوع تسهیلات";
                        repDataGrid.Columns[4].HeaderText = "مبلغ تسهیلات";
                        repDataGrid.Columns[5].HeaderText = "نرخ";
                        repDataGrid.Columns[6].HeaderText = "مبلغ بازپرداخت";
                        repDataGrid.Columns[7].HeaderText = "تاریخ بازپرداخت";
                        repDataGrid.Columns[8].HeaderText = "نوع بازپرداخت";
                    }
                    break;
                case 2: ado.ClearControl(Tab2);
                    ado.ClearControl(grpDate);
                    ds = ado.select("SELECT cheqid, cheqtype, accid, cheqexpo, cheqdate, cheqquan, inmode, cheqstate, cheqnote FROM cheq AS ch WHERE (idcs <> 0)");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        foreach (DataGridViewRow rw in repDataGrid.Rows)
                            sum1 += Convert.ToDouble(rw.Cells["cheqquan"].Value);

                        DataRow row = ds.Tables[0].NewRow();
                        row["cheqid"] = "جمع کـــــل";
                        row["cheqquan"] = sum1;
                        ds.Tables[0].Rows.Add(row);
                        repDataGrid.DataSource = ds.Tables[0];

                        repDataGrid.Columns[0].HeaderText = "شماره چک";
                        repDataGrid.Columns[1].HeaderText = "نوع چک";
                        repDataGrid.Columns[2].HeaderText = "شماره حساب";
                        repDataGrid.Columns[3].HeaderText = "تاریخ صدور";
                        repDataGrid.Columns[4].HeaderText = "تاریخ سررسید";
                        repDataGrid.Columns[5].HeaderText = "مبلغ چک";
                        repDataGrid.Columns[6].HeaderText = "در وجه";
                        repDataGrid.Columns[7].HeaderText = "وضعیت چک";
                        repDataGrid.Columns[8].HeaderText = "شرح چک";
                    }
                    break;
                case 3: ado.ClearControl(Tab3);
                    ado.ClearControl(grpDate);
                    ds = ado.select("select name,relation,citycode,hometel,worktel,mobile,fax,email,site,adres from phone where phid<>0");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        repDataGrid.Columns[0].HeaderText = "نام";
                        repDataGrid.Columns[1].HeaderText = "نسبت فامیلی";
                        repDataGrid.Columns[2].HeaderText = "کد شهر";
                        repDataGrid.Columns[3].HeaderText = "منزل";
                        repDataGrid.Columns[4].HeaderText = "محل کار";
                        repDataGrid.Columns[5].HeaderText = "تلفن همراه";
                        repDataGrid.Columns[6].HeaderText = "فاکس";
                        repDataGrid.Columns[7].HeaderText = "ایمیل";
                        repDataGrid.Columns[8].HeaderText = "سایت";
                        repDataGrid.Columns[9].HeaderText = "آدرس";
                    }
                    break;
                case 4: ado.ClearControl(Tab4);
                    ado.ClearControl(grpDate);
                    ds = ado.select("SELECT bs.salname, sa.saldate, sa.salnote, sa.saltotal FROM salary AS sa INNER JOIN basesal AS bs ON sa.bsid = bs.bsid");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        foreach (DataGridViewRow rw in repDataGrid.Rows)
                            sum1 += Convert.ToDouble(rw.Cells["saltotal"].Value);
                        
                        DataRow row = ds.Tables[0].NewRow();
                        row["salname"] = "جمع کـــــل";
                        row["saltotal"] = sum1;
                        ds.Tables[0].Rows.Add(row);
                        repDataGrid.DataSource = ds.Tables[0];

                        repDataGrid.Columns[0].HeaderText = "نوع درآمد";
                        repDataGrid.Columns[1].HeaderText = "تاریخ ثبت درآمد";
                        repDataGrid.Columns[2].HeaderText = "شرح درآمد";
                        repDataGrid.Columns[3].HeaderText = "مبلغ درآمد";
                    }
                    break;
                case 5: ado.ClearControl(Tab5);
                    ado.ClearControl(grpDate);
                    ds = ado.select("SELECT bc.costname, fa.name, co.costdate, co.costnote, co.costquan FROM cost AS co INNER JOIN basecost AS bc ON co.bcid = bc.bcid INNER JOIN family AS fa ON co.memid = fa.memid WHERE (co.cid <> 0)");
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        repDataGrid.DataSource = ds.Tables[0];
                        foreach (DataGridViewRow rw in repDataGrid.Rows)
                            sum1 += Convert.ToDouble(rw.Cells["costquan"].Value);

                        DataRow row = ds.Tables[0].NewRow();
                        row["costname"] = "جمع کـــــل";
                        row["costquan"] = sum1;
                        ds.Tables[0].Rows.Add(row);
                        repDataGrid.DataSource = ds.Tables[0];

                        repDataGrid.Columns[0].HeaderText = "نوع هزینه";
                        repDataGrid.Columns[1].HeaderText = "هزینه کننده";
                        repDataGrid.Columns[2].HeaderText = "تاریخ هزینه";
                        repDataGrid.Columns[3].HeaderText = "شرح هزینه";
                        repDataGrid.Columns[4].HeaderText = "مبلغ هزینه";
                    }
                    break;
            }
        }

        private void btnCreateRep_Click(object sender, EventArgs e)
        {
            switch (tabBase.SelectedTabPage.TabIndex)
            {
                case 0: AccountFilter();
                    break;
                case 1: LoanFilter();
                    break;
                case 2: CheqFilter();
                    break;
                case 3: PhoneFilter();
                    break;
                case 4: SalaryFilter();
                    break;
                case 5: CostFilter();
                    break;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDGV.Print_DataGridView(repDataGrid);
        }

        public void AccountFilter()
        {
            query = "SELECT fa.name, ac.accid, ac.custid, ac.accdate, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                    +"FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                    +"banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid ";
            if (txtaccmemid.Text.Trim().Length != 0)
                query += "AND fa.name like (N'%" + txtaccmemid.Text + "%')";
            if (txtaccidA.Text.Trim().Length != 0)
                query += "AND ac.accid='" + txtaccidA.Text + "'";
            if (txtbankid.Text.Trim().Length != 0)
                query += "AND ac.bankid=" + selectedkeybankid;
            if (txtbaid.Text.Trim().Length != 0)
                query += "AND ac.baid=" + selectedkeybaid;

            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND ac.accdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND ac.accdate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND ac.accdate < '" + txtenddate.Text + "'";


            if (txtstoremin.Value.ToString() != "0" && txtstoremax.Value.ToString() != "0")
                query += "AND store between " + txtstoremin.Value.ToString() + " and " + txtstoremax.Value.ToString();
            else if (txtstoremin.Value.ToString() != "0")
                query += "AND store > " + txtstoremin.Value.ToString();
            else if (txtstoremax.Value.ToString() != "0")
                query += "AND store < " + txtstoremax.Value.ToString();

            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];
        }

        private void rdoCheq_CheckedChanged(object sender, EventArgs e)
        {
            ds = ado.select("select accid,csseries,csdate,csfirst,csend from cheqset where accid='" + txtaccidA.Text + "'");
            repDataGrid.DataSource = ds.Tables[0];
            repDataGrid.Columns[0].HeaderText = "شماره حساب";
            repDataGrid.Columns[1].HeaderText = "شماره سری";
            repDataGrid.Columns[2].HeaderText = "تاریخ دریافت";
            repDataGrid.Columns[3].HeaderText = "شماره شروع";
            repDataGrid.Columns[4].HeaderText = "شماره پایان";
            rdoCheq.Checked = false;
        }

        private void rdoAcccard_CheckedChanged(object sender, EventArgs e)
        {
            if(txtaccmemid.Text.Trim().Length !=0 && txtaccidA.Text.Trim()!="0")
                ds = ado.select("SELECT acd.accid, fa.name, acd.cardid, acd.settlenum FROM acc_card AS acd INNER JOIN family AS fa ON acd.memid = fa.memid where acd.accid='" + txtaccidA.Text + "' AND acd.memid=" + selectedkeymem);
            else if (txtaccmemid.Text.Trim().Length != 0)
                ds = ado.select("SELECT acd.accid, fa.name, acd.cardid, acd.settlenum FROM acc_card AS acd INNER JOIN family AS fa ON acd.memid = fa.memid where acd.memid=" + selectedkeymem);
            else if (txtaccidA.Text.Trim() != "0")
                ds = ado.select("SELECT acd.accid, fa.name, acd.cardid, acd.settlenum FROM acc_card AS acd INNER JOIN family AS fa ON acd.memid = fa.memid where acd.accid='" + txtaccidA.Text + "'");
            repDataGrid.DataSource = ds.Tables[0];
            repDataGrid.Columns[0].HeaderText = "شماره حساب";
            repDataGrid.Columns[1].HeaderText = "صاحب کارت";
            repDataGrid.Columns[2].HeaderText = "شماره کارت";
            repDataGrid.Columns[3].HeaderText = "شناسه واریز";
            rdoAcccard.Checked = false;
        }

        private void rdoTrans_CheckedChanged(object sender, EventArgs e)
        {
            ds = ado.select("select * from fin_detail where accid='" + txtaccidA.Text + "'");
            repDataGrid.DataSource = ds.Tables[0];
            repDataGrid.Columns[0].HeaderText = "شماره حساب";
            repDataGrid.Columns[1].HeaderText = "تاریخ تراکنش";
            repDataGrid.Columns[2].HeaderText = "شرح تراکنش";
            repDataGrid.Columns[3].HeaderText = "برداشت";
            repDataGrid.Columns[4].HeaderText = "واریز";
            repDataGrid.Columns[5].HeaderText = "باقیمانده";
            rdoTrans.Checked = false;
        }

        public void LoanFilter()
        {
            query = "SELECT lo.loanid, fa.name, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbackdate, lo.loanbacktype FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid ";
            if (cboloanbacktype.Text.Trim().Length != 0)
                query += "AND lo.loanbacktype like (N'%" + cboloanbacktype.Text + "%')";
            if (txtloanP.Text.Trim().Length != 0)
                query += "AND lo.loanid=" + selectedkeyloan;

            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND lo.loandate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND lo.loandate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND lo.loandate < '" + txtenddate.Text + "'";

            if (txtloanqmin.Value.ToString() != "0" && txtloanqmax.Value.ToString() != "0")
                query += "AND lo.loanquan between " + txtloanqmin.Value.ToString() + " and " + txtloanqmax.Value.ToString();
            else if (txtloanqmin.Value.ToString() != "0")
                query += "AND lo.loanquan > " + txtloanqmin.Value.ToString();
            else if (txtloanqmax.Value.ToString() != "0")
                query += "AND lo.loanquan < " + txtloanqmax.Value.ToString();

            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];
        }

        private void rdopayment_CheckedChanged(object sender, EventArgs e)
        {
            if (rdopayment.Checked==true && selectedkeyloan == "")
            {
                MessageBox.Show("لطفا مشخصات دریافت کننده تسهیلات را انتخاب نمائید", "", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                rdopayment.Checked = false;
                return;
            }
            if (selectedkeyloan != "")
            {
                ds = ado.select("SELECT dateusan, payquan, datepay, setwage, setdelay, setstate, setnote FROM pay_settle where loanid=" + selectedkeyloan);
                repDataGrid.DataSource = ds.Tables[0];
                repDataGrid.Columns[0].HeaderText = "تاریخ سررسید";
                repDataGrid.Columns[1].HeaderText = "مبلغ قسط";
                repDataGrid.Columns[2].HeaderText = "تاریخ پرداخت";
                repDataGrid.Columns[3].HeaderText = "کارمزد دوره";
                repDataGrid.Columns[4].HeaderText = "جریمه تاخیر";
                repDataGrid.Columns[5].HeaderText = "وضعیت قسط";
                repDataGrid.Columns[6].HeaderText = "شرح قسط";
            }
            rdopayment.Checked = false;
        }

        public void CheqFilter()
        {
            query = "SELECT cheqid, cheqtype, accid, cheqexpo, cheqdate, cheqquan, inmode, cheqstate, cheqnote FROM cheq AS ch WHERE (idcs <> 0) ";
            if (cbocheqtype.Text.Trim().Length != 0)
                query += "AND cheqtype like (N'%" + cbocheqtype.Text + "%')";
            if (txtaccid.Text.Trim().Length != 0)
                query += "AND accid= '" + txtaccid.Text + "'";
            if (txtcsid.Text.Trim().Length != 0)
                query += "AND ch.csid=" + selectedkeycsid;
            if (txtinmode.Text.Trim().Length != 0)
                query += "AND inmode like (N'%" + txtinmode.Text + "%')";
            if (cbocheqstate.Text.Trim().Length != 0)
                query += "AND cheqstate like (N'%" + cbocheqstate.Text + "%')";

            if (rdochExpo.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqexpo between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND cheqexpo > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqexpo < '" + txtenddate.Text + "'";
            }
            else if (rdochdate.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND cheqdate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqdate < '" + txtenddate.Text + "'";
            }

            if (txtcheqquanmin.Value.ToString() != "0" && txtcheqquanmax.Value.ToString() != "0")
                query += "AND cheqquan between " + txtcheqquanmin.Value.ToString() + " and " + txtcheqquanmax.Value.ToString();
            else if (txtcheqquanmin.Value.ToString() != "0")
                query += "AND cheqquan > " + txtcheqquanmin.Value.ToString();
            else if (txtcheqquanmax.Value.ToString() != "0")
                query += "AND cheqquan < " + txtcheqquanmax.Value.ToString();

            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];
        }

        public void PhoneFilter()
        {
            query = "select name,relation,citycode,hometel,worktel,mobile,fax,email,site,adres from phone where phid<>0 ";
            if (txtnamePH.Text.Trim().Length != 0)
                query += "AND name like (N'%" + txtnamePH.Text + "%')";
            if (cborelation.Text.Trim().Length != 0)
                query += "AND relation like (N'%" + cborelation.Text + "%')";
            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];        
        }
        
        public void SalaryFilter()
        {
            query = "SELECT bs.salname, sa.saldate, sa.salnote, sa.saltotal FROM salary AS sa INNER JOIN basesal AS bs ON sa.bsid = bs.bsid WHERE (sa.salid <> 0) ";
            if (txtbsid.Text.Trim().Length != 0)
                query += "AND sa.bsid=" + selectedkeybsid;
            if (txtsalnote.Text.Trim().Length != 0)
                query += "AND sa.salnote like (N'%" + txtsalnote.Text + "%')";
            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND sa.saldate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND sa.saldate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND sa.saldate < '" + txtenddate.Text + "'";

            if (txtsalmin.Value.ToString() != "0" && txtsalmax.Value.ToString() != "0")
                query += "AND saltotal between " + txtsalmin.Value.ToString() + " and " + txtsalmax.Value.ToString();
            else if (txtsalmin.Value.ToString() != "0")
                query += "AND saltotal > " + txtsalmin.Value.ToString();
            else if (txtsalmax.Value.ToString() != "0")
                query += "AND saltotal < " + txtsalmax.Value.ToString();

            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];        
        }

        public void CostFilter()
        {
            query = "SELECT bc.costname, fa.name, co.costdate, co.costnote, co.costquan FROM cost AS co INNER JOIN basecost AS bc ON co.bcid = bc.bcid INNER JOIN family AS fa ON co.memid = fa.memid WHERE (co.cid <> 0) ";
            if (txtbcid.Text.Trim().Length != 0)
                query += "AND co.bcid=" + selectedkeybcid;
            if (txtmemidC.Text.Trim().Length != 0)
                query += "AND co.memid=" + selectedkeymem;
            if (txtcostnote.Text.Trim().Length != 0)
                query += "AND co.costnote like (N'%" + txtcostnote.Text + "%')";
            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND co.costdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND co.costdate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND co.costdate < '" + txtenddate.Text + "'";

            if (txtcostmin.Value.ToString() != "0" && txtcostmax.Value.ToString() != "0")
                query += "AND costquan between " + txtcostmin.Value.ToString() + " and " + txtcostmax.Value.ToString();
            else if (txtcostmin.Value.ToString() != "0")
                query += "AND costquan > " + txtcostmin.Value.ToString();
            else if (txtcostmax.Value.ToString() != "0")
                query += "AND costquan < " + txtcostmax.Value.ToString();

            ds = ado.select(query);
            repDataGrid.DataSource = ds.Tables[0];
        }

        private void btnInsSal_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from basesal");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from basesal");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybsid = dgvr.Cells[0].Value.ToString();
                txtbsid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnInsCost_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from basecost");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from basecost");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybcid = dgvr.Cells[0].Value.ToString();
                txtbcid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnInsMem_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymem = dgvr.Cells[0].Value.ToString();
                txtmemidC.Text = dgvr.Cells[1].Value.ToString();
                txtaccmemid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnchAcc_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                                + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                                + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                                + "ON bnk.bbid = bb.bbid");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                                + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                                + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                                + "ON bnk.bbid = bb.bbid");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeyloan = dgvr.Cells[0].Value.ToString();
                selectedkeyaccid = dgvr.Cells[1].Value.ToString();
                txtaccid.Text = dgvr.Cells[1].Value.ToString();
                txtloanP.Text = dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[1].Value.ToString() + " - " + dgvr.Cells[4].Value.ToString() + " شعبه " + dgvr.Cells[5].Value.ToString() + " کد " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnInscsid_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from cheqset where accid='" + selectedkeyaccid + "'");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from cheqset where accid='" + selectedkeyaccid + "'");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeycsid = dgvr.Cells[0].Value.ToString();
                txtcsid.Text = "دسته چک سری" + dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnInsBankid_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT b.bankid, b.branchid, k.bankname, b.branchname FROM banks AS b INNER JOIN basebank AS k ON b.bbid = k.bbid");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT b.bankid, b.branchid, k.bankname, b.branchname FROM banks AS b INNER JOIN basebank AS k ON b.bbid = k.bbid");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybankid = dgvr.Cells[0].Value.ToString();
                txtbankid.Text = dgvr.Cells[1].Value.ToString() + "-" + dgvr.Cells[2].Value.ToString() + " شعبه " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnInsbaid_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from baseacc");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from baseacc");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybaid = dgvr.Cells[0].Value.ToString();
                txtbaid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void btnIncAcc_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT lo.loanid, fa.name, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbacktype FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("SELECT lo.loanid, fa.name, lo.accid, lo.loandate, lo.loantype, lo.loanquan, lo.loanrate, lo.loanback, lo.loanbacktype FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeyloan = dgvr.Cells[0].Value.ToString();
                txtloanP.Text = dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[1].Value.ToString() + " - " + dgvr.Cells[4].Value.ToString() + " شعبه " + dgvr.Cells[5].Value.ToString() + " کد " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtnamePH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void txtbsid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void txtsalmin_TextChanged(object sender, EventArgs e)
        {
            if (txtsalmin.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtsalmin.Text) == null) return;
                if (ado.ExtractNumbers(txtsalmin.Text).Length == 13) ProcessTabKey(true);
                lblSalmin.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtsalmin.Text))) + " ریال";
            }
            else
                lblSalmin.Text = "";

        }

        private void txtsalmax_TextChanged(object sender, EventArgs e)
        {
            if (txtsalmax.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtsalmax.Text) == null) return;
                if (ado.ExtractNumbers(txtsalmax.Text).Length == 13) ProcessTabKey(true);
                lblSalmax.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtsalmax.Text))) + " ریال";
            }
            else
                lblSalmax.Text = "";
        }

        private void txtcostmin_TextChanged(object sender, EventArgs e)
        {
            if (txtcostmin.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcostmin.Text) == null) return;
                if (ado.ExtractNumbers(txtcostmin.Text).Length == 13) ProcessTabKey(true);
                lblCostmin.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcostmin.Text))) + " ریال";
            }
            else
                lblCostmin.Text = "";
        }

        private void txtcostmax_TextChanged(object sender, EventArgs e)
        {
            if (txtcostmax.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcostmax.Text) == null) return;
                if (ado.ExtractNumbers(txtcostmax.Text).Length == 13) ProcessTabKey(true);
                lblCostmax.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcostmax.Text))) + " ریال";
            }
            else
                lblCostmax.Text = "";
        }

        private void txtcheqquanmin_TextChanged(object sender, EventArgs e)
        {
            if (txtcheqquanmin.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcheqquanmin.Text) == null) return;
                if (ado.ExtractNumbers(txtcheqquanmin.Text).Length == 13) ProcessTabKey(true);
                lblquanmin.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcheqquanmin.Text))) + " ریال";
            }
            else
                lblquanmin.Text = "";
        }

        private void txtcheqquanmax_TextChanged(object sender, EventArgs e)
        {
            if (txtcheqquanmax.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcheqquanmax.Text) == null) return;
                if (ado.ExtractNumbers(txtcheqquanmax.Text).Length == 13) ProcessTabKey(true);
                lblquanmax.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcheqquanmax.Text))) + " ریال";
            }
            else
                lblquanmax.Text = "";
        }

        private void txtloanqmin_TextChanged(object sender, EventArgs e)
        {
            if (txtloanqmin.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtloanqmin.Text) == null) return;
                if (ado.ExtractNumbers(txtloanqmin.Text).Length == 13) ProcessTabKey(true);
                lblloanqmin.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtloanqmin.Text))) + " ریال";
            }
            else
                lblloanqmin.Text = "";
        }

        private void txtloanqmax_TextChanged(object sender, EventArgs e)
        {
            if (txtloanqmax.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtloanqmax.Text) == null) return;
                if (ado.ExtractNumbers(txtloanqmax.Text).Length == 13) ProcessTabKey(true);
                lblloanqmax.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtloanqmax.Text))) + " ریال";
            }
            else
                lblloanqmax.Text = "";
        }
    }
}
