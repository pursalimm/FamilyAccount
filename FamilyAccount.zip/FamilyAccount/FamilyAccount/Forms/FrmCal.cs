﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FamilyAccount
{
    public partial class FrmCal : Form
    {
        ClassDB ado = new ClassDB();
        public FrmCal()
        {
            InitializeComponent();
        }

        public static FrmCal Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmCal();
            }
            return aForm;
        }

        private void txtmainMoney_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmCal_Load(object sender, EventArgs e)
        {
            txtmainMoney.Focus();
        }

        private void rdoRas_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRas.Checked == true)
            {
                if (txtmainMoney.Text.ToString() != "" || txtrate.Text.ToString() != "" || txttime.Text.ToString() != "")
                {
                    if (ado.ExtractNumbers(txttime.Text) == null) return;
                    if (ado.ExtractNumbers(txtmainMoney.Text) == null) return;
                    double result = (double.Parse(ado.ExtractNumbers(txtmainMoney.Text)) * double.Parse(txtrate.Value.ToString()) * int.Parse(txttime.Text)) / 36500;
                    txtavail.Text = result.ToString();
                    txtbackmoney.Text = (double.Parse(ado.ExtractNumbers(txtmainMoney.Text)) + result).ToString();
                }
                else
                {
                    txtmainMoney.Text = "";
                    txtrate.Text = "";
                    txttime.Text = "";
                }
            }
            else
            {
                if (txtmainMoney.Text.ToString() != "" || txtrate.Text.ToString() != "" || txttime.Text.ToString() != "")
                {
                    if (ado.ExtractNumbers(txtspace.Text) == null) return;
                    if (ado.ExtractNumbers(txtmonth.Text) == null) return;
                    if (ado.ExtractNumbers(txtmainMoney.Text) == null) return;
                    double result = (double.Parse(ado.ExtractNumbers(txtmainMoney.Text)) * double.Parse(txtrate.Value.ToString()) * (int.Parse(txtmonth.Text) + 1) * int.Parse(txtspace.Text)) / 2400;
                    txtavail.Text = result.ToString();
                    txtbackmoney.Text = (double.Parse(ado.ExtractNumbers(txtmainMoney.Text)) + result).ToString();
                }
                else
                {
                    txtmainMoney.Text = "";
                    txtrate.Text = "";
                    txttime.Text = "";
                    txtspace.Text = "";
                    txtmonth.Text = "";
                }
            }
        }
    }
}
