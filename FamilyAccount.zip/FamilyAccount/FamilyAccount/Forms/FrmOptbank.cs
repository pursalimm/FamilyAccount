﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    public partial class FrmOptbank : Form
    {
        string accountID = string.Empty;
        string qRemain = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        SqlConnection cnn = new SqlConnection(Properties.Settings.Default.AccountConnectionString);
        public FrmOptbank(string accID, string remain)
        {
            InitializeComponent();
            accountID = accID;
            qRemain = remain;
        }

        private void detailDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && detailDataGrid.RowCount > 0)
            {
                SelectedDetail();
                backContainer.Enabled = false;
                btnNew.Enabled = true;
                btnSave.Enabled = false;
            }
        }

        private void detailDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && detailDataGrid.RowCount > 0)
            {
                SelectedDetail();
                if (detailDataGrid.CurrentRow.Index == 0)
                    detailDataGrid[1, 0].Selected = true;
                else
                    detailDataGrid[1, detailDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
                backContainer.Enabled = false;
                btnNew.Enabled = true;
                btnSave.Enabled = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtaccid.Text = accountID;
            DataSet ds = ado.select("select accid,store from account where accid='" + accountID + "'");
            qRemain = ds.Tables[0].Rows[0]["store"].ToString();
            qRemain = qRemain.Substring(0, qRemain.Length - 5);
            txtquanremain.Value = qRemain;
            txtquandate.Focus();
        }

        private void UpdateStoreAcc()
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "update account set store=@store where accid=@accid";
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@store", SqlDbType.Money).Value = txtquanremain.Value.ToString();
            ado.update(cmd, CommandType.Text, cmd.CommandText);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            if (rdoTake.Checked == false && rdoSettle.Checked == false)
            {
                MessageBox.Show("شما هیچ گزینه ای را جهت تراکنش بانکی انتخاب ننموده اید", "برداشت یا واریز", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            if (rdoTake.Checked == true && txtquantake.Value.ToString()=="0")
            {
                MessageBox.Show("مبلغ برداشتی نمی تواند صفر باشد", "مبلغ برداشت", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            if (rdoSettle.Checked == true && txtquansettle.Value.ToString()=="0")
            {
                MessageBox.Show("مبلغ واریزی نمی تواند صفر باشد", "مبلغ واربز", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into fin_detail values(@accid,@quandate,@quannote,@quantake,@quansettle,@quanremain)";
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@quandate", SqlDbType.NVarChar).Value = txtquandate.Text;
            cmd.Parameters.Add("@quannote", SqlDbType.NVarChar).Value = txtquannote.Text;
            cmd.Parameters.Add("@quantake", SqlDbType.Money).Value = txtquantake.Value.ToString();
            cmd.Parameters.Add("@quansettle", SqlDbType.Money).Value = txtquansettle.Value.ToString();
            cmd.Parameters.Add("@quanremain", SqlDbType.Money).Value = txtquanremain.Value.ToString();
            if (ado.insert(cmd, CommandType.Text, cmd.CommandText))
            {
                cmd.Parameters.Clear();
                cmd.CommandText = "update account set store=@store where accid=@accid";
                cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
                cmd.Parameters.Add("@store", SqlDbType.Money).Value = txtquanremain.Value.ToString();
                cmd.Connection = cnn;
                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();
                ado.ClearControl(backContainer);
            }
            GridRefresh();
            btnNew.Enabled = true;
            btnSave.Enabled = false;
        }

        private void SelectedDetail()
        {
            txtaccid.Text = detailDataGrid["accid", detailDataGrid.CurrentRow.Index].Value.ToString();
            txtquandate.Text = detailDataGrid["quandate", detailDataGrid.CurrentRow.Index].Value.ToString();
            txtquannote.Text = detailDataGrid["quannote", detailDataGrid.CurrentRow.Index].Value.ToString();
            txtquantake.Text = detailDataGrid["quantake", detailDataGrid.CurrentRow.Index].Value.ToString();
            txtquansettle.Text = detailDataGrid["quansettle", detailDataGrid.CurrentRow.Index].Value.ToString();
            txtquanremain.Text = detailDataGrid["quanremain", detailDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void txtquandate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtquandate);
        }

        private void txtaccid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void FrmOptbank_Load(object sender, EventArgs e)
        {
            txtaccid.Text = accountID;
            txtquanremain.Value = qRemain;
            GridRefresh();
            ado.SetFarsiLanguage();
            btnNew.Enabled = false;
            btnSave.Enabled = true;
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from fin_detail where accid='" + accountID + "'");
            detailDataGrid.DataSource = ds.Tables[0];
            if (detailDataGrid.RowCount > 0)
            {
                double stake = 0, ssettle = 0, sremain = 0;
                foreach (DataGridViewRow row in detailDataGrid.Rows)
                {
                    stake += Convert.ToDouble(row.Cells["quantake"].Value);
                    ssettle += Convert.ToDouble(row.Cells["quansettle"].Value);
                    sremain += Convert.ToDouble(row.Cells["quanremain"].Value);
                }
                detailDataGrid.Rows[detailDataGrid.RowCount - 1].Cells[2].Value = "جمع کـــــل";
                detailDataGrid.Rows[detailDataGrid.RowCount - 1].Cells[3].Value = stake;
                detailDataGrid.Rows[detailDataGrid.RowCount - 1].Cells[4].Value = ssettle;
                detailDataGrid.Rows[detailDataGrid.RowCount - 1].Cells[5].Value = sremain;
            }
        }

        private void txtquantake_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void txtquantake_TextChanged(object sender, EventArgs e)
        {
            if (txtquantake.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtquantake.Text) == null) return;
                if (ado.ExtractNumbers(txtquantake.Text).Length == 13) ProcessTabKey(true);
                lblTake.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtquantake.Text))) + " ریال";
                txtquanremain.Text = Convert.ToString(long.Parse(qRemain) - long.Parse(ado.ExtractNumbers(txtquantake.Text)));
            }
            else
                lblTake.Text = "";
        }

        private void txtquansettle_TextChanged(object sender, EventArgs e)
        {
            if (txtquansettle.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtquansettle.Text) == null) return;
                if (ado.ExtractNumbers(txtquansettle.Text).Length == 13) ProcessTabKey(true);
                lblSettle.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtquansettle.Text))) + " ریال";
                txtquanremain.Text = Convert.ToString(long.Parse(qRemain) + long.Parse(ado.ExtractNumbers(txtquansettle.Text)));
            }
            else
                lblTake.Text = "";
        }

        private void txtquanremain_TextChanged(object sender, EventArgs e)
        {
            if (txtquanremain.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtquanremain.Text) == null) return;
                if (ado.ExtractNumbers(txtquanremain.Text).Length == 13) ProcessTabKey(true);
                lblRemain.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtquanremain.Text))) + " ریال";
            }
            else
                lblTake.Text = "";
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void txtaccid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void rdoTake_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoTake.Checked == true)
            {
                rdoSettle.Checked = false;
                txtquansettle.Enabled = false;
                txtquantake.Enabled = true;
                txtquantake.Value = 0;
                txtquansettle.Value = 0;
                txtquantake.Focus();
            }
        }

        private void rdoSettle_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoSettle.Checked == true)
            {
                rdoTake.Checked = false;
                txtquantake.Enabled = false;
                txtquansettle.Enabled = true;
                txtquantake.Value = 0;
                txtquansettle.Value = 0;
                txtquansettle.Focus();
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "select * from fin_detail where accid='" + txtaccid.Text + "' ";
            if (txtnoteS.Text.Trim().Length != 0)
                query += "AND quannote like (N'%" + txtnoteS.Text + "%') ";
            if (rdotakeS.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND quandate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate < '" + txtenddate.Text + "'";

                if (txtminMoney.Value.ToString() != "0" && txtmaxMoney.Value.ToString() != "0")
                    query += "AND quantake between " + txtminMoney.Value.ToString() + " and " + txtmaxMoney.Value.ToString();
                else if (txtminMoney.Value.ToString() != "0")
                    query += "AND quantake > " + txtminMoney.Value.ToString();
                else if (txtmaxMoney.Value.ToString() != "0")
                    query += "AND quantake < " + txtmaxMoney.Value.ToString();
            }
            else if (rdosettleS.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND quandate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate < '" + txtenddate.Text + "'";

                if (txtminMoney.Value.ToString() != "0" && txtmaxMoney.Value.ToString() != "0")
                    query += "AND quansettle between " + txtminMoney.Value.ToString() + " and " + txtmaxMoney.Value.ToString();
                else if (txtminMoney.Value.ToString() != "0")
                    query += "AND quansettle > " + txtminMoney.Value.ToString();
                else if (txtmaxMoney.Value.ToString() != "0")
                    query += "AND quansettle < " + txtmaxMoney.Value.ToString();
            }
            else if (rdoremainS.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND quandate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND quandate < '" + txtenddate.Text + "'";

                if (txtminMoney.Value.ToString() != "0" && txtmaxMoney.Value.ToString() != "0")
                    query += "AND quanremain between " + txtminMoney.Value.ToString() + " and " + txtmaxMoney.Value.ToString();
                else if (txtminMoney.Value.ToString() != "0")
                    query += "AND quanremain > " + txtminMoney.Value.ToString();
                else if (txtmaxMoney.Value.ToString() != "0")
                    query += "AND quanremain < " + txtmaxMoney.Value.ToString();
            }

            DataSet ds = ado.select(query);
            detailDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from fin_detail where accid='" + txtaccid.Text + "'");
            detailDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }
    }
}
