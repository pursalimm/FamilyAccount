﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    public partial class FrmFamily : Form
    {
        string idSel = "";
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public FrmFamily()
        {
            InitializeComponent();
        }

        public static FrmFamily Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmFamily();
            }
            return aForm;
        }

        private void btnOpenPic_Click(object sender, EventArgs e)
        {
            if (openPic.ShowDialog() == DialogResult.OK)
                picpicture.ImageLocation = openPic.FileName;
        }

        private void btnRemovePic_Click(object sender, EventArgs e)
        {
            picpicture.Image = (Image)Properties.Resources.nullPic;
        }

        private void txtusername_Enter(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

        private void txtusername_Leave(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

        private void FrmFamily_Load(object sender, EventArgs e)
        {
            GridRefresh();
            ado.SetFarsiLanguage();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
            cmd.Parameters.Add("@fathername", SqlDbType.NVarChar).Value = txtfathername.Text;
            cmd.Parameters.Add("@mothername", SqlDbType.NVarChar).Value = txtmothername.Text;
            cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = cbosex.Text;
            cmd.Parameters.Add("@birthdate", SqlDbType.NVarChar).Value = txtbirthdate.Text;
            cmd.Parameters.Add("@shenasid", SqlDbType.NVarChar).Value = txtshenasid.Text;
            cmd.Parameters.Add("@publicid", SqlDbType.NVarChar).Value = txtpublicid.Text;
            cmd.Parameters.Add("@postalcode", SqlDbType.NVarChar).Value = txtpostalcode.Text;
            cmd.Parameters.Add("@depend", SqlDbType.NVarChar).Value = cbodepend.Text;
            cmd.Parameters.Add("@matchstate", SqlDbType.NVarChar).Value = cbomatchstate.Text;
            cmd.Parameters.Add("@matchdate", SqlDbType.NVarChar).Value = txtmatchdate.Text;
            cmd.Parameters.Add("@picture", SqlDbType.Image).Value = ado.ImageToByte(picpicture.Image);
            if (ado.insert(cmd, CommandType.StoredProcedure, "spInsertFamily"))
            {
                if (cbodepend.Text.Equals("سرپرست"))
                {
                    Properties.Settings.Default.ExistSupervisor = true;
                    Properties.Settings.Default.Save();
                }
                ado.ClearControl(backContainer);
            }
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void txtmemid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnAbort.Enabled = true;
            cbodepend.Enabled = true;
            txtmatchdate.Visible = false;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            picpicture.Image = (Image)Properties.Resources.nullPic;
            txtname.Focus();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update family set name=@name,fathername=@fathername,mothername=@mothername,sex=@sex,birthdate=@birthdate,shenasid=@shenasid,publicid=@publicid,postalcode=@postalcode,depend=@depend,matchstate=@matchstate,matchdate=@matchdate,picture=@picture where memid=@memid";
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = txtname.Text;
            cmd.Parameters.Add("@fathername", SqlDbType.NVarChar).Value = txtfathername.Text;
            cmd.Parameters.Add("@mothername", SqlDbType.NVarChar).Value = txtmothername.Text;
            cmd.Parameters.Add("@sex", SqlDbType.NVarChar).Value = cbosex.Text;
            cmd.Parameters.Add("@birthdate", SqlDbType.NVarChar).Value = txtbirthdate.Text;
            cmd.Parameters.Add("@shenasid", SqlDbType.NVarChar).Value = txtshenasid.Text;
            cmd.Parameters.Add("@publicid", SqlDbType.NVarChar).Value = txtpublicid.Text;
            cmd.Parameters.Add("@postalcode", SqlDbType.NVarChar).Value = txtpostalcode.Text;
            cmd.Parameters.Add("@depend", SqlDbType.NVarChar).Value = cbodepend.Text;
            cmd.Parameters.Add("@matchstate", SqlDbType.NVarChar).Value = cbomatchstate.Text;
            cmd.Parameters.Add("@matchdate", SqlDbType.NVarChar).Value = txtmatchdate.Text;
            cmd.Parameters.Add("@picture", SqlDbType.Image).Value = ado.ImageToByte(picpicture.Image);
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
            {
                if (cbodepend.Text.Equals("سرپرست"))
                {
                    Properties.Settings.Default.ExistSupervisor = true;
                    Properties.Settings.Default.Save();
                }
                ado.ClearControl(backContainer);
            }
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from family where memid=@memid";
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                {
                    if (cbodepend.Text.Equals("سرپرست"))
                    {
                        Properties.Settings.Default.ExistSupervisor = false;
                        Properties.Settings.Default.Save();
                    }
                    ado.ClearControl(backContainer);
                }
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void cbomatchstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbomatchstate.SelectedIndex == 0 || cbomatchstate.Text == "")
            {
                txtmatchdate.Text = "";
                txtmatchdate.Visible = false;
            }
            else
            {
                txtmatchdate.Text = "";
                txtmatchdate.Visible = true;
            }
        }

        private void GridRefresh()
        {
            DataSet ds=ado.select("select * from family");
            FamilyDataGrid.DataSource = ds.Tables[0];
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            ado.ClearControl(backContainer);
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            picpicture.Image = (Image)Properties.Resources.nullPic;
        }

        private void picpicture_DoubleClick(object sender, EventArgs e)
        {
            picpicture.Image.Save(Application.StartupPath + "\\image.jpg");
            System.Diagnostics.Process.Start(@"C:\Windows\system32\rundll32.exe", @"C:\Windows\system32\shimgvw.dll,ImageView_Fullscreen " + Application.StartupPath + "\\image.jpg");
        }

        private void SelectedData()
        {
            idSel = FamilyDataGrid["memid", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtname.Text = FamilyDataGrid["name", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtfathername.Text = FamilyDataGrid["fathername", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtmothername.Text = FamilyDataGrid["mothername", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            cbosex.Text = FamilyDataGrid["sex", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtbirthdate.Text = FamilyDataGrid["birthdate", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtshenasid.Text = FamilyDataGrid["shenasid", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtpublicid.Text = FamilyDataGrid["publicid", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtpostalcode.Text = FamilyDataGrid["postalcode", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            cbodepend.Text = FamilyDataGrid["depend", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            cbomatchstate.Text = FamilyDataGrid["matchstate", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            txtmatchdate.Text = FamilyDataGrid["matchdate", FamilyDataGrid.CurrentRow.Index].Value.ToString();
            picpicture.Image = ado.ByteToImage((byte[])FamilyDataGrid["picture", FamilyDataGrid.CurrentRow.Index].Value);
        }

        private void FamilyDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (FamilyDataGrid.RowCount > 0)
            {
                if (FamilyDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void FamilyDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && FamilyDataGrid.RowCount > 0)
            {
                SelectedData();
                if (FamilyDataGrid.CurrentRow.Index == 0)
                    FamilyDataGrid[0, 0].Selected = true;
                else
                    FamilyDataGrid[0, FamilyDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void FamilyDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && FamilyDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtbirthdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtbirthdate);
        }

        private void txtmatchdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtmatchdate);
        }
    }
}   
