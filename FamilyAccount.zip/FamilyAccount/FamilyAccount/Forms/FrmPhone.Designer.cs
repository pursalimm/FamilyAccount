﻿namespace FamilyAccount
{
    partial class FrmPhone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmPhone aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem4 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem5 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem6 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPhone));
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem7 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem8 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem9 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem10 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem11 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem12 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtadres = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsite = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cborelation = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtcitycode = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtworktel = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtfax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txthometel = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmobile = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtemail = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.phoneDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.phid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.relation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.citycode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hometel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.worktel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.site = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtnamePH = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cboRelationPH = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtadres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cborelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcitycode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtworktel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthometel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmobile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.phoneDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamePH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRelationPH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.txtadres);
            this.backContainer.Controls.Add(this.txtsite);
            this.backContainer.Controls.Add(this.txtname);
            this.backContainer.Controls.Add(this.cborelation);
            this.backContainer.Controls.Add(this.txtcitycode);
            this.backContainer.Controls.Add(this.txtworktel);
            this.backContainer.Controls.Add(this.txtfax);
            this.backContainer.Controls.Add(this.txthometel);
            this.backContainer.Controls.Add(this.txtmobile);
            this.backContainer.Controls.Add(this.txtemail);
            this.backContainer.Location = new System.Drawing.Point(8, 34);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(689, 189);
            this.backContainer.TabIndex = 0;
            this.backContainer.Tag = "0";
            // 
            // txtadres
            // 
            this.txtadres.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtadres.CaptionStyle.CaptionSize = 110;
            this.txtadres.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtadres.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtadres.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtadres.CaptionStyle.TextStyle.Text = "آدرس";
            this.txtadres.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadres.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtadres.Location = new System.Drawing.Point(7, 156);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(675, 27);
            this.txtadres.TabIndex = 9;
            this.txtadres.Tag = "0";
            this.txtadres.ValidationStyle.AcceptsTab = true;
            this.txtadres.ValidationStyle.PasswordChar = '\0';
            this.txtadres.Value = "";
            this.txtadres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtsite
            // 
            this.txtsite.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsite.CaptionStyle.CaptionSize = 110;
            this.txtsite.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsite.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsite.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsite.CaptionStyle.TextStyle.Text = "سایت";
            this.txtsite.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsite.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsite.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsite.Location = new System.Drawing.Point(7, 125);
            this.txtsite.Name = "txtsite";
            this.txtsite.Size = new System.Drawing.Size(326, 27);
            this.txtsite.TabIndex = 8;
            this.txtsite.Tag = "0";
            this.txtsite.ValidationStyle.AcceptsTab = true;
            this.txtsite.ValidationStyle.PasswordChar = '\0';
            this.txtsite.Value = "";
            this.txtsite.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtname
            // 
            this.txtname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtname.CaptionStyle.CaptionSize = 110;
            this.txtname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtname.CaptionStyle.TextStyle.Text = "نام و نام خانوادگی";
            this.txtname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtname.Location = new System.Drawing.Point(414, 11);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(268, 27);
            this.txtname.TabIndex = 0;
            this.txtname.Tag = "1";
            this.txtname.ValidationStyle.AcceptsTab = true;
            this.txtname.ValidationStyle.PasswordChar = '\0';
            this.txtname.Value = "";
            this.txtname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // cborelation
            // 
            // 
            // 
            // 
            this.cborelation.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cborelation.CaptionStyle.CaptionSize = 110;
            this.cborelation.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cborelation.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cborelation.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cborelation.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cborelation.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cborelation.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cborelation.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cborelation.CaptionStyle.TextStyle.Text = "نسبت فامیلی";
            this.cborelation.CheckedDisplaySeparator = ',';
            this.cborelation.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cborelation.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cborelation.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cborelation.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cborelation.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cborelation.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cborelation.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cborelation.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cborelation.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cborelation.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = "0";
            elListBoxItem1.Value = "همسر";
            elListBoxItem2.Key = "1";
            elListBoxItem2.Value = "فرزند";
            elListBoxItem3.Key = "2";
            elListBoxItem3.Value = "آشنا/فامیل";
            elListBoxItem4.Key = "3";
            elListBoxItem4.Value = "دوست";
            elListBoxItem5.Key = "4";
            elListBoxItem5.Value = "همکار";
            elListBoxItem6.Key = "5";
            elListBoxItem6.Value = "سایر";
            this.cborelation.Items.Add(elListBoxItem1);
            this.cborelation.Items.Add(elListBoxItem2);
            this.cborelation.Items.Add(elListBoxItem3);
            this.cborelation.Items.Add(elListBoxItem4);
            this.cborelation.Items.Add(elListBoxItem5);
            this.cborelation.Items.Add(elListBoxItem6);
            this.cborelation.Location = new System.Drawing.Point(128, 9);
            this.cborelation.Name = "cborelation";
            this.cborelation.Size = new System.Drawing.Size(205, 27);
            this.cborelation.TabIndex = 1;
            this.cborelation.Tag = "1";
            this.cborelation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtcitycode
            // 
            this.txtcitycode.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcitycode.CaptionStyle.CaptionSize = 110;
            this.txtcitycode.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcitycode.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcitycode.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcitycode.CaptionStyle.TextStyle.Text = "کد شهر";
            this.txtcitycode.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcitycode.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcitycode.Location = new System.Drawing.Point(519, 40);
            this.txtcitycode.Name = "txtcitycode";
            this.txtcitycode.Size = new System.Drawing.Size(163, 27);
            this.txtcitycode.TabIndex = 2;
            this.txtcitycode.Tag = "0";
            this.txtcitycode.ValidationStyle.AcceptsTab = true;
            this.txtcitycode.ValidationStyle.PasswordChar = '\0';
            this.txtcitycode.Value = "";
            this.txtcitycode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtworktel
            // 
            this.txtworktel.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtworktel.CaptionStyle.CaptionSize = 110;
            this.txtworktel.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtworktel.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtworktel.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtworktel.CaptionStyle.TextStyle.Text = "تلفن محل کار";
            this.txtworktel.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtworktel.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtworktel.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtworktel.Location = new System.Drawing.Point(477, 98);
            this.txtworktel.Name = "txtworktel";
            this.txtworktel.Size = new System.Drawing.Size(205, 27);
            this.txtworktel.TabIndex = 5;
            this.txtworktel.Tag = "0";
            this.txtworktel.ValidationStyle.AcceptsTab = true;
            this.txtworktel.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtworktel.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtworktel.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txtworktel.ValidationStyle.PasswordChar = '\0';
            this.txtworktel.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtworktel.Value = "        ";
            this.txtworktel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtfax
            // 
            this.txtfax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtfax.CaptionStyle.CaptionSize = 110;
            this.txtfax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtfax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtfax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtfax.CaptionStyle.TextStyle.Text = "فاکس";
            this.txtfax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtfax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtfax.Location = new System.Drawing.Point(128, 96);
            this.txtfax.Name = "txtfax";
            this.txtfax.Size = new System.Drawing.Size(205, 27);
            this.txtfax.TabIndex = 6;
            this.txtfax.Tag = "0";
            this.txtfax.ValidationStyle.AcceptsTab = true;
            this.txtfax.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txtfax.ValidationStyle.PasswordChar = '\0';
            this.txtfax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtfax.Value = "        ";
            this.txtfax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txthometel
            // 
            this.txthometel.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txthometel.CaptionStyle.CaptionSize = 110;
            this.txthometel.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txthometel.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txthometel.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txthometel.CaptionStyle.TextStyle.Text = "تلفن منزل";
            this.txthometel.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthometel.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txthometel.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txthometel.Location = new System.Drawing.Point(477, 69);
            this.txthometel.Name = "txthometel";
            this.txthometel.Size = new System.Drawing.Size(205, 27);
            this.txthometel.TabIndex = 3;
            this.txthometel.Tag = "0";
            this.txthometel.ValidationStyle.AcceptsTab = true;
            this.txthometel.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txthometel.ValidationStyle.PasswordChar = '\0';
            this.txthometel.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txthometel.Value = "        ";
            this.txthometel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtmobile
            // 
            this.txtmobile.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmobile.CaptionStyle.CaptionSize = 110;
            this.txtmobile.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmobile.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmobile.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmobile.CaptionStyle.TextStyle.Text = "تلفن همراه";
            this.txtmobile.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmobile.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtmobile.Location = new System.Drawing.Point(128, 67);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtmobile.Size = new System.Drawing.Size(205, 27);
            this.txtmobile.TabIndex = 4;
            this.txtmobile.Tag = "0";
            this.txtmobile.ValidationStyle.AcceptsTab = true;
            this.txtmobile.ValidationStyle.MaskValidationStyle.Mask = "00000000000";
            this.txtmobile.ValidationStyle.PasswordChar = '\0';
            this.txtmobile.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtmobile.Value = "           ";
            this.txtmobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // txtemail
            // 
            this.txtemail.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtemail.CaptionStyle.CaptionSize = 110;
            this.txtemail.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtemail.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtemail.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtemail.CaptionStyle.TextStyle.Text = "ایمیل";
            this.txtemail.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtemail.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtemail.Location = new System.Drawing.Point(356, 127);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(326, 27);
            this.txtemail.TabIndex = 7;
            this.txtemail.Tag = "0";
            this.txtemail.ValidationStyle.AcceptsTab = true;
            this.txtemail.ValidationStyle.PasswordChar = '\0';
            this.txtemail.Value = "";
            this.txtemail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.Controls.Add(this.phoneDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.Location = new System.Drawing.Point(8, 225);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(689, 304);
            this.elRichPanel1.TabIndex = 10;
            this.elRichPanel1.Tag = "0";
            // 
            // phoneDataGrid
            // 
            this.phoneDataGrid.AllowUserToAddRows = false;
            this.phoneDataGrid.AllowUserToDeleteRows = false;
            this.phoneDataGrid.AllowUserToResizeColumns = false;
            this.phoneDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.phoneDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.phoneDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.phoneDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.phoneDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.phoneDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.phoneDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.phoneDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.phoneDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.phid,
            this.name,
            this.relation,
            this.citycode,
            this.hometel,
            this.worktel,
            this.mobile,
            this.fax,
            this.email,
            this.site,
            this.adres});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.phoneDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.phoneDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.phoneDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.phoneDataGrid.Location = new System.Drawing.Point(1, 16);
            this.phoneDataGrid.MultiSelect = false;
            this.phoneDataGrid.Name = "phoneDataGrid";
            this.phoneDataGrid.ReadOnly = true;
            this.phoneDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.phoneDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.phoneDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.phoneDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.phoneDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.phoneDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.phoneDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.phoneDataGrid.ShowCellErrors = false;
            this.phoneDataGrid.ShowCellToolTips = false;
            this.phoneDataGrid.ShowEditingIcon = false;
            this.phoneDataGrid.ShowRowErrors = false;
            this.phoneDataGrid.Size = new System.Drawing.Size(687, 272);
            this.phoneDataGrid.TabIndex = 0;
            this.phoneDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.phoneDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.phoneDataGrid_MouseClick);
            this.phoneDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.phoneDataGrid_CellClick);
            this.phoneDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.phoneDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // phid
            // 
            this.phid.DataPropertyName = "phid";
            this.phid.HeaderText = "کد";
            this.phid.Name = "phid";
            this.phid.ReadOnly = true;
            this.phid.Visible = false;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "نام";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // relation
            // 
            this.relation.DataPropertyName = "relation";
            this.relation.HeaderText = "نسبت فامیلی";
            this.relation.Name = "relation";
            this.relation.ReadOnly = true;
            // 
            // citycode
            // 
            this.citycode.DataPropertyName = "citycode";
            this.citycode.HeaderText = "کد شهر";
            this.citycode.Name = "citycode";
            this.citycode.ReadOnly = true;
            // 
            // hometel
            // 
            this.hometel.DataPropertyName = "hometel";
            this.hometel.HeaderText = "تلفن منزل";
            this.hometel.Name = "hometel";
            this.hometel.ReadOnly = true;
            // 
            // worktel
            // 
            this.worktel.DataPropertyName = "worktel";
            this.worktel.HeaderText = "تلفن محل کار";
            this.worktel.Name = "worktel";
            this.worktel.ReadOnly = true;
            // 
            // mobile
            // 
            this.mobile.DataPropertyName = "mobile";
            this.mobile.HeaderText = "تلفن همراه";
            this.mobile.Name = "mobile";
            this.mobile.ReadOnly = true;
            // 
            // fax
            // 
            this.fax.DataPropertyName = "fax";
            this.fax.HeaderText = "فاکس";
            this.fax.Name = "fax";
            this.fax.ReadOnly = true;
            this.fax.Visible = false;
            // 
            // email
            // 
            this.email.DataPropertyName = "email";
            this.email.HeaderText = "ایمیل";
            this.email.Name = "email";
            this.email.ReadOnly = true;
            this.email.Visible = false;
            // 
            // site
            // 
            this.site.DataPropertyName = "site";
            this.site.HeaderText = "سایت";
            this.site.Name = "site";
            this.site.ReadOnly = true;
            this.site.Visible = false;
            // 
            // adres
            // 
            this.adres.DataPropertyName = "adres";
            this.adres.HeaderText = "آدرس";
            this.adres.Name = "adres";
            this.adres.ReadOnly = true;
            this.adres.Visible = false;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(108, 535);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 1;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(9, 8, 688, 215);
            this.expandPanel.Location = new System.Drawing.Point(9, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(688, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 11;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.txtnamePH);
            this.BackSearch.Controls.Add(this.cboRelationPH);
            this.BackSearch.Location = new System.Drawing.Point(8, 33);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(670, 143);
            this.BackSearch.TabIndex = 10;
            // 
            // txtnamePH
            // 
            this.txtnamePH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtnamePH.CaptionStyle.CaptionSize = 110;
            this.txtnamePH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtnamePH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtnamePH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtnamePH.CaptionStyle.TextStyle.Text = "نام و نام خانوادگی";
            this.txtnamePH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnamePH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtnamePH.Location = new System.Drawing.Point(395, 6);
            this.txtnamePH.Name = "txtnamePH";
            this.txtnamePH.Size = new System.Drawing.Size(268, 27);
            this.txtnamePH.TabIndex = 0;
            this.txtnamePH.Tag = "0";
            this.txtnamePH.ValidationStyle.AcceptsTab = true;
            this.txtnamePH.ValidationStyle.PasswordChar = '\0';
            this.txtnamePH.Value = "";
            this.txtnamePH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // cboRelationPH
            // 
            // 
            // 
            // 
            this.cboRelationPH.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cboRelationPH.CaptionStyle.CaptionSize = 110;
            this.cboRelationPH.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboRelationPH.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cboRelationPH.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cboRelationPH.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboRelationPH.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboRelationPH.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cboRelationPH.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.cboRelationPH.CaptionStyle.TextStyle.Text = "نسبت فامیلی";
            this.cboRelationPH.CheckedDisplaySeparator = ',';
            this.cboRelationPH.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cboRelationPH.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cboRelationPH.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cboRelationPH.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles2.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles2.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cboRelationPH.DropDownItemSelectionStyle = elListBoxSelectionStyles2;
            this.cboRelationPH.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboRelationPH.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cboRelationPH.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cboRelationPH.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            elListBoxItem7.Key = "0";
            elListBoxItem7.Value = "همسر";
            elListBoxItem8.Key = "1";
            elListBoxItem8.Value = "فرزند";
            elListBoxItem9.Key = "2";
            elListBoxItem9.Value = "آشنا/فامیل";
            elListBoxItem10.Key = "3";
            elListBoxItem10.Value = "دوست";
            elListBoxItem11.Key = "4";
            elListBoxItem11.Value = "همکار";
            elListBoxItem12.Key = "5";
            elListBoxItem12.Value = "سایر";
            this.cboRelationPH.Items.Add(elListBoxItem7);
            this.cboRelationPH.Items.Add(elListBoxItem8);
            this.cboRelationPH.Items.Add(elListBoxItem9);
            this.cboRelationPH.Items.Add(elListBoxItem10);
            this.cboRelationPH.Items.Add(elListBoxItem11);
            this.cboRelationPH.Items.Add(elListBoxItem12);
            this.cboRelationPH.Location = new System.Drawing.Point(452, 34);
            this.cboRelationPH.Name = "cboRelationPH";
            this.cboRelationPH.Size = new System.Drawing.Size(211, 27);
            this.cboRelationPH.TabIndex = 1;
            this.cboRelationPH.Tag = "0";
            this.cboRelationPH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfname_KeyPress);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(82, 182);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 2;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(7, 182);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 3;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmPhone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 582);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.backContainer);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPhone";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "دفتر تلفن";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmPhone_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtadres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cborelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcitycode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtworktel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthometel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmobile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.phoneDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtnamePH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRelationPH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtname;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcitycode;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtworktel;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtfax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txthometel;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmobile;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtemail;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cborelation;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtadres;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsite;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView phoneDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn phid;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn relation;
        private System.Windows.Forms.DataGridViewTextBoxColumn citycode;
        private System.Windows.Forms.DataGridViewTextBoxColumn hometel;
        private System.Windows.Forms.DataGridViewTextBoxColumn worktel;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn site;
        private System.Windows.Forms.DataGridViewTextBoxColumn adres;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtnamePH;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cboRelationPH;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
    }
}