﻿namespace FamilyAccount
{
    partial class FrmBanks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmBanks aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBanks));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtbbid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtadres = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsite = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbranchid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbranchname = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcitycode = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtfax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsms = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txttel = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txttelbank = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtemail = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.bankDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bankid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bbid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.basebankBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.branchid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.branchname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.citycode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telbank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.site = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.basebankTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.basebankTableAdapter();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtbranchnameB = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbranchidB = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbbidB = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbbid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtadres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcitycode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttelbank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bankDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basebankBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchnameB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchidB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbbidB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // backContainer
            // 
            this.backContainer.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtbbid);
            this.backContainer.Controls.Add(this.txtnote);
            this.backContainer.Controls.Add(this.txtadres);
            this.backContainer.Controls.Add(this.txtsite);
            this.backContainer.Controls.Add(this.txtbranchid);
            this.backContainer.Controls.Add(this.txtbranchname);
            this.backContainer.Controls.Add(this.txtcitycode);
            this.backContainer.Controls.Add(this.txtfax);
            this.backContainer.Controls.Add(this.txtsms);
            this.backContainer.Controls.Add(this.txttel);
            this.backContainer.Controls.Add(this.txttelbank);
            this.backContainer.Controls.Add(this.txtemail);
            this.backContainer.Location = new System.Drawing.Point(7, 31);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(670, 242);
            this.backContainer.TabIndex = 0;
            this.backContainer.Tag = "0";
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(368, 6);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 1;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            // 
            // txtbbid
            // 
            this.txtbbid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbbid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbbid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbbid.CaptionStyle.CaptionSize = 97;
            this.txtbbid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbbid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbbid.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbid.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbid.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbbid.CaptionStyle.TextStyle.Text = "عنوان بانک";
            this.txtbbid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbbid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbbid.Location = new System.Drawing.Point(397, 6);
            this.txtbbid.Name = "txtbbid";
            this.txtbbid.Size = new System.Drawing.Size(263, 27);
            this.txtbbid.TabIndex = 0;
            this.txtbbid.Tag = "1";
            this.txtbbid.ValidationStyle.AcceptsTab = true;
            this.txtbbid.ValidationStyle.PasswordChar = '\0';
            this.txtbbid.ValidationStyle.ReadOnly = true;
            this.txtbbid.Value = "";
            this.txtbbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            this.txtbbid.Enter += new System.EventHandler(this.txtbbid_Enter);
            // 
            // txtnote
            // 
            this.txtnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtnote.CaptionStyle.CaptionSize = 100;
            this.txtnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtnote.CaptionStyle.TextStyle.Text = "توضیحات";
            this.txtnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtnote.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtnote.Location = new System.Drawing.Point(9, 209);
            this.txtnote.Name = "txtnote";
            this.txtnote.Size = new System.Drawing.Size(651, 27);
            this.txtnote.TabIndex = 12;
            this.txtnote.Tag = "0";
            this.txtnote.ValidationStyle.AcceptsTab = true;
            this.txtnote.ValidationStyle.PasswordChar = '\0';
            this.txtnote.Value = "";
            this.txtnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtadres
            // 
            this.txtadres.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtadres.CaptionStyle.CaptionSize = 100;
            this.txtadres.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtadres.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtadres.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtadres.CaptionStyle.TextStyle.Text = "آدرس";
            this.txtadres.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadres.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtadres.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtadres.Location = new System.Drawing.Point(9, 180);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(651, 27);
            this.txtadres.TabIndex = 11;
            this.txtadres.Tag = "0";
            this.txtadres.ValidationStyle.AcceptsTab = true;
            this.txtadres.ValidationStyle.PasswordChar = '\0';
            this.txtadres.Value = "";
            this.txtadres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtsite
            // 
            this.txtsite.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsite.CaptionStyle.CaptionSize = 100;
            this.txtsite.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsite.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsite.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsite.CaptionStyle.TextStyle.Text = "سایت";
            this.txtsite.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsite.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsite.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsite.Location = new System.Drawing.Point(9, 151);
            this.txtsite.Name = "txtsite";
            this.txtsite.Size = new System.Drawing.Size(305, 27);
            this.txtsite.TabIndex = 10;
            this.txtsite.Tag = "0";
            this.txtsite.ValidationStyle.AcceptsTab = true;
            this.txtsite.ValidationStyle.PasswordChar = '\0';
            this.txtsite.Value = "";
            this.txtsite.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtbranchid
            // 
            this.txtbranchid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbranchid.CaptionStyle.CaptionSize = 100;
            this.txtbranchid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbranchid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbranchid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbranchid.CaptionStyle.TextStyle.Text = "کد شعبه";
            this.txtbranchid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbranchid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbranchid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbranchid.Location = new System.Drawing.Point(489, 35);
            this.txtbranchid.Name = "txtbranchid";
            this.txtbranchid.Size = new System.Drawing.Size(171, 27);
            this.txtbranchid.TabIndex = 2;
            this.txtbranchid.Tag = "1";
            this.txtbranchid.ValidationStyle.AcceptsTab = true;
            this.txtbranchid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtbranchid.ValidationStyle.PasswordChar = '\0';
            this.txtbranchid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtbranchid.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtbranchid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtbranchname
            // 
            this.txtbranchname.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbranchname.CaptionStyle.CaptionSize = 100;
            this.txtbranchname.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbranchname.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbranchname.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbranchname.CaptionStyle.TextStyle.Text = "نام شعبه";
            this.txtbranchname.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbranchname.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbranchname.Location = new System.Drawing.Point(44, 35);
            this.txtbranchname.Name = "txtbranchname";
            this.txtbranchname.Size = new System.Drawing.Size(270, 27);
            this.txtbranchname.TabIndex = 3;
            this.txtbranchname.Tag = "1";
            this.txtbranchname.ValidationStyle.AcceptsTab = true;
            this.txtbranchname.ValidationStyle.PasswordChar = '\0';
            this.txtbranchname.Value = "";
            this.txtbranchname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtcitycode
            // 
            this.txtcitycode.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcitycode.CaptionStyle.CaptionSize = 100;
            this.txtcitycode.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcitycode.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcitycode.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcitycode.CaptionStyle.TextStyle.Text = "کد شهر";
            this.txtcitycode.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcitycode.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcitycode.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcitycode.Location = new System.Drawing.Point(505, 64);
            this.txtcitycode.Name = "txtcitycode";
            this.txtcitycode.Size = new System.Drawing.Size(155, 27);
            this.txtcitycode.TabIndex = 4;
            this.txtcitycode.Tag = "0";
            this.txtcitycode.ValidationStyle.AcceptsTab = true;
            this.txtcitycode.ValidationStyle.PasswordChar = '\0';
            this.txtcitycode.Value = "";
            this.txtcitycode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtfax
            // 
            this.txtfax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtfax.CaptionStyle.CaptionSize = 100;
            this.txtfax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtfax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtfax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtfax.CaptionStyle.TextStyle.Text = "فاکس";
            this.txtfax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtfax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtfax.Location = new System.Drawing.Point(457, 93);
            this.txtfax.Name = "txtfax";
            this.txtfax.Size = new System.Drawing.Size(203, 27);
            this.txtfax.TabIndex = 6;
            this.txtfax.Tag = "0";
            this.txtfax.ValidationStyle.AcceptsTab = true;
            this.txtfax.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtfax.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtfax.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txtfax.ValidationStyle.PasswordChar = '\0';
            this.txtfax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtfax.Value = "        ";
            this.txtfax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtsms
            // 
            this.txtsms.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsms.CaptionStyle.CaptionSize = 100;
            this.txtsms.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsms.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsms.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsms.CaptionStyle.TextStyle.Text = "پیام کوتاه";
            this.txtsms.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsms.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsms.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsms.Location = new System.Drawing.Point(457, 122);
            this.txtsms.Name = "txtsms";
            this.txtsms.Size = new System.Drawing.Size(203, 27);
            this.txtsms.TabIndex = 8;
            this.txtsms.Tag = "0";
            this.txtsms.ValidationStyle.AcceptsTab = true;
            this.txtsms.ValidationStyle.PasswordChar = '\0';
            this.txtsms.Value = "";
            this.txtsms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txttel
            // 
            this.txttel.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txttel.CaptionStyle.CaptionSize = 100;
            this.txttel.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txttel.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txttel.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txttel.CaptionStyle.TextStyle.Text = "تلفن";
            this.txttel.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttel.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txttel.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txttel.Location = new System.Drawing.Point(111, 64);
            this.txttel.Name = "txttel";
            this.txttel.Size = new System.Drawing.Size(203, 27);
            this.txttel.TabIndex = 5;
            this.txttel.Tag = "0";
            this.txttel.ValidationStyle.AcceptsTab = true;
            this.txttel.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txttel.ValidationStyle.PasswordChar = '\0';
            this.txttel.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txttel.Value = "        ";
            this.txttel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txttelbank
            // 
            this.txttelbank.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txttelbank.CaptionStyle.CaptionSize = 100;
            this.txttelbank.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txttelbank.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txttelbank.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txttelbank.CaptionStyle.TextStyle.Text = "تلفنبانک";
            this.txttelbank.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttelbank.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txttelbank.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txttelbank.Location = new System.Drawing.Point(111, 93);
            this.txttelbank.Name = "txttelbank";
            this.txttelbank.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txttelbank.Size = new System.Drawing.Size(203, 27);
            this.txttelbank.TabIndex = 7;
            this.txttelbank.Tag = "0";
            this.txttelbank.ValidationStyle.AcceptsTab = true;
            this.txttelbank.ValidationStyle.MaskValidationStyle.Mask = "00000000";
            this.txttelbank.ValidationStyle.PasswordChar = '\0';
            this.txttelbank.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txttelbank.Value = "        ";
            this.txttelbank.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtemail
            // 
            this.txtemail.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtemail.CaptionStyle.CaptionSize = 100;
            this.txtemail.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtemail.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtemail.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtemail.CaptionStyle.TextStyle.Text = "ایمیل";
            this.txtemail.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtemail.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtemail.Location = new System.Drawing.Point(355, 151);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(305, 27);
            this.txtemail.TabIndex = 9;
            this.txtemail.Tag = "0";
            this.txtemail.ValidationStyle.AcceptsTab = true;
            this.txtemail.ValidationStyle.PasswordChar = '\0';
            this.txtemail.Value = "";
            this.txtemail.Leave += new System.EventHandler(this.txtemail_Leave);
            this.txtemail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            this.txtemail.Enter += new System.EventHandler(this.txtemail_Enter);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.Controls.Add(this.bankDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.Location = new System.Drawing.Point(7, 279);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(670, 225);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // bankDataGrid
            // 
            this.bankDataGrid.AllowUserToAddRows = false;
            this.bankDataGrid.AllowUserToDeleteRows = false;
            this.bankDataGrid.AllowUserToResizeColumns = false;
            this.bankDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.bankDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bankDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bankDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.bankDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.bankDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bankDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bankDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.bankDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.bankid,
            this.bbid,
            this.branchid,
            this.branchname,
            this.citycode,
            this.tel,
            this.fax,
            this.telbank,
            this.sms,
            this.email,
            this.site,
            this.adres,
            this.note});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bankDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.bankDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bankDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.bankDataGrid.Location = new System.Drawing.Point(1, 16);
            this.bankDataGrid.MultiSelect = false;
            this.bankDataGrid.Name = "bankDataGrid";
            this.bankDataGrid.ReadOnly = true;
            this.bankDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bankDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.bankDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bankDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.bankDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.bankDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.bankDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bankDataGrid.ShowCellErrors = false;
            this.bankDataGrid.ShowCellToolTips = false;
            this.bankDataGrid.ShowEditingIcon = false;
            this.bankDataGrid.ShowRowErrors = false;
            this.bankDataGrid.Size = new System.Drawing.Size(668, 193);
            this.bankDataGrid.TabIndex = 0;
            this.bankDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.bankDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.bankDataGrid_MouseClick);
            this.bankDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bankDataGrid_CellClick);
            this.bankDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bankDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // bankid
            // 
            this.bankid.DataPropertyName = "bankid";
            this.bankid.HeaderText = "کد بانک";
            this.bankid.Name = "bankid";
            this.bankid.ReadOnly = true;
            this.bankid.Visible = false;
            // 
            // bbid
            // 
            this.bbid.DataPropertyName = "bbid";
            this.bbid.DataSource = this.basebankBindingSource;
            this.bbid.DisplayMember = "bankname";
            this.bbid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.bbid.HeaderText = "عنوان بانک";
            this.bbid.Name = "bbid";
            this.bbid.ReadOnly = true;
            this.bbid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.bbid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.bbid.ValueMember = "bbid";
            // 
            // basebankBindingSource
            // 
            this.basebankBindingSource.DataMember = "basebank";
            this.basebankBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // branchid
            // 
            this.branchid.DataPropertyName = "branchid";
            this.branchid.HeaderText = "کد شعبه";
            this.branchid.Name = "branchid";
            this.branchid.ReadOnly = true;
            // 
            // branchname
            // 
            this.branchname.DataPropertyName = "branchname";
            this.branchname.HeaderText = "نام شعبه";
            this.branchname.Name = "branchname";
            this.branchname.ReadOnly = true;
            // 
            // citycode
            // 
            this.citycode.DataPropertyName = "citycode";
            this.citycode.HeaderText = "کد شهر";
            this.citycode.Name = "citycode";
            this.citycode.ReadOnly = true;
            this.citycode.Visible = false;
            // 
            // tel
            // 
            this.tel.DataPropertyName = "tel";
            this.tel.HeaderText = "تلفن";
            this.tel.Name = "tel";
            this.tel.ReadOnly = true;
            // 
            // fax
            // 
            this.fax.DataPropertyName = "fax";
            this.fax.HeaderText = "فاکس";
            this.fax.Name = "fax";
            this.fax.ReadOnly = true;
            this.fax.Visible = false;
            // 
            // telbank
            // 
            this.telbank.DataPropertyName = "telbank";
            this.telbank.HeaderText = "تلفنبانک";
            this.telbank.Name = "telbank";
            this.telbank.ReadOnly = true;
            // 
            // sms
            // 
            this.sms.DataPropertyName = "sms";
            this.sms.HeaderText = "پیام کوتاه";
            this.sms.Name = "sms";
            this.sms.ReadOnly = true;
            this.sms.Visible = false;
            // 
            // email
            // 
            this.email.DataPropertyName = "email";
            this.email.HeaderText = "ایمیل";
            this.email.Name = "email";
            this.email.ReadOnly = true;
            this.email.Visible = false;
            // 
            // site
            // 
            this.site.DataPropertyName = "site";
            this.site.HeaderText = "سایت";
            this.site.Name = "site";
            this.site.ReadOnly = true;
            this.site.Visible = false;
            // 
            // adres
            // 
            this.adres.DataPropertyName = "adres";
            this.adres.HeaderText = "آدرس";
            this.adres.Name = "adres";
            this.adres.ReadOnly = true;
            this.adres.Visible = false;
            // 
            // note
            // 
            this.note.DataPropertyName = "note";
            this.note.HeaderText = "توضیحات";
            this.note.Name = "note";
            this.note.ReadOnly = true;
            this.note.Visible = false;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.btnDelete);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Controls.Add(this.btnSave);
            this.elContainer1.Controls.Add(this.btnNew);
            this.elContainer1.Location = new System.Drawing.Point(97, 510);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(489, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // basebankTableAdapter
            // 
            this.basebankTableAdapter.ClearBeforeFill = true;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(8, 5, 669, 268);
            this.expandPanel.Location = new System.Drawing.Point(8, 5);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(669, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 4;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.txtbranchnameB);
            this.BackSearch.Controls.Add(this.txtbranchidB);
            this.BackSearch.Controls.Add(this.txtbbidB);
            this.BackSearch.Location = new System.Drawing.Point(8, 32);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(653, 197);
            this.BackSearch.TabIndex = 6;
            // 
            // txtbranchnameB
            // 
            this.txtbranchnameB.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbranchnameB.CaptionStyle.CaptionSize = 100;
            this.txtbranchnameB.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbranchnameB.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbranchnameB.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbranchnameB.CaptionStyle.TextStyle.Text = "نام شعبه";
            this.txtbranchnameB.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbranchnameB.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbranchnameB.Location = new System.Drawing.Point(26, 38);
            this.txtbranchnameB.Name = "txtbranchnameB";
            this.txtbranchnameB.Size = new System.Drawing.Size(270, 27);
            this.txtbranchnameB.TabIndex = 2;
            this.txtbranchnameB.Tag = "1";
            this.txtbranchnameB.ValidationStyle.AcceptsTab = true;
            this.txtbranchnameB.ValidationStyle.PasswordChar = '\0';
            this.txtbranchnameB.Value = "";
            this.txtbranchnameB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtbranchidB
            // 
            this.txtbranchidB.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbranchidB.CaptionStyle.CaptionSize = 100;
            this.txtbranchidB.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbranchidB.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbranchidB.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbranchidB.CaptionStyle.TextStyle.Text = "کد شعبه";
            this.txtbranchidB.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbranchidB.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbranchidB.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbranchidB.Location = new System.Drawing.Point(471, 38);
            this.txtbranchidB.Name = "txtbranchidB";
            this.txtbranchidB.Size = new System.Drawing.Size(171, 27);
            this.txtbranchidB.TabIndex = 1;
            this.txtbranchidB.Tag = "1";
            this.txtbranchidB.ValidationStyle.AcceptsTab = true;
            this.txtbranchidB.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtbranchidB.ValidationStyle.PasswordChar = '\0';
            this.txtbranchidB.Value = "";
            this.txtbranchidB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // txtbbidB
            // 
            this.txtbbidB.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbbidB.CaptionStyle.CaptionSize = 97;
            this.txtbbidB.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbbidB.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbbidB.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbidB.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbidB.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbbidB.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbbidB.CaptionStyle.TextStyle.Text = "عنوان بانک";
            this.txtbbidB.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbbidB.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbbidB.Location = new System.Drawing.Point(379, 9);
            this.txtbbidB.Name = "txtbbidB";
            this.txtbbidB.Size = new System.Drawing.Size(263, 27);
            this.txtbbidB.TabIndex = 0;
            this.txtbbidB.Tag = "1";
            this.txtbbidB.ValidationStyle.AcceptsTab = true;
            this.txtbbidB.ValidationStyle.PasswordChar = '\0';
            this.txtbbidB.Value = "";
            this.txtbbidB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbankid_KeyPress);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(83, 235);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 4;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(8, 235);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 5;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // FrmBanks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 558);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.backContainer);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmBanks";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "بانکهای دارای حساب بانکی";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmBanks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbbid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtadres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcitycode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtfax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttelbank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bankDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basebankBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchnameB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbranchidB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbbidB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtadres;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsite;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbranchid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbranchname;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtfax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsms;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txttel;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txttelbank;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtemail;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtnote;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcitycode;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView bankDataGrid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbbid;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource basebankBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.basebankTableAdapter basebankTableAdapter;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn bankid;
        private System.Windows.Forms.DataGridViewComboBoxColumn bbid;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchid;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchname;
        private System.Windows.Forms.DataGridViewTextBoxColumn citycode;
        private System.Windows.Forms.DataGridViewTextBoxColumn tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn telbank;
        private System.Windows.Forms.DataGridViewTextBoxColumn sms;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn site;
        private System.Windows.Forms.DataGridViewTextBoxColumn adres;
        private System.Windows.Forms.DataGridViewTextBoxColumn note;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbbidB;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbranchidB;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbranchnameB;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
    }
}