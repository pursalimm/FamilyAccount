﻿namespace FamilyAccount
{
    partial class FrmPrompt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmPrompt aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrompt));
            this.lstCur = new System.Windows.Forms.ListBox();
            this.lstNext = new System.Windows.Forms.ListBox();
            this.rdoCur = new System.Windows.Forms.RadioButton();
            this.rdoNext = new System.Windows.Forms.RadioButton();
            this.lblClose = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstCur
            // 
            this.lstCur.BackColor = System.Drawing.Color.Gold;
            this.lstCur.FormattingEnabled = true;
            this.lstCur.ItemHeight = 14;
            this.lstCur.Location = new System.Drawing.Point(10, 24);
            this.lstCur.Name = "lstCur";
            this.lstCur.Size = new System.Drawing.Size(531, 116);
            this.lstCur.TabIndex = 6;
            this.lstCur.SelectedIndexChanged += new System.EventHandler(this.lstCur_SelectedIndexChanged);
            // 
            // lstNext
            // 
            this.lstNext.BackColor = System.Drawing.Color.Gold;
            this.lstNext.FormattingEnabled = true;
            this.lstNext.ItemHeight = 14;
            this.lstNext.Location = new System.Drawing.Point(10, 24);
            this.lstNext.Name = "lstNext";
            this.lstNext.Size = new System.Drawing.Size(531, 116);
            this.lstNext.TabIndex = 7;
            this.lstNext.SelectedIndexChanged += new System.EventHandler(this.lstNext_SelectedIndexChanged);
            // 
            // rdoCur
            // 
            this.rdoCur.AutoSize = true;
            this.rdoCur.BackColor = System.Drawing.Color.Transparent;
            this.rdoCur.Checked = true;
            this.rdoCur.ForeColor = System.Drawing.Color.Blue;
            this.rdoCur.Location = new System.Drawing.Point(275, 2);
            this.rdoCur.Name = "rdoCur";
            this.rdoCur.Size = new System.Drawing.Size(105, 18);
            this.rdoCur.TabIndex = 5;
            this.rdoCur.TabStop = true;
            this.rdoCur.Text = "رویدادهای جاری";
            this.rdoCur.UseVisualStyleBackColor = false;
            this.rdoCur.CheckedChanged += new System.EventHandler(this.rdoCur_CheckedChanged);
            // 
            // rdoNext
            // 
            this.rdoNext.AutoSize = true;
            this.rdoNext.BackColor = System.Drawing.Color.Transparent;
            this.rdoNext.ForeColor = System.Drawing.Color.Blue;
            this.rdoNext.Location = new System.Drawing.Point(160, 2);
            this.rdoNext.Name = "rdoNext";
            this.rdoNext.Size = new System.Drawing.Size(97, 18);
            this.rdoNext.TabIndex = 6;
            this.rdoNext.Text = "رویدادهای آتی";
            this.rdoNext.UseVisualStyleBackColor = false;
            this.rdoNext.CheckedChanged += new System.EventHandler(this.rdoNext_CheckedChanged);
            // 
            // lblClose
            // 
            this.lblClose.AutoSize = true;
            this.lblClose.BackColor = System.Drawing.Color.Transparent;
            this.lblClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClose.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblClose.ForeColor = System.Drawing.Color.Blue;
            this.lblClose.Location = new System.Drawing.Point(1, 0);
            this.lblClose.Name = "lblClose";
            this.lblClose.Size = new System.Drawing.Size(20, 19);
            this.lblClose.TabIndex = 8;
            this.lblClose.Text = "X";
            this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
            // 
            // FrmPrompt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(550, 150);
            this.ControlBox = false;
            this.Controls.Add(this.lblClose);
            this.Controls.Add(this.lstCur);
            this.Controls.Add(this.lstNext);
            this.Controls.Add(this.rdoNext);
            this.Controls.Add(this.rdoCur);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPrompt";
            this.Opacity = 0.8;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "اعلان";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.Load += new System.EventHandler(this.FrmPrompt_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstCur;
        private System.Windows.Forms.ListBox lstNext;
        private System.Windows.Forms.RadioButton rdoCur;
        private System.Windows.Forms.RadioButton rdoNext;
        private System.Windows.Forms.Label lblClose;
    }
}