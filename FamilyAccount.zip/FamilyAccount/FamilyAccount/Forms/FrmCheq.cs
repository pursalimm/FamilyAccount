﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmCheq : Form
    {
        string idSel = "";
        string selectedkeycsid = string.Empty;
        string selectedkeyaccid = string.Empty;
        DataSet ds = null;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmCheq()
        {
            InitializeComponent();
        }

        public static FrmCheq Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmCheq();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backType.Enabled = true;
            ado.ClearControl(backType);
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            cbocheqtype.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backType)) return;
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into cheq values(@cheqid,@csid,@cheqtype,@accid,@cheqexpo,@cheqdate,@cheqquan,@inmode,@cheqstate,@cheqnote)";
            cmd.Parameters.Add("@cheqid", SqlDbType.NVarChar).Value = txtcheqid.Text;
            if (cbocheqtype.SelectedIndex == 0)
                cmd.Parameters.Add("@csid", SqlDbType.Int).Value = selectedkeycsid;
            else
                cmd.Parameters.Add("@csid", SqlDbType.Int).Value = 0;
            cmd.Parameters.Add("@cheqtype", SqlDbType.NVarChar).Value = cbocheqtype.Text;
            if (cbocheqtype.SelectedIndex == 0)
                cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = selectedkeyaccid;
            else    
                cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@cheqexpo", SqlDbType.NVarChar).Value = txtcheqexpo.Text;
            cmd.Parameters.Add("@cheqdate", SqlDbType.NVarChar).Value = txtcheqdate.Text;
            cmd.Parameters.Add("@cheqquan", SqlDbType.Money).Value = txtcheqquan.Value.ToString();
            cmd.Parameters.Add("@inmode", SqlDbType.NVarChar).Value = txtinmode.Text;
            cmd.Parameters.Add("@cheqstate", SqlDbType.NVarChar).Value = cbocheqstate.Text;
            cmd.Parameters.Add("@cheqnote", SqlDbType.NText).Value = txtcheqnote.Text;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backType)) return;
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update cheq set csid=@csid,cheqid=@cheqid,cheqtype=@cheqtype,accid=@accid,cheqexpo=@cheqexpo,cheqdate=@cheqdate,cheqquan=@cheqquan,inmode=@inmode,cheqstate=@cheqstate,cheqnote=@cheqnote where idcs=@idcs";
            cmd.Parameters.Add("@idcs", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@cheqid", SqlDbType.NVarChar).Value = txtcheqid.Text;
            if (cbocheqtype.SelectedIndex == 0)
                cmd.Parameters.Add("@csid", SqlDbType.Int).Value = selectedkeycsid;
            else
                cmd.Parameters.Add("@csid", SqlDbType.Int).Value = 0;
            cmd.Parameters.Add("@cheqtype", SqlDbType.NVarChar).Value = cbocheqtype.Text;
            if (cbocheqtype.SelectedIndex == 0)
                cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = selectedkeyaccid;
            else
                cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@cheqexpo", SqlDbType.NVarChar).Value = txtcheqexpo.Text;
            cmd.Parameters.Add("@cheqdate", SqlDbType.NVarChar).Value = txtcheqdate.Text;
            cmd.Parameters.Add("@cheqquan", SqlDbType.Money).Value = txtcheqquan.Value.ToString();
            cmd.Parameters.Add("@inmode", SqlDbType.NVarChar).Value = txtinmode.Text;
            cmd.Parameters.Add("@cheqstate", SqlDbType.NVarChar).Value = cbocheqstate.Text;
            cmd.Parameters.Add("@cheqnote", SqlDbType.NText).Value = txtcheqnote.Text;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from cheq where idcs=@idcs";
            cmd.Parameters.Add("@idcs", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmCheq_Load(object sender, EventArgs e)
        {
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtaccid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from cheq");
            cheqDataGrid.DataSource = ds.Tables[0];
            if (cheqDataGrid.RowCount > 0)
            {
                double sum = 0;
                foreach (DataGridViewRow row in cheqDataGrid.Rows)
                    sum += Convert.ToDouble(row.Cells["cheqquan"].Value);
                lblsum.Text = sum.ToString("C0");
            }
        }

        private void cheqDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (cheqDataGrid.RowCount > 0)
            {
                if (cheqDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                    backType.Enabled = false;
                }
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backType.Enabled = false;
            ado.ClearControl(backType);
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
        }

        private void SelectedCheq()
        {
            idSel = cheqDataGrid["idcs", cheqDataGrid.CurrentRow.Index].Value.ToString();
            cbocheqtype.Text = cheqDataGrid["cheqtype", cheqDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeycsid = cheqDataGrid["csid", cheqDataGrid.CurrentRow.Index].Value.ToString();
            if (selectedkeycsid != "0")
            {
                ds = ado.select("SELECT csid, csseries, csdate FROM cheqset where csid=" + int.Parse(selectedkeycsid));
                txtcsid.Text = "دسته چک سری" + ds.Tables[0].Rows[0]["csseries"].ToString() + " - " + ds.Tables[0].Rows[0]["csdate"].ToString();
            }
            txtcheqid.Text = cheqDataGrid["cheqid", cheqDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeyaccid = cheqDataGrid["accid", cheqDataGrid.CurrentRow.Index].Value.ToString();
            ds = ado.select("SELECT fa.name, bnk.branchid, bb.bankname, bnk.branchname FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN "
                        +"baseacc AS ba ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid AND "
                        +"ac.accid= '"+ selectedkeyaccid +"'");
            if(ds.Tables[0].Rows.Count==1)
                txtaccid.Text = selectedkeyaccid + " - " + ds.Tables[0].Rows[0]["name"].ToString() + " - " + ds.Tables[0].Rows[0]["bankname"].ToString() + " شعبه " + ds.Tables[0].Rows[0]["branchname"].ToString() + " کد " + ds.Tables[0].Rows[0]["branchid"].ToString();
            else
                txtaccid.Text = cheqDataGrid["accid", cheqDataGrid.CurrentRow.Index].Value.ToString();
            txtcheqexpo.Text = cheqDataGrid["cheqexpo", cheqDataGrid.CurrentRow.Index].Value.ToString();
            txtcheqdate.Text = cheqDataGrid["cheqdate", cheqDataGrid.CurrentRow.Index].Value.ToString();
            txtcheqquan.Text = cheqDataGrid["cheqquan", cheqDataGrid.CurrentRow.Index].Value.ToString();
            txtinmode.Text = cheqDataGrid["inmode", cheqDataGrid.CurrentRow.Index].Value.ToString();
            cbocheqstate.Text = cheqDataGrid["cheqstate", cheqDataGrid.CurrentRow.Index].Value.ToString();
            txtcheqnote.Text = cheqDataGrid["cheqnote", cheqDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void cheqDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && cheqDataGrid.RowCount > 0)
            {
                SelectedCheq();
                if (cheqDataGrid.CurrentRow.Index == 0)
                    cheqDataGrid[0, 0].Selected = true;
                else
                    cheqDataGrid[0, cheqDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void cheqDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && cheqDataGrid.RowCount > 0)
                SelectedCheq();
        }

        private void txtcheqexpo_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtcheqexpo);
        }

        private void txtcheqdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtcheqdate);
        }

        private void txtcheqquan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void txtcheqquan_TextChanged(object sender, EventArgs e)
        {
            if (txtcheqquan.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtcheqquan.Text) == null) return;
                if (ado.ExtractNumbers(txtcheqquan.Text).Length == 13) ProcessTabKey(true);
                lblQuan.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtcheqquan.Text))) + " ریال";
            }
            else
                lblQuan.Text = "";
        }

        private void cbocheqtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbocheqtype.SelectedIndex == 0)
            {
                btnIns1.Visible = true;
                btnIns2.Visible = true;
                txtaccid.Enter += new EventHandler(txtaccid_Enter);
                txtcsid.Enter += new EventHandler(txtcsid_Enter);
                txtcheqid.Leave += new EventHandler(txtcheqid_Leave);
                txtaccid.ValidationStyle.ReadOnly = false;
                txtaccid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.String;
                txtcsid.Tag = "1";
                ado.ClearControl(backContainer);
            }
            else
            {
                btnIns1.Visible = false;
                btnIns2.Visible = false;
                txtaccid.Enter -= new EventHandler(txtaccid_Enter);
                txtcsid.Enter -= new EventHandler(txtcsid_Enter);
                txtcheqid.Leave -= new EventHandler(txtcheqid_Leave);
                txtaccid.ValidationStyle.ReadOnly = false;
                txtaccid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
                txtcsid.Tag = "0";
                ado.ClearControl(backContainer);
            }
        }

        private void txtcheqid_Leave(object sender, EventArgs e)
        {
            if (txtcsid.Text=="" || txtcheqid.Text == "0")
                return;
            DataSet ds = ado.select("select * from cheqset where csid=" + int.Parse(selectedkeycsid));
            if (decimal.Parse(txtcheqid.Text) >= decimal.Parse(ds.Tables[0].Rows[0]["csfirst"].ToString()) && decimal.Parse(txtcheqid.Text) <= decimal.Parse(ds.Tables[0].Rows[0]["csend"].ToString()))
            {
                return;
            }
            else
            {
                MessageBox.Show("شماره چک وارده شده نامعتبر می باشد", "شماره چک", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                txtcheqid.Text = "";
                txtcheqid.Focus();
            }
        }

        private void btnIns1_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                    +"FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                                    +"banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid WHERE (ba.accname = N'جاری')");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            FrmSelectRow fsr = new FrmSelectRow("SELECT fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname, ac.store, ba.accname "
                                                +"FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba ON ac.baid = ba.baid INNER JOIN "
                                                +"banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb ON bnk.bbid = bb.bbid WHERE (ba.accname = N'جاری')");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeyaccid = dgvr.Cells[1].Value.ToString();
                txtaccid.Text = dgvr.Cells[1].Value.ToString() + " - " + dgvr.Cells[0].Value.ToString() + " - " + dgvr.Cells[3].Value.ToString() + " شعبه " + dgvr.Cells[4].Value.ToString() + " کد " + dgvr.Cells[2].Value.ToString();
            }
            txtcsid.Text = "";
            ProcessTabKey(true);
        }

        private void btnIns2_Click(object sender, EventArgs e)
        {
            if (txtaccid.Text == "")
            {
                MessageBox.Show("لطفا شماره حساب خود را انتخاب نمائید", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            DataSet ds = ado.select("select * from cheqset where accid='" + selectedkeyaccid + "'");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from cheqset where accid='" + selectedkeyaccid + "'");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeycsid = dgvr.Cells[0].Value.ToString();
                txtcsid.Text = "دسته چک سری" + dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtaccid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void txtcsid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT idcs, cheqid, csid, cheqtype, accid, cheqexpo, cheqdate, cheqquan, inmode, cheqstate, cheqnote FROM cheq AS ch WHERE (idcs <> 0) ";
            if (cbotypeCH.Text.Trim().Length != 0)
                query += "AND cheqtype like (N'%" + cbotypeCH.Text + "%')";
            if (txtaccidCH.Text.Trim().Length != 0)
                query += "AND accid= '" + txtaccidCH.Text + "'";
            if (txtcsidCH.Text.Trim().Length != 0)
                query += "AND csid=" + selectedkeycsid;
            if (txtinmodeCH.Text.Trim().Length != 0)
                query += "AND inmode like (N'%" + txtinmodeCH.Text + "%')";
            if (cbostateCH.Text.Trim().Length != 0)
                query += "AND cheqstate like (N'%" + cbostateCH.Text + "%')";

            if (rdochExpo.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqexpo between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND cheqexpo > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqexpo < '" + txtenddate.Text + "'";
            }
            else if (rdochdate.Checked == true)
            {
                if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqdate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
                else if (txtstartdate.Text.Trim().Length != 0)
                    query += "AND cheqdate > '" + txtstartdate.Text + "'";
                else if (txtenddate.Text.Trim().Length != 0)
                    query += "AND cheqdate < '" + txtenddate.Text + "'";
            }

            if (txtcheqquanmin.Value.ToString() != "0" && txtcheqquanmax.Value.ToString() != "0")
                query += "AND cheqquan between " + txtcheqquanmin.Value.ToString() + " and " + txtcheqquanmax.Value.ToString();
            else if (txtcheqquanmin.Value.ToString() != "0")
                query += "AND cheqquan > " + txtcheqquanmin.Value.ToString();
            else if (txtcheqquanmax.Value.ToString() != "0")
                query += "AND cheqquan < " + txtcheqquanmax.Value.ToString();

            DataSet ds = ado.select(query);
            cheqDataGrid.DataSource = ds.Tables[0];
            selectedkeycsid = string.Empty;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT idcs, cheqid, csid, cheqtype, accid, cheqexpo, cheqdate, cheqquan, inmode, cheqstate, cheqnote FROM cheq AS ch WHERE (idcs <> 0) ");
            cheqDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }

        private void btnInsCH_Click(object sender, EventArgs e)
        {
            if (txtaccidCH.Text == "")
            {
                MessageBox.Show("لطفا شماره حساب خود را وارد نمائید", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            DataSet ds = ado.select("select * from cheqset where accid='" + txtaccidCH.Text + "'");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from cheqset where accid='" + txtaccidCH.Text + "'");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeycsid = dgvr.Cells[0].Value.ToString();
                txtcsidCH.Text = "دسته چک سری" + dgvr.Cells[2].Value.ToString() + " - " + dgvr.Cells[3].Value.ToString();
            }
            ProcessTabKey(true);
        }
    }
}
