﻿namespace FamilyAccount
{
    partial class FrmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmAbout aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAbout));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle3 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.elLabel3 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.elLabel2 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.elLabel1 = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel1)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundImageStyle.Alpha = 100;
            this.elRichPanel1.ContainerStyle.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.elRichPanel1.ContainerStyle.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.elRichPanel1.ContainerStyle.BackgroundImageStyle.ImageEffect = Klik.Windows.Forms.v1.Common.ImageEffect.Mirror;
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.elRichPanel1.Controls.Add(this.elLabel3);
            this.elRichPanel1.Controls.Add(this.label3);
            this.elRichPanel1.Controls.Add(this.label2);
            this.elRichPanel1.Controls.Add(this.label1);
            this.elRichPanel1.Controls.Add(this.elLabel2);
            this.elRichPanel1.Controls.Add(this.elLabel1);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.FooterStyle.Height = 20;
            this.elRichPanel1.FooterStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.elRichPanel1.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.elRichPanel1.FooterStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.elRichPanel1.HeaderStyle.Height = 24;
            this.elRichPanel1.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.elRichPanel1.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.Black;
            this.elRichPanel1.HeaderStyle.TextStyle.Text = "درباره نرم افزار";
            this.elRichPanel1.HeaderStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elRichPanel1.Location = new System.Drawing.Point(12, 12);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 24, 1, 20);
            this.elRichPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.elRichPanel1.Size = new System.Drawing.Size(395, 210);
            this.elRichPanel1.TabIndex = 0;
            this.elRichPanel1.Click += new System.EventHandler(this.FrmAbout_Click);
            // 
            // elLabel3
            // 
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel3.FlashStyle = paintStyle1;
            this.elLabel3.Location = new System.Drawing.Point(174, 163);
            this.elLabel3.Name = "elLabel3";
            this.elLabel3.Size = new System.Drawing.Size(154, 20);
            this.elLabel3.TabIndex = 137;
            this.elLabel3.TabStop = false;
            this.elLabel3.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel3.TextStyle.ForeColor = System.Drawing.Color.Gold;
            this.elLabel3.TextStyle.Text = "مهدی برات زاده جوینی";
            this.elLabel3.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elLabel3.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 14);
            this.label3.TabIndex = 136;
            this.label3.Text = "طراحی و پیاده سازی سیستم";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(308, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 14);
            this.label2.TabIndex = 135;
            this.label2.Text = "آنالیز سیستم";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(185, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 14);
            this.label1.TabIndex = 134;
            this.label1.Text = "سیستم حسابداری خانواده";
            // 
            // elLabel2
            // 
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel2.FlashStyle = paintStyle2;
            this.elLabel2.Location = new System.Drawing.Point(174, 117);
            this.elLabel2.Name = "elLabel2";
            this.elLabel2.Size = new System.Drawing.Size(154, 20);
            this.elLabel2.TabIndex = 132;
            this.elLabel2.TabStop = false;
            this.elLabel2.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel2.TextStyle.ForeColor = System.Drawing.Color.Gold;
            this.elLabel2.TextStyle.Text = "مهندس سعید نوروزیان";
            this.elLabel2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.elLabel2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elLabel1
            // 
            paintStyle3.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle3.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elLabel1.FlashStyle = paintStyle3;
            this.elLabel1.Location = new System.Drawing.Point(142, 51);
            this.elLabel1.Name = "elLabel1";
            this.elLabel1.Size = new System.Drawing.Size(230, 22);
            this.elLabel1.TabIndex = 131;
            this.elLabel1.TabStop = false;
            this.elLabel1.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elLabel1.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.elLabel1.TextStyle.Text = "اولین نرم افزار حسابداری خانواده ایرانی";
            this.elLabel1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(419, 234);
            this.ControlBox = false;
            this.Controls.Add(this.elRichPanel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAbout";
            this.Opacity = 0.75;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "درباره ...";
            this.TopMost = true;
            this.Click += new System.EventHandler(this.FrmAbout_Click);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            this.elRichPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elLabel1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel1;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel elLabel2;
    }
}