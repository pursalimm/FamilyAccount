﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    public partial class FrmPayment : Form
    {
        string idSel = "";
        string loanCode = string.Empty;
        string selectedkeymemid = string.Empty;
        string selectedloanid = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmPayment(string loan)
        {
            InitializeComponent();
            loanCode = loan;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update pay_settle set datepay=@datepay,memid=@memid,setwage=@setwage,setdelay=@setdelay,setstate=@setstate,setnote=@setnote where idpay=@idpay";
            cmd.Parameters.Add("@idpay", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@datepay", SqlDbType.NVarChar).Value = txtdatepay.Text;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymemid;
            cmd.Parameters.Add("@setwage", SqlDbType.Money).Value = txtsetwage.Value.ToString();
            cmd.Parameters.Add("@setdelay", SqlDbType.Money).Value = txtsetdelay.Value.ToString();
            cmd.Parameters.Add("@setstate", SqlDbType.NVarChar).Value = cbosetstate.Text;
            cmd.Parameters.Add("@setnote", SqlDbType.NText).Value = txtsetnote.Text;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnEdit.Enabled = false;
            btnAbort.Enabled = false;
            ado.ClearControl(backContainer);
            backContainer.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from pay_settle where loanid='" + loanCode + "'");
            payDataGrid.DataSource = ds.Tables[0];
        }

        private void SelectedData()
        {
            idSel = payDataGrid["idpay", payDataGrid.CurrentRow.Index].Value.ToString();
            selectedloanid = payDataGrid["loanid", payDataGrid.CurrentRow.Index].Value.ToString();
            txtdateusan.Text = payDataGrid["dateusan", payDataGrid.CurrentRow.Index].Value.ToString();
            txtpayquan.Text = payDataGrid["payquan", payDataGrid.CurrentRow.Index].Value.ToString();
            txtdatepay.Text = payDataGrid["datepay", payDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeymemid = payDataGrid["memid", payDataGrid.CurrentRow.Index].Value.ToString();
            DataSet ds = ado.select("select name from family where memid='" + selectedkeymemid + "'");
            if (ds.Tables[0].Rows.Count == 0)
                txtmemid.Text = "";
            else
                txtmemid.Text = ds.Tables[0].Rows[0]["name"].ToString();
            txtsetwage.Text = payDataGrid["setwage", payDataGrid.CurrentRow.Index].Value.ToString();
            txtsetdelay.Text = payDataGrid["setdelay", payDataGrid.CurrentRow.Index].Value.ToString();
            cbosetstate.Text = payDataGrid["setstate", payDataGrid.CurrentRow.Index].Value.ToString();
            txtsetnote.Text = payDataGrid["setnote", payDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void payDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && payDataGrid.RowCount > 0)
            {
                SelectedData();
                if (payDataGrid.CurrentRow.Index == 0)
                    payDataGrid[0, 0].Selected = true;
                else
                    payDataGrid[0, payDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void payDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && payDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtdatepay_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtdatepay);
        }

        private void txtdateusan_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtdateusan);
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void txtdateusan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void FrmPayment_Load(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT fa.memid, fa.name, ac.accid, bnk.branchid, bb.bankname, bnk.branchname "
                                    + "FROM account AS ac INNER JOIN family AS fa ON ac.memid = fa.memid INNER JOIN baseacc AS ba "
                                    + "ON ac.baid = ba.baid INNER JOIN banks AS bnk ON ac.bankid = bnk.bankid INNER JOIN basebank AS bb "
                                    + "ON bnk.bbid = bb.bbid");
            lblLoan.Text = "اقساط تسهیلات شماره " + loanCode + "    -    " + ds.Tables[0].Rows[0]["accid"].ToString() + " - " + ds.Tables[0].Rows[0]["name"].ToString() + " - " + ds.Tables[0].Rows[0]["bankname"].ToString() + " شعبه " + ds.Tables[0].Rows[0]["branchname"].ToString() + " کد " + ds.Tables[0].Rows[0]["branchid"].ToString();
            familyTableAdapter.Fill(accountDataSet.family);
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymemid = dgvr.Cells[0].Value.ToString();
                txtmemid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void payDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (payDataGrid.RowCount > 0)
            {
                if (payDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnEdit.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                    txtdatepay.Focus();
                }
                else
                {
                    btnEdit.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void txtmemid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }
    }
}
