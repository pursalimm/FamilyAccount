﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FamilyAccount
{
    public partial class FrmSelectRow : Form
    {
        DataSet ds = null;
        string sqlCMD = string.Empty;
        ClassDB ado = new ClassDB();
        public DataGridViewRow dgvRow;

        public FrmSelectRow(string CMD)
        {
            sqlCMD = CMD;
            InitializeComponent();
        }

        private void FrmSelectRow_Load(object sender, EventArgs e)
        {
            ds = ado.select(sqlCMD);
            SelectDataGrid.DataSource = ds.Tables[0];
            FormSize();
        }

        private void SelectDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && SelectDataGrid.RowCount > 0)
            {
                dgvRow = SelectDataGrid.Rows[SelectDataGrid.CurrentRow.Index];
                this.Close();
            }
            else if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void SelectDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && SelectDataGrid.RowCount > 0)
            {
                dgvRow = SelectDataGrid.Rows[SelectDataGrid.CurrentRow.Index];
                this.Close();
            }
        }

        private void FormSize()
        {
            int sum = 0;
            for (int i = 0; i < SelectDataGrid.Columns.Count; i++)
                sum += SelectDataGrid.Rows[0].Cells[i].Size.Width;
            sum += 100;
            this.Size = new Size(sum, this.Width+50);
            txtSearch.Size = new Size(sum, this.Width + 50);
        }

        private void FrmSelectRow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                dgvRow = null;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text.Equals("جستجوی عبارت موردنظر"))
                return;
            ado.SearchGrid(SelectDataGrid, txtSearch.Text);
        }

        private void txtSearch_Enter(object sender, EventArgs e)
        {
            txtSearch.Text = "";
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            txtSearch.Text = "جستجوی عبارت موردنظر";
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13 || e.KeyChar == 27)
                ProcessTabKey(true);
        }
    }
}
