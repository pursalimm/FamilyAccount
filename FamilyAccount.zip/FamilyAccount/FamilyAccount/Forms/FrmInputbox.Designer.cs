﻿namespace FamilyAccount
{
    partial class FrmInputbox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInputbox));
            this.txtEnteredText = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnOk = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.txtEnteredText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEnteredText
            // 
            this.txtEnteredText.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtEnteredText.CaptionStyle.CaptionAlignment = Klik.Windows.Forms.v1.Common.SideAlignment.Top;
            this.txtEnteredText.CaptionStyle.CaptionSize = 25;
            this.txtEnteredText.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtEnteredText.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtEnteredText.CaptionStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicSilver;
            this.txtEnteredText.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtEnteredText.CaptionStyle.TextStyle.Text = "مقدار موردنظر را وارد نمائید";
            this.txtEnteredText.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnteredText.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtEnteredText.Location = new System.Drawing.Point(13, 14);
            this.txtEnteredText.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtEnteredText.Name = "txtEnteredText";
            this.txtEnteredText.Size = new System.Drawing.Size(501, 52);
            this.txtEnteredText.TabIndex = 0;
            this.txtEnteredText.Tag = "1";
            this.txtEnteredText.ValidationStyle.AcceptsTab = true;
            this.txtEnteredText.ValidationStyle.PasswordChar = '\0';
            this.txtEnteredText.Value = "";
            this.txtEnteredText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnteredText_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(13, 78);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(58, 25);
            this.btnClose.TabIndex = 2;
            this.btnClose.Tag = "0";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "انصراف";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnOk
            // 
            this.btnOk.BackgroundImageStyle.Alpha = 100;
            this.btnOk.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOk.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnOk.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnOk.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOk.Location = new System.Drawing.Point(75, 78);
            this.btnOk.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnOk.Name = "btnOk";
            this.btnOk.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnOk.Size = new System.Drawing.Size(58, 25);
            this.btnOk.TabIndex = 1;
            this.btnOk.Tag = "0";
            this.btnOk.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.TextStyle.Text = "تائید";
            this.btnOk.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.FormOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.kFormManager1.MainContainer = this;
            // 
            // FrmInputbox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 118);
            this.ControlBox = false;
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtEnteredText);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmInputbox";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ورود اطلاعات";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.txtEnteredText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnOk;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        public Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtEnteredText;
    }
}