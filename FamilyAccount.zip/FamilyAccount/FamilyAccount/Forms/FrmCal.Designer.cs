﻿namespace FamilyAccount
{
    partial class FrmCal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmCal aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCal));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.txtrate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmainMoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txttime = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtavail = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbackmoney = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtmonth = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtspace = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.rdoRas = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.rdoAghsat = new Klik.Windows.Forms.v1.EntryLib.ELRadioButton();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elContainer3 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtrate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmainMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtavail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbackmoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoRas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoAghsat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).BeginInit();
            this.elContainer3.SuspendLayout();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // txtrate
            // 
            this.txtrate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtrate.CaptionStyle.CaptionSize = 70;
            this.txtrate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtrate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtrate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtrate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtrate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtrate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrate.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txtrate.CaptionStyle.TextStyle.Text = "نرخ";
            this.txtrate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtrate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtrate.Location = new System.Drawing.Point(320, 35);
            this.txtrate.Name = "txtrate";
            this.txtrate.Size = new System.Drawing.Size(137, 27);
            this.txtrate.TabIndex = 1;
            this.txtrate.Tag = "1";
            this.txtrate.ValidationStyle.AcceptsTab = true;
            this.txtrate.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtrate.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtrate.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Percent;
            this.txtrate.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtrate.ValidationStyle.PasswordChar = '\0';
            this.txtrate.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtrate.Value = 0;
            this.txtrate.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            this.txtrate.TextChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            this.txtrate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // txtmainMoney
            // 
            this.txtmainMoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmainMoney.CaptionStyle.CaptionSize = 70;
            this.txtmainMoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmainMoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmainMoney.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmainMoney.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtmainMoney.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtmainMoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmainMoney.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txtmainMoney.CaptionStyle.TextStyle.Text = "اصل وام";
            this.txtmainMoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmainMoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmainMoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtmainMoney.Location = new System.Drawing.Point(235, 7);
            this.txtmainMoney.Name = "txtmainMoney";
            this.txtmainMoney.Size = new System.Drawing.Size(222, 27);
            this.txtmainMoney.TabIndex = 0;
            this.txtmainMoney.Tag = "1";
            this.txtmainMoney.ValidationStyle.AcceptsTab = true;
            this.txtmainMoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtmainMoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtmainMoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtmainMoney.ValidationStyle.PasswordChar = '\0';
            this.txtmainMoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtmainMoney.Value = 0;
            this.txtmainMoney.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            this.txtmainMoney.TextChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            this.txtmainMoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // txttime
            // 
            this.txttime.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txttime.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txttime.CaptionStyle.CaptionSize = 70;
            this.txttime.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txttime.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txttime.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txttime.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txttime.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txttime.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttime.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txttime.CaptionStyle.TextStyle.Text = "(مدت(روز";
            this.txttime.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttime.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txttime.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txttime.Location = new System.Drawing.Point(320, 63);
            this.txttime.Name = "txttime";
            this.txttime.Size = new System.Drawing.Size(137, 27);
            this.txttime.TabIndex = 2;
            this.txttime.Tag = "0";
            this.txttime.ValidationStyle.AcceptsTab = true;
            this.txttime.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txttime.ValidationStyle.NumericValidationStyle.Minimum = "1";
            this.txttime.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txttime.ValidationStyle.PasswordChar = '\0';
            this.txttime.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txttime.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txttime.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            this.txttime.TextChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            this.txttime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.Spin;
            // 
            // txtavail
            // 
            this.txtavail.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtavail.CaptionStyle.CaptionSize = 90;
            this.txtavail.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtavail.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtavail.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtavail.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtavail.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtavail.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtavail.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtavail.CaptionStyle.TextStyle.Text = "سود وام";
            this.txtavail.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtavail.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtavail.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtavail.Location = new System.Drawing.Point(239, 7);
            this.txtavail.Name = "txtavail";
            this.txtavail.Size = new System.Drawing.Size(219, 27);
            this.txtavail.TabIndex = 0;
            this.txtavail.Tag = "1";
            this.txtavail.ValidationStyle.AcceptsTab = true;
            this.txtavail.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtavail.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtavail.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtavail.ValidationStyle.PasswordChar = '\0';
            this.txtavail.ValidationStyle.ReadOnly = true;
            this.txtavail.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtavail.Value = 0;
            this.txtavail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // txtbackmoney
            // 
            this.txtbackmoney.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbackmoney.CaptionStyle.CaptionSize = 90;
            this.txtbackmoney.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbackmoney.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbackmoney.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbackmoney.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbackmoney.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtbackmoney.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbackmoney.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtbackmoney.CaptionStyle.TextStyle.Text = "مبلغ بازپرداخت";
            this.txtbackmoney.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbackmoney.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbackmoney.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbackmoney.Location = new System.Drawing.Point(7, 7);
            this.txtbackmoney.Name = "txtbackmoney";
            this.txtbackmoney.Size = new System.Drawing.Size(219, 27);
            this.txtbackmoney.TabIndex = 1;
            this.txtbackmoney.Tag = "1";
            this.txtbackmoney.ValidationStyle.AcceptsTab = true;
            this.txtbackmoney.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtbackmoney.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtbackmoney.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtbackmoney.ValidationStyle.PasswordChar = '\0';
            this.txtbackmoney.ValidationStyle.ReadOnly = true;
            this.txtbackmoney.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtbackmoney.Value = 0;
            this.txtbackmoney.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(6, 197);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(75, 27);
            this.btnClose.TabIndex = 3;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtmonth
            // 
            this.txtmonth.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtmonth.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmonth.CaptionStyle.CaptionSize = 120;
            this.txtmonth.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmonth.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmonth.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmonth.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtmonth.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtmonth.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonth.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txtmonth.CaptionStyle.TextStyle.Text = "(تعداد اقساط (ماه";
            this.txtmonth.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonth.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmonth.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtmonth.Location = new System.Drawing.Point(6, 35);
            this.txtmonth.Name = "txtmonth";
            this.txtmonth.Size = new System.Drawing.Size(177, 27);
            this.txtmonth.TabIndex = 3;
            this.txtmonth.Tag = "0";
            this.txtmonth.ValidationStyle.AcceptsTab = true;
            this.txtmonth.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtmonth.ValidationStyle.NumericValidationStyle.Minimum = "1";
            this.txtmonth.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtmonth.ValidationStyle.PasswordChar = '\0';
            this.txtmonth.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtmonth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtmonth.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            this.txtmonth.TextChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            this.txtmonth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // txtspace
            // 
            this.txtspace.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtspace.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtspace.CaptionStyle.CaptionSize = 120;
            this.txtspace.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtspace.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtspace.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtspace.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtspace.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtspace.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspace.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txtspace.CaptionStyle.TextStyle.Text = "فاصله اقساط وام";
            this.txtspace.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtspace.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtspace.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtspace.Location = new System.Drawing.Point(6, 63);
            this.txtspace.Name = "txtspace";
            this.txtspace.Size = new System.Drawing.Size(177, 27);
            this.txtspace.TabIndex = 4;
            this.txtspace.Tag = "0";
            this.txtspace.ValidationStyle.AcceptsTab = true;
            this.txtspace.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtspace.ValidationStyle.NumericValidationStyle.Minimum = "1";
            this.txtspace.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Decimal;
            this.txtspace.ValidationStyle.PasswordChar = '\0';
            this.txtspace.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtspace.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtspace.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Office2003;
            this.txtspace.TextChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            this.txtspace.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmainMoney_KeyPress);
            // 
            // rdoRas
            // 
            this.rdoRas.Checked = true;
            this.rdoRas.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoRas.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoRas.Location = new System.Drawing.Point(327, 7);
            this.rdoRas.Name = "rdoRas";
            this.rdoRas.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoRas.Size = new System.Drawing.Size(131, 27);
            this.rdoRas.TabIndex = 0;
            this.rdoRas.Tag = "0";
            this.rdoRas.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoRas.TextStyle.Text = "تسهیلات راس مدت";
            this.rdoRas.Value = true;
            this.rdoRas.CheckedChanged += new System.EventHandler(this.rdoRas_CheckedChanged);
            // 
            // rdoAghsat
            // 
            this.rdoAghsat.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.rdoAghsat.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.rdoAghsat.Location = new System.Drawing.Point(7, 7);
            this.rdoAghsat.Name = "rdoAghsat";
            this.rdoAghsat.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.rdoAghsat.Size = new System.Drawing.Size(131, 27);
            this.rdoAghsat.TabIndex = 1;
            this.rdoAghsat.TabStop = false;
            this.rdoAghsat.Tag = "0";
            this.rdoAghsat.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoAghsat.TextStyle.Text = "تسهیلات اقساطی";
            this.rdoAghsat.Value = false;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.txtmonth);
            this.elContainer1.Controls.Add(this.txttime);
            this.elContainer1.Controls.Add(this.txtmainMoney);
            this.elContainer1.Controls.Add(this.txtspace);
            this.elContainer1.Controls.Add(this.txtrate);
            this.elContainer1.Location = new System.Drawing.Point(6, 49);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(465, 98);
            this.elContainer1.TabIndex = 0;
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.rdoRas);
            this.elContainer2.Controls.Add(this.rdoAghsat);
            this.elContainer2.Location = new System.Drawing.Point(6, 6);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(465, 41);
            this.elContainer2.TabIndex = 1;
            // 
            // elContainer3
            // 
            this.elContainer3.Controls.Add(this.txtavail);
            this.elContainer3.Controls.Add(this.txtbackmoney);
            this.elContainer3.Location = new System.Drawing.Point(6, 150);
            this.elContainer3.Name = "elContainer3";
            this.elContainer3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer3.Size = new System.Drawing.Size(465, 41);
            this.elContainer3.TabIndex = 2;
            // 
            // FrmCal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 230);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer3);
            this.Controls.Add(this.elContainer2);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.btnClose);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmCal";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "محاسبه سود تسهیلات";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmCal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtrate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmainMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtavail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbackmoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoRas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoAghsat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elContainer3)).EndInit();
            this.elContainer3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtrate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmainMoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txttime;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbackmoney;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtavail;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtspace;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmonth;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoRas;
        private Klik.Windows.Forms.v1.EntryLib.ELRadioButton rdoAghsat;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer3;
    }
}