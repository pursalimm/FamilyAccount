﻿namespace FamilyAccount
{
    partial class FrmSetcheq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetcheq));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.backSet = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtcsseries = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcsdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.txtcsend = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcsfirst = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.SetDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectC = new System.Windows.Forms.DataGridViewButtonColumn();
            this.csidS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csseries = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csfirst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csend = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elButton6 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton8 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backSet)).BeginInit();
            this.backSet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsseries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsfirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SetDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // backSet
            // 
            this.backSet.Controls.Add(this.txtcsseries);
            this.backSet.Controls.Add(this.txtaccid);
            this.backSet.Controls.Add(this.txtcsdate);
            this.backSet.Controls.Add(this.txtcsend);
            this.backSet.Controls.Add(this.txtcsfirst);
            this.backSet.Location = new System.Drawing.Point(8, 8);
            this.backSet.Name = "backSet";
            this.backSet.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backSet.Size = new System.Drawing.Size(550, 107);
            this.backSet.TabIndex = 0;
            this.backSet.Tag = "0";
            // 
            // txtcsseries
            // 
            this.txtcsseries.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsseries.CaptionStyle.CaptionSize = 120;
            this.txtcsseries.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsseries.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsseries.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtcsseries.CaptionStyle.TextStyle.Text = "شماره سری/سریال";
            this.txtcsseries.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsseries.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsseries.Location = new System.Drawing.Point(255, 40);
            this.txtcsseries.Name = "txtcsseries";
            this.txtcsseries.Size = new System.Drawing.Size(284, 27);
            this.txtcsseries.TabIndex = 1;
            this.txtcsseries.Tag = "1";
            this.txtcsseries.ValidationStyle.AcceptsTab = true;
            this.txtcsseries.ValidationStyle.PasswordChar = '\0';
            this.txtcsseries.Value = "";
            this.txtcsseries.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcsdate_KeyPress);
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 120;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccid.Location = new System.Drawing.Point(292, 11);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(247, 27);
            this.txtaccid.TabIndex = 0;
            this.txtaccid.Tag = "1";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.ValidationStyle.ReadOnly = true;
            this.txtaccid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtaccid.Value = 0;
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcsdate_KeyPress);
            this.txtaccid.Enter += new System.EventHandler(this.txtaccid_Enter);
            // 
            // txtcsdate
            // 
            this.txtcsdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtcsdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsdate.CaptionStyle.CaptionSize = 120;
            this.txtcsdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsdate.CaptionStyle.TextStyle.Text = "تاریخ دریافت";
            this.txtcsdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcsdate.Location = new System.Drawing.Point(11, 40);
            this.txtcsdate.Name = "txtcsdate";
            this.txtcsdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtcsdate.Size = new System.Drawing.Size(228, 27);
            this.txtcsdate.TabIndex = 2;
            this.txtcsdate.Tag = "1";
            this.txtcsdate.ValidationStyle.AcceptsTab = true;
            this.txtcsdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtcsdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtcsdate.ValidationStyle.PasswordChar = '\0';
            this.txtcsdate.Value = "";
            this.txtcsdate.Leave += new System.EventHandler(this.txtcsdate_Leave);
            this.txtcsdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcsdate_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextMenuStrip1";
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // txtcsend
            // 
            this.txtcsend.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsend.CaptionStyle.CaptionSize = 120;
            this.txtcsend.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsend.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsend.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsend.CaptionStyle.TextStyle.Text = "تا شماره";
            this.txtcsend.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsend.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsend.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcsend.Location = new System.Drawing.Point(26, 69);
            this.txtcsend.Name = "txtcsend";
            this.txtcsend.Size = new System.Drawing.Size(213, 27);
            this.txtcsend.TabIndex = 4;
            this.txtcsend.Tag = "1";
            this.txtcsend.ValidationStyle.AcceptsTab = true;
            this.txtcsend.ValidationStyle.MaskValidationStyle.Mask = "0000000000";
            this.txtcsend.ValidationStyle.PasswordChar = '\0';
            this.txtcsend.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtcsend.Value = "          ";
            this.txtcsend.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcsdate_KeyPress);
            // 
            // txtcsfirst
            // 
            this.txtcsfirst.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcsfirst.CaptionStyle.CaptionSize = 120;
            this.txtcsfirst.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcsfirst.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcsfirst.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsfirst.CaptionStyle.TextStyle.Text = "از شماره";
            this.txtcsfirst.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcsfirst.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcsfirst.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcsfirst.Location = new System.Drawing.Point(326, 69);
            this.txtcsfirst.Name = "txtcsfirst";
            this.txtcsfirst.Size = new System.Drawing.Size(213, 27);
            this.txtcsfirst.TabIndex = 3;
            this.txtcsfirst.Tag = "1";
            this.txtcsfirst.ValidationStyle.AcceptsTab = true;
            this.txtcsfirst.ValidationStyle.MaskValidationStyle.Mask = "0000000000";
            this.txtcsfirst.ValidationStyle.PasswordChar = '\0';
            this.txtcsfirst.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Mask;
            this.txtcsfirst.Value = "          ";
            this.txtcsfirst.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcsdate_KeyPress);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel1.Controls.Add(this.SetDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel1.Location = new System.Drawing.Point(8, 119);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(550, 256);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // SetDataGrid
            // 
            this.SetDataGrid.AllowUserToAddRows = false;
            this.SetDataGrid.AllowUserToDeleteRows = false;
            this.SetDataGrid.AllowUserToResizeColumns = false;
            this.SetDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.SetDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.SetDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SetDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.SetDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.SetDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SetDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.SetDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.SetDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectC,
            this.csidS,
            this.accid,
            this.csseries,
            this.csdate,
            this.csfirst,
            this.csend});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SetDataGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.SetDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SetDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.SetDataGrid.Location = new System.Drawing.Point(1, 16);
            this.SetDataGrid.MultiSelect = false;
            this.SetDataGrid.Name = "SetDataGrid";
            this.SetDataGrid.ReadOnly = true;
            this.SetDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SetDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.SetDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.SetDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.SetDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SetDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.SetDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SetDataGrid.ShowCellErrors = false;
            this.SetDataGrid.ShowCellToolTips = false;
            this.SetDataGrid.ShowEditingIcon = false;
            this.SetDataGrid.ShowRowErrors = false;
            this.SetDataGrid.Size = new System.Drawing.Size(548, 224);
            this.SetDataGrid.TabIndex = 0;
            this.SetDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.SetDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SetDataGrid_MouseClick);
            this.SetDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SetDataGrid_CellClick);
            this.SetDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SetDataGrid_KeyDown);
            // 
            // SelectC
            // 
            this.SelectC.HeaderText = "";
            this.SelectC.Name = "SelectC";
            this.SelectC.ReadOnly = true;
            this.SelectC.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SelectC.Text = "انتخاب";
            this.SelectC.UseColumnTextForButtonValue = true;
            // 
            // csidS
            // 
            this.csidS.DataPropertyName = "csid";
            this.csidS.HeaderText = "کد";
            this.csidS.Name = "csidS";
            this.csidS.ReadOnly = true;
            this.csidS.Visible = false;
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            this.accid.Visible = false;
            // 
            // csseries
            // 
            this.csseries.DataPropertyName = "csseries";
            this.csseries.HeaderText = "شماره سریال";
            this.csseries.Name = "csseries";
            this.csseries.ReadOnly = true;
            // 
            // csdate
            // 
            this.csdate.DataPropertyName = "csdate";
            this.csdate.HeaderText = "تاریخ دریافت";
            this.csdate.Name = "csdate";
            this.csdate.ReadOnly = true;
            // 
            // csfirst
            // 
            this.csfirst.DataPropertyName = "csfirst";
            this.csfirst.HeaderText = "شماره شروع";
            this.csfirst.Name = "csfirst";
            this.csfirst.ReadOnly = true;
            // 
            // csend
            // 
            this.csend.DataPropertyName = "csend";
            this.csend.HeaderText = "شماره پایان";
            this.csend.Name = "csend";
            this.csend.ReadOnly = true;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(90, 7);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(11, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(249, 7);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(408, 7);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(329, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(170, 7);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.elButton6);
            this.elContainer2.Controls.Add(this.btnAbort);
            this.elContainer2.Controls.Add(this.elButton8);
            this.elContainer2.Controls.Add(this.btnClose);
            this.elContainer2.Controls.Add(this.btnEdit);
            this.elContainer2.Controls.Add(this.btnDelete);
            this.elContainer2.Controls.Add(this.btnNew);
            this.elContainer2.Controls.Add(this.btnSave);
            this.elContainer2.Location = new System.Drawing.Point(40, 381);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(489, 41);
            this.elContainer2.TabIndex = 2;
            this.elContainer2.Tag = "0";
            this.elContainer2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // elButton6
            // 
            this.elButton6.Location = new System.Drawing.Point(0, 0);
            this.elButton6.Name = "elButton6";
            this.elButton6.Size = new System.Drawing.Size(0, 0);
            this.elButton6.TabIndex = 5;
            // 
            // elButton8
            // 
            this.elButton8.Location = new System.Drawing.Point(0, 0);
            this.elButton8.Name = "elButton8";
            this.elButton8.Size = new System.Drawing.Size(0, 0);
            this.elButton8.TabIndex = 5;
            // 
            // FrmSetcheq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 429);
            this.ControlBox = false;
            this.Controls.Add(this.elContainer2);
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.backSet);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmSetcheq";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "دسته چکها";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmSetcheq_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backSet)).EndInit();
            this.backSet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtcsseries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtcsend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcsfirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SetDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backSet;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsend;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsfirst;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView SetDataGrid;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton6;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton8;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcsseries;
        private System.Windows.Forms.DataGridViewButtonColumn SelectC;
        private System.Windows.Forms.DataGridViewTextBoxColumn csidS;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewTextBoxColumn csseries;
        private System.Windows.Forms.DataGridViewTextBoxColumn csdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn csfirst;
        private System.Windows.Forms.DataGridViewTextBoxColumn csend;
    }
}