﻿namespace FamilyAccount
{
    partial class FrmPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles elListBoxSelectionStyles1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxSelectionStyles();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem1 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem2 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            Klik.Windows.Forms.v1.EntryLib.ELListBoxItem elListBoxItem3 = new Klik.Windows.Forms.v1.EntryLib.ELListBoxItem();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPayment));
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtpayquan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.lblLoan = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.btnIns = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.cbosetstate = new Klik.Windows.Forms.v1.EntryLib.ELComboBox();
            this.txtsetdelay = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsetwage = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsetnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtdateusan = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtdatepay = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.elRichPanel1 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.payDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.SelectPay = new System.Windows.Forms.DataGridViewButtonColumn();
            this.idpay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateusan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payquan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datepay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.memid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setwage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setdelay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setstate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.setnote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.familyTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtpayquan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbosetstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetdelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetwage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdateusan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdatepay)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).BeginInit();
            this.elRichPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.payDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            this.SuspendLayout();
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.MainContainer = this;
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.txtpayquan);
            this.backContainer.Controls.Add(this.lblLoan);
            this.backContainer.Controls.Add(this.btnIns);
            this.backContainer.Controls.Add(this.txtmemid);
            this.backContainer.Controls.Add(this.cbosetstate);
            this.backContainer.Controls.Add(this.txtsetdelay);
            this.backContainer.Controls.Add(this.txtsetwage);
            this.backContainer.Controls.Add(this.txtsetnote);
            this.backContainer.Controls.Add(this.txtdateusan);
            this.backContainer.Controls.Add(this.txtdatepay);
            this.backContainer.Location = new System.Drawing.Point(7, 8);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(758, 162);
            this.backContainer.TabIndex = 0;
            // 
            // txtpayquan
            // 
            this.txtpayquan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtpayquan.CaptionStyle.CaptionSize = 100;
            this.txtpayquan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtpayquan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtpayquan.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayquan.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayquan.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtpayquan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayquan.CaptionStyle.TextStyle.Text = "مبلغ قسط";
            this.txtpayquan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpayquan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtpayquan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpayquan.Location = new System.Drawing.Point(8, 69);
            this.txtpayquan.Name = "txtpayquan";
            this.txtpayquan.Size = new System.Drawing.Size(222, 27);
            this.txtpayquan.TabIndex = 5;
            this.txtpayquan.Tag = "1";
            this.txtpayquan.ValidationStyle.AcceptsTab = true;
            this.txtpayquan.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtpayquan.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtpayquan.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtpayquan.ValidationStyle.PasswordChar = '\0';
            this.txtpayquan.ValidationStyle.ReadOnly = true;
            this.txtpayquan.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtpayquan.Value = 0;
            this.txtpayquan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // lblLoan
            // 
            this.lblLoan.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblLoan.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblLoan.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblLoan.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblLoan.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblLoan.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle1.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.Transparent;
            this.lblLoan.FlashStyle = paintStyle1;
            this.lblLoan.Location = new System.Drawing.Point(8, 11);
            this.lblLoan.Name = "lblLoan";
            this.lblLoan.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblLoan.Size = new System.Drawing.Size(743, 25);
            this.lblLoan.TabIndex = 0;
            this.lblLoan.TabStop = false;
            this.lblLoan.Tag = "0";
            this.lblLoan.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblLoan.TextStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoan.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblLoan.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLoan.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblLoan.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnIns
            // 
            this.btnIns.BackgroundImageStyle.Alpha = 100;
            this.btnIns.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnIns.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Location = new System.Drawing.Point(437, 69);
            this.btnIns.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns.Name = "btnIns";
            this.btnIns.Size = new System.Drawing.Size(28, 27);
            this.btnIns.TabIndex = 4;
            this.btnIns.Tag = "0";
            this.btnIns.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns.Click += new System.EventHandler(this.btnIns_Click);
            this.btnIns.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtmemid
            // 
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemid.CaptionStyle.CaptionSize = 95;
            this.txtmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemid.CaptionStyle.TextStyle.Text = "واریزکننده قسط";
            this.txtmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemid.Location = new System.Drawing.Point(466, 69);
            this.txtmemid.Name = "txtmemid";
            this.txtmemid.Size = new System.Drawing.Size(284, 27);
            this.txtmemid.TabIndex = 3;
            this.txtmemid.Tag = "1";
            this.txtmemid.ValidationStyle.AcceptsTab = true;
            this.txtmemid.ValidationStyle.PasswordChar = '\0';
            this.txtmemid.ValidationStyle.ReadOnly = true;
            this.txtmemid.Value = "";
            this.txtmemid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            this.txtmemid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // cbosetstate
            // 
            // 
            // 
            // 
            this.cbosetstate.ButtonStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.ButtonStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.ButtonStyle.StateStyles.PressedStyle.TextFont = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.ButtonStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.cbosetstate.CaptionStyle.CaptionSize = 100;
            this.cbosetstate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosetstate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.cbosetstate.CaptionStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosetstate.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosetstate.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosetstate.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.cbosetstate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosetstate.CaptionStyle.TextStyle.Text = "وضعیت پرداخت";
            this.cbosetstate.CheckedDisplaySeparator = ',';
            this.cbosetstate.DropDownBackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbosetstate.DropDownBackgroundStyle.GradientAngle = 45F;
            this.cbosetstate.DropDownBackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.cbosetstate.DropDownBackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.cbosetstate.DropDownDescriptionFont = new System.Drawing.Font("Tahoma", 9F);
            elListBoxSelectionStyles1.HotTrackStyle.BorderStyle.EdgeRadius = 4;
            elListBoxSelectionStyles1.SelectedStyle.BorderStyle.EdgeRadius = 4;
            this.cbosetstate.DropDownItemSelectionStyle = elListBoxSelectionStyles1;
            this.cbosetstate.DropDownStyle = Klik.Windows.Forms.v1.EntryLib.DropDownStyles.DropDownList;
            this.cbosetstate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbosetstate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.cbosetstate.EditBoxStyle.StateStyles.DisabledStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.EditBoxStyle.StateStyles.FocusStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.EditBoxStyle.StateStyles.HoverStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.cbosetstate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            elListBoxItem1.Key = "0";
            elListBoxItem1.Value = "انتظار";
            elListBoxItem2.Key = "1";
            elListBoxItem2.Value = "پرداخت";
            elListBoxItem3.Key = "2";
            elListBoxItem3.Value = "پرداخت با تاخیر";
            this.cbosetstate.Items.Add(elListBoxItem1);
            this.cbosetstate.Items.Add(elListBoxItem2);
            this.cbosetstate.Items.Add(elListBoxItem3);
            this.cbosetstate.Location = new System.Drawing.Point(8, 127);
            this.cbosetstate.Name = "cbosetstate";
            this.cbosetstate.Size = new System.Drawing.Size(222, 27);
            this.cbosetstate.TabIndex = 9;
            this.cbosetstate.Tag = "1";
            this.cbosetstate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtsetdelay
            // 
            this.txtsetdelay.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsetdelay.CaptionStyle.CaptionSize = 100;
            this.txtsetdelay.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsetdelay.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsetdelay.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetdelay.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetdelay.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetdelay.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetdelay.CaptionStyle.TextStyle.Text = "جریمه تاخیر";
            this.txtsetdelay.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetdelay.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsetdelay.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsetdelay.Location = new System.Drawing.Point(40, 98);
            this.txtsetdelay.Name = "txtsetdelay";
            this.txtsetdelay.Size = new System.Drawing.Size(190, 27);
            this.txtsetdelay.TabIndex = 7;
            this.txtsetdelay.Tag = "0";
            this.txtsetdelay.ValidationStyle.AcceptsTab = true;
            this.txtsetdelay.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsetdelay.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsetdelay.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtsetdelay.ValidationStyle.PasswordChar = '\0';
            this.txtsetdelay.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsetdelay.Value = 0;
            this.txtsetdelay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtsetwage
            // 
            this.txtsetwage.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsetwage.CaptionStyle.CaptionSize = 100;
            this.txtsetwage.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsetwage.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsetwage.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetwage.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetwage.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetwage.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetwage.CaptionStyle.TextStyle.Text = "کارمزد دوره";
            this.txtsetwage.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetwage.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsetwage.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsetwage.Location = new System.Drawing.Point(544, 98);
            this.txtsetwage.Name = "txtsetwage";
            this.txtsetwage.Size = new System.Drawing.Size(206, 27);
            this.txtsetwage.TabIndex = 6;
            this.txtsetwage.Tag = "0";
            this.txtsetwage.ValidationStyle.AcceptsTab = true;
            this.txtsetwage.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtsetwage.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtsetwage.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtsetwage.ValidationStyle.PasswordChar = '\0';
            this.txtsetwage.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtsetwage.Value = 0;
            this.txtsetwage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtsetnote
            // 
            this.txtsetnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsetnote.CaptionStyle.CaptionSize = 100;
            this.txtsetnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsetnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsetnote.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetnote.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetnote.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtsetnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetnote.CaptionStyle.TextStyle.Text = "شرح قسط";
            this.txtsetnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsetnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsetnote.Location = new System.Drawing.Point(286, 127);
            this.txtsetnote.Name = "txtsetnote";
            this.txtsetnote.Size = new System.Drawing.Size(464, 27);
            this.txtsetnote.TabIndex = 8;
            this.txtsetnote.Tag = "0";
            this.txtsetnote.ValidationStyle.AcceptsTab = true;
            this.txtsetnote.ValidationStyle.Multiline = true;
            this.txtsetnote.ValidationStyle.PasswordChar = '\0';
            this.txtsetnote.Value = "";
            this.txtsetnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtdateusan
            // 
            this.txtdateusan.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtdateusan.CaptionStyle.CaptionSize = 100;
            this.txtdateusan.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtdateusan.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtdateusan.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdateusan.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdateusan.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdateusan.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateusan.CaptionStyle.TextStyle.Text = "تاریخ سررسید";
            this.txtdateusan.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateusan.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtdateusan.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtdateusan.Location = new System.Drawing.Point(561, 40);
            this.txtdateusan.Name = "txtdateusan";
            this.txtdateusan.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtdateusan.Size = new System.Drawing.Size(189, 27);
            this.txtdateusan.TabIndex = 1;
            this.txtdateusan.Tag = "1";
            this.txtdateusan.ValidationStyle.AcceptsTab = true;
            this.txtdateusan.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtdateusan.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtdateusan.ValidationStyle.PasswordChar = '\0';
            this.txtdateusan.ValidationStyle.ReadOnly = true;
            this.txtdateusan.Value = "";
            this.txtdateusan.Leave += new System.EventHandler(this.txtdateusan_Leave);
            this.txtdateusan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // txtdatepay
            // 
            this.txtdatepay.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtdatepay.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtdatepay.CaptionStyle.CaptionSize = 100;
            this.txtdatepay.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtdatepay.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtdatepay.CaptionStyle.StateStyles.DisabledStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdatepay.CaptionStyle.StateStyles.FocusStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdatepay.CaptionStyle.StateStyles.HoverStyle.TextFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtdatepay.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdatepay.CaptionStyle.TextStyle.Text = "تاریخ پرداخت";
            this.txtdatepay.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdatepay.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtdatepay.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdatepay.Location = new System.Drawing.Point(24, 40);
            this.txtdatepay.Name = "txtdatepay";
            this.txtdatepay.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtdatepay.Size = new System.Drawing.Size(206, 27);
            this.txtdatepay.TabIndex = 2;
            this.txtdatepay.Tag = "1";
            this.txtdatepay.ValidationStyle.AcceptsTab = true;
            this.txtdatepay.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtdatepay.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtdatepay.ValidationStyle.PasswordChar = '\0';
            this.txtdatepay.Value = "";
            this.txtdatepay.Leave += new System.EventHandler(this.txtdatepay_Leave);
            this.txtdatepay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtdateusan_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextDate";
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // elRichPanel1
            // 
            this.elRichPanel1.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel1.Controls.Add(this.payDataGrid);
            this.elRichPanel1.Expanded = true;
            this.elRichPanel1.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel1.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel1.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.FooterStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F);
            this.elRichPanel1.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel1.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel1.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel1.Location = new System.Drawing.Point(7, 172);
            this.elRichPanel1.Name = "elRichPanel1";
            this.elRichPanel1.Padding = new System.Windows.Forms.Padding(1, 16, 1, 16);
            this.elRichPanel1.Size = new System.Drawing.Size(758, 330);
            this.elRichPanel1.TabIndex = 1;
            this.elRichPanel1.Tag = "0";
            // 
            // payDataGrid
            // 
            this.payDataGrid.AllowUserToAddRows = false;
            this.payDataGrid.AllowUserToDeleteRows = false;
            this.payDataGrid.AllowUserToResizeColumns = false;
            this.payDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.payDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.payDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.payDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.payDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.payDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.payDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.payDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.payDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectPay,
            this.idpay,
            this.loanid,
            this.dateusan,
            this.payquan,
            this.datepay,
            this.memid,
            this.setwage,
            this.setdelay,
            this.setstate,
            this.setnote});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.payDataGrid.DefaultCellStyle = dataGridViewCellStyle6;
            this.payDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.payDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.payDataGrid.Location = new System.Drawing.Point(1, 16);
            this.payDataGrid.MultiSelect = false;
            this.payDataGrid.Name = "payDataGrid";
            this.payDataGrid.ReadOnly = true;
            this.payDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.payDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.payDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.payDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.payDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.payDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.payDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.payDataGrid.ShowCellErrors = false;
            this.payDataGrid.ShowCellToolTips = false;
            this.payDataGrid.ShowEditingIcon = false;
            this.payDataGrid.ShowRowErrors = false;
            this.payDataGrid.Size = new System.Drawing.Size(756, 298);
            this.payDataGrid.TabIndex = 0;
            this.payDataGrid.Tag = "0";
            this.payDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.payDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.payDataGrid_MouseClick);
            this.payDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.payDataGrid_CellClick);
            this.payDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.payDataGrid_KeyDown);
            // 
            // SelectPay
            // 
            this.SelectPay.HeaderText = "";
            this.SelectPay.Name = "SelectPay";
            this.SelectPay.ReadOnly = true;
            this.SelectPay.Text = "انتخاب";
            this.SelectPay.UseColumnTextForButtonValue = true;
            // 
            // idpay
            // 
            this.idpay.DataPropertyName = "idpay";
            this.idpay.HeaderText = "کد";
            this.idpay.Name = "idpay";
            this.idpay.ReadOnly = true;
            this.idpay.Visible = false;
            // 
            // loanid
            // 
            this.loanid.DataPropertyName = "loanid";
            this.loanid.HeaderText = "کد تسهیلات";
            this.loanid.Name = "loanid";
            this.loanid.ReadOnly = true;
            this.loanid.Visible = false;
            // 
            // dateusan
            // 
            this.dateusan.DataPropertyName = "dateusan";
            this.dateusan.HeaderText = "تاریخ سررسید";
            this.dateusan.Name = "dateusan";
            this.dateusan.ReadOnly = true;
            // 
            // payquan
            // 
            this.payquan.DataPropertyName = "payquan";
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = null;
            this.payquan.DefaultCellStyle = dataGridViewCellStyle3;
            this.payquan.HeaderText = "مبلغ قسط";
            this.payquan.Name = "payquan";
            this.payquan.ReadOnly = true;
            // 
            // datepay
            // 
            this.datepay.DataPropertyName = "datepay";
            this.datepay.HeaderText = "تاریخ پرداخت";
            this.datepay.Name = "datepay";
            this.datepay.ReadOnly = true;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.HeaderText = "واریزکننده";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.memid.Visible = false;
            // 
            // setwage
            // 
            this.setwage.DataPropertyName = "setwage";
            dataGridViewCellStyle4.Format = "C0";
            dataGridViewCellStyle4.NullValue = null;
            this.setwage.DefaultCellStyle = dataGridViewCellStyle4;
            this.setwage.HeaderText = "کارمزد دوره";
            this.setwage.Name = "setwage";
            this.setwage.ReadOnly = true;
            // 
            // setdelay
            // 
            this.setdelay.DataPropertyName = "setdelay";
            dataGridViewCellStyle5.Format = "C0";
            dataGridViewCellStyle5.NullValue = null;
            this.setdelay.DefaultCellStyle = dataGridViewCellStyle5;
            this.setdelay.HeaderText = "جریمه تاخیر";
            this.setdelay.Name = "setdelay";
            this.setdelay.ReadOnly = true;
            // 
            // setstate
            // 
            this.setstate.DataPropertyName = "setstate";
            this.setstate.HeaderText = "وضعیت قسط";
            this.setstate.Name = "setstate";
            this.setstate.ReadOnly = true;
            // 
            // setnote
            // 
            this.setnote.DataPropertyName = "setnote";
            this.setnote.HeaderText = "شرح قسط";
            this.setnote.Name = "setnote";
            this.setnote.ReadOnly = true;
            this.setnote.Visible = false;
            // 
            // familyBindingSource
            // 
            this.familyBindingSource.DataMember = "family";
            this.familyBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // elContainer1
            // 
            this.elContainer1.Controls.Add(this.btnAbort);
            this.elContainer1.Controls.Add(this.btnClose);
            this.elContainer1.Controls.Add(this.btnEdit);
            this.elContainer1.Controls.Add(this.elButton5);
            this.elContainer1.Controls.Add(this.elButton3);
            this.elContainer1.Location = new System.Drawing.Point(7, 510);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(251, 41);
            this.elContainer1.TabIndex = 2;
            this.elContainer1.Tag = "0";
            this.elContainer1.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 1;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 2;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(171, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 0;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ثبت";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // familyTableAdapter
            // 
            this.familyTableAdapter.ClearBeforeFill = true;
            // 
            // FrmPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 558);
            this.ControlBox = false;
            this.Controls.Add(this.elRichPanel1);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.backContainer);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPayment";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "اقساط تسهیلات بانکی";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmPayment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtpayquan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbosetstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetdelay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetwage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsetnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdateusan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdatepay)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel1)).EndInit();
            this.elRichPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.payDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELComboBox cbosetstate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsetdelay;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsetwage;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsetnote;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtdateusan;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtdatepay;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel1;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView payDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblLoan;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource familyBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter familyTableAdapter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtpayquan;
        private System.Windows.Forms.DataGridViewButtonColumn SelectPay;
        private System.Windows.Forms.DataGridViewTextBoxColumn idpay;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateusan;
        private System.Windows.Forms.DataGridViewTextBoxColumn payquan;
        private System.Windows.Forms.DataGridViewTextBoxColumn datepay;
        private System.Windows.Forms.DataGridViewTextBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn setwage;
        private System.Windows.Forms.DataGridViewTextBoxColumn setdelay;
        private System.Windows.Forms.DataGridViewTextBoxColumn setstate;
        private System.Windows.Forms.DataGridViewTextBoxColumn setnote;
    }
}