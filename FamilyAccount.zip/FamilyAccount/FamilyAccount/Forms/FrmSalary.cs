﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmSalary : Form
    {
        string idSel = "";
        string selectedkeybsid = string.Empty;
        PersianDate pd;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmSalary()
        {
            InitializeComponent();
        }

        public static FrmSalary Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmSalary();
            }
            return aForm;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void faDatePicker_DoubleClick(object sender, EventArgs e)
        {
            FarsiLibrary.Win.Controls.FaMonthViewStrip fmv = (FarsiLibrary.Win.Controls.FaMonthViewStrip)sender;
            pd = PersianDateConverter.ToPersianDate(fmv.FAMonthView.SelectedDateTime.Value);
            ActiveControl.Text = pd.ToString("d");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtbsid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into salary values(@bsid,@saldate,@salnote,@saltotal)";
            cmd.Parameters.Add("@bsid", SqlDbType.Int).Value = selectedkeybsid;
            cmd.Parameters.Add("@saldate", SqlDbType.NVarChar).Value = txtsaldate.Text;
            cmd.Parameters.Add("@salnote", SqlDbType.NText).Value = txtsalnote.Text;
            cmd.Parameters.Add("@saltotal", SqlDbType.Money).Value = txtsaltotal.Value;
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update salary set bsid=@bsid,saldate=@saldate,salnote=@salnote,saltotal=@saltotal where salid=@salid";
            cmd.Parameters.Add("@salid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@bsid", SqlDbType.Int).Value = selectedkeybsid;
            cmd.Parameters.Add("@saldate", SqlDbType.NVarChar).Value = txtsaldate.Text;
            cmd.Parameters.Add("@salnote", SqlDbType.NText).Value = txtsalnote.Text;
            cmd.Parameters.Add("@saltotal", SqlDbType.Money).Value = txtsaltotal.Value;
            if (ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from salary where salid=@salid";
            cmd.Parameters.Add("@salid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void FrmSalary_Load(object sender, EventArgs e)
        {
            basesalTableAdapter.Fill(accountDataSet.basesal);
            GridRefresh();
            ado.SetFarsiLanguage();
            btnAbort_Click(sender, e);
        }

        private void txtsalid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("SELECT salid, bsid, saldate, salnote, saltotal from salary");
            salaryDataGrid.DataSource = ds.Tables[0];
            if (salaryDataGrid.RowCount > 0)
            {
                double sum = 0;
                foreach (DataGridViewRow row in salaryDataGrid.Rows)
                    sum += Convert.ToDouble(row.Cells["saltotal"].Value);
                lblsum.Text = sum.ToString("C0");
            }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
            lblSaltotal.Text = "";
        }

        private void salaryDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (salaryDataGrid.RowCount > 0)
            {
                if (salaryDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void SelectedData()
        {
            idSel = salaryDataGrid["salid", salaryDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeybsid = salaryDataGrid["bsid", salaryDataGrid.CurrentRow.Index].Value.ToString();
            txtbsid.Text = salaryDataGrid["bsid", salaryDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtsaldate.Text = salaryDataGrid["saldate", salaryDataGrid.CurrentRow.Index].Value.ToString();
            txtsalnote.Text = salaryDataGrid["salnote", salaryDataGrid.CurrentRow.Index].Value.ToString();
            txtsaltotal.Text = salaryDataGrid["saltotal", salaryDataGrid.CurrentRow.Index].Value.ToString();
        }

        private void salaryDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && salaryDataGrid.RowCount > 0)
            {
                SelectedData();
                if (salaryDataGrid.CurrentRow.Index == 0)
                    salaryDataGrid[0, 0].Selected = true;
                else
                    salaryDataGrid[0, salaryDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void salaryDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && salaryDataGrid.RowCount > 0)
                SelectedData();
        }

        private void txtsaldate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtsaldate);
        }

        private void txtsaltotal_TextChanged(object sender, EventArgs e)
        {
            if (txtsaltotal.Text.ToString() != "")
            {
                if (ado.ExtractNumbers(txtsaltotal.Text) == null) return;
                if (ado.ExtractNumbers(txtsaltotal.Text).Length == 13)  ProcessTabKey(true);
                lblSaltotal.Text = FarsiLibrary.Utils.ToWords.ToString(long.Parse(ado.ExtractNumbers(txtsaltotal.Text))) + " ریال";
            }
            else
                lblSaltotal.Text = "";
        }


        private void txtsaltotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
            if (!((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) && e.KeyChar != 8)
                e.KeyChar = char.MinValue;
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select * from basesal");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select * from basesal");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeybsid = dgvr.Cells[0].Value.ToString();
                txtbsid.Text = dgvr.Cells[1].Value.ToString();
                txtbsidS.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtbsid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string query = "SELECT sa.salid, sa.bsid, sa.saldate, sa.salnote, sa.saltotal FROM salary AS sa INNER JOIN basesal AS bs ON sa.bsid = bs.bsid WHERE (sa.salid <> 0) ";
            if (txtbsidS.Text.Trim().Length != 0)
                query += "AND bs.salname like (N'%" + txtbsidS.Text + "%')";
            if (txtsalnoteS.Text.Trim().Length != 0)
                query += "AND sa.salnote like (N'%" + txtsalnoteS.Text + "%')";
            if (txtstartdate.Text.Trim().Length != 0 && txtenddate.Text.Trim().Length != 0)
                query += "AND sa.saldate between '" + txtstartdate.Text + "' AND '" + txtenddate.Text + "'";
            else if (txtstartdate.Text.Trim().Length != 0)
                query += "AND sa.saldate > '" + txtstartdate.Text + "'";
            else if (txtenddate.Text.Trim().Length != 0)
                query += "AND sa.saldate < '" + txtenddate.Text + "'";

            if (txtsalmin.Value.ToString() != "0" && txtsalmax.Value.ToString() != "0")
                query += "AND saltotal between " + txtsalmin.Value.ToString() + " and " + txtsalmax.Value.ToString();
            else if (txtsalmin.Value.ToString() != "0")
                query += "AND saltotal > " + txtsalmin.Value.ToString();
            else if (txtsalmax.Value.ToString() != "0")
                query += "AND saltotal < " + txtsalmax.Value.ToString();

            DataSet ds = ado.select(query);
            salaryDataGrid.DataSource = ds.Tables[0];
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("SELECT sa.salid, sa.bsid, sa.saldate, sa.salnote, sa.saltotal FROM salary AS sa INNER JOIN basesal AS bs ON sa.bsid = bs.bsid WHERE (sa.salid <> 0)");
            salaryDataGrid.DataSource = ds.Tables[0];
            ado.ClearControl(BackSearch);
        }

        private void txtstartdate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtstartdate);
        }

        private void txtenddate_Leave(object sender, EventArgs e)
        {
            ado.DateValidation(txtenddate);
        }

        private void expandPanel_ExpandedChanged(object sender, DevComponents.DotNetBar.ExpandedChangeEventArgs e)
        {
            ado.ClearControl(backContainer);
            ado.ClearControl(BackSearch);
        }
    }
}
