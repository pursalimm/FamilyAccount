﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;

namespace FamilyAccount
{
    public partial class FrmPrompt : Form
    {
        ClassDB ado = new ClassDB();
        PersianDate pd = PersianDateConverter.ToPersianDate(DateTime.Now);
        public FrmPrompt()
        {
            InitializeComponent();
        }

        public static FrmPrompt Instance()
        {
            if (aForm == null)
            {
                aForm = new FrmPrompt();
            }
            return aForm;
        }

        public void EventPrompt()
        {
            DataSet ds = ado.select("SELECT no.nid, ba.actname, no.startdate, no.time, no.note FROM notation AS no INNER JOIN baseact AS ba ON no.baid = ba.baid");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (ado.DateDiff(ds.Tables[0].Rows[i]["startdate"].ToString(), pd.ToString("d")) == 0)
                    lstCur.Items.Add(ds.Tables[0].Rows[i]["actname"].ToString() + " در تاریخ " + ds.Tables[0].Rows[i]["startdate"].ToString() + " ساعت " + ds.Tables[0].Rows[i]["time"].ToString() + " - " + ds.Tables[0].Rows[i]["note"].ToString());
                if (ado.DateDiff(ds.Tables[0].Rows[i]["startdate"].ToString(), pd.ToString("d")) == -Properties.Settings.Default.EventTime)
                    lstNext.Items.Add(ds.Tables[0].Rows[i]["actname"].ToString() + " در تاریخ " + ds.Tables[0].Rows[i]["startdate"].ToString() + " ساعت " + ds.Tables[0].Rows[i]["time"].ToString() + " - " + ds.Tables[0].Rows[i]["note"].ToString());
            }
            ds = ado.select("SELECT cheqid, cheqtype, accid, cheqdate, cheqquan, inmode, cheqstate FROM cheq WHERE (cheqstate = 'انتظار')");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (ado.DateDiff(ds.Tables[0].Rows[i]["cheqdate"].ToString(), pd.ToString("d")) == 0)
                    lstCur.Items.Add("چک " + ds.Tables[0].Rows[i]["cheqtype"].ToString() + " در وجه " + ds.Tables[0].Rows[i]["inmode"].ToString() + " به شماره " + ds.Tables[0].Rows[i]["cheqid"].ToString() + " -شماره حساب " + ds.Tables[0].Rows[i]["accid"].ToString() + " -مبلغ " + ds.Tables[0].Rows[i]["cheqquan"].ToString().Substring(0, ds.Tables[0].Rows[i]["cheqquan"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["cheqdate"].ToString());
                if (ado.DateDiff(ds.Tables[0].Rows[i]["cheqdate"].ToString(), pd.ToString("d")) == -Properties.Settings.Default.EventTime)
                    lstNext.Items.Add("چک " + ds.Tables[0].Rows[i]["cheqtype"].ToString() + " در وجه " + ds.Tables[0].Rows[i]["inmode"].ToString() + " به شماره " + ds.Tables[0].Rows[i]["cheqid"].ToString() + " -شماره حساب " + ds.Tables[0].Rows[i]["accid"].ToString() + " -مبلغ " + ds.Tables[0].Rows[i]["cheqquan"].ToString().Substring(0, ds.Tables[0].Rows[i]["cheqquan"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["cheqdate"].ToString());
            }
            ds = ado.select("SELECT fa.name, lo.accid, lo.loantype, lo.loanback, lo.loanbackdate FROM loan AS lo INNER JOIN family AS fa ON lo.memid = fa.memid WHERE (lo.loanbacktype = 'راس مدت')");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (ado.DateDiff(ds.Tables[0].Rows[i]["loanbackdate"].ToString(), pd.ToString("d")) == 0)
                    lstCur.Items.Add("تسهیلات " + ds.Tables[0].Rows[i]["loantype"].ToString() + " به نام " + ds.Tables[0].Rows[i]["name"].ToString() + " -شماره حساب " + ds.Tables[0].Rows[i]["accid"].ToString() + " به مبلغ " + ds.Tables[0].Rows[i]["loanback"].ToString().Substring(0, ds.Tables[0].Rows[i]["loanback"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["loanbackdate"].ToString());
                if (ado.DateDiff(ds.Tables[0].Rows[i]["loanbackdate"].ToString(), pd.ToString("d")) == -Properties.Settings.Default.EventTime)
                    lstNext.Items.Add("تسهیلات " + ds.Tables[0].Rows[i]["loantype"].ToString() + " به نام " + ds.Tables[0].Rows[i]["name"].ToString() + " -شماره حساب " + ds.Tables[0].Rows[i]["accid"].ToString() + " به مبلغ " + ds.Tables[0].Rows[i]["loanback"].ToString().Substring(0, ds.Tables[0].Rows[i]["loanback"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["loanbackdate"].ToString());
            }
            ds = ado.select("SELECT ps.loanid, ps.dateusan, ps.payquan, ps.setstate FROM pay_settle AS ps INNER JOIN loan AS lo ON ps.loanid = lo.loanid WHERE (ps.setstate = 'انتظار')");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                if (ado.DateDiff(ds.Tables[0].Rows[i]["dateusan"].ToString(), pd.ToString("d")) == 0)
                    lstCur.Items.Add("اقساط تسهیلات شماره " + ds.Tables[0].Rows[i]["loanid"].ToString() + " به مبلغ " + ds.Tables[0].Rows[i]["payquan"].ToString().Substring(0, ds.Tables[0].Rows[i]["payquan"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["dateusan"].ToString());
                if (ado.DateDiff(ds.Tables[0].Rows[i]["dateusan"].ToString(), pd.ToString("d")) == -Properties.Settings.Default.EventTime)
                    lstNext.Items.Add("اقساط تسهیلات شماره " + ds.Tables[0].Rows[i]["loanid"].ToString() + " به مبلغ " + ds.Tables[0].Rows[i]["payquan"].ToString().Substring(0, ds.Tables[0].Rows[i]["payquan"].ToString().Length - 5) + " ریال به تاریخ " + ds.Tables[0].Rows[i]["dateusan"].ToString());
            }
        }

        private void FrmPrompt_Load(object sender, EventArgs e)
        {
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 550, Screen.PrimaryScreen.WorkingArea.Height - 150);
            EventPrompt();
        }

        private void lstCur_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCur.SelectedItem != null)
                MessageBox.Show(lstCur.SelectedItem.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void lstNext_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstNext.SelectedItem != null)
                MessageBox.Show(lstNext.SelectedItem.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void rdoCur_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoCur.Checked == true)
                lstCur.BringToFront();
        }

        private void rdoNext_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoNext.Checked == true)
                lstNext.BringToFront();
        }

        private void lblClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
