﻿namespace FamilyAccount
{
    partial class FrmAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private static FrmAccount aForm = null;
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            aForm = null;
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAccount));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            this.elContainer1 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.elRichPanel2 = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.accDataGrid = new Klik.Windows.Forms.v1.EntryLib.ELDataGridView();
            this.Select = new System.Windows.Forms.DataGridViewButtonColumn();
            this.memid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.familyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accountDataSet = new FamilyAccount.AccountDataSet();
            this.accid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bankid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.store = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.baid = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.baseaccBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accnote = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.availrate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accuser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accpass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.secureid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnOptbank = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnAccCard = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.backContainer = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnIns2 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnIns3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnIns1 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtavailrate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.lblStore = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.txtbankid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbaid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmemid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.grpAccInternet = new Klik.Windows.Forms.v1.EntryLib.ELGroupBox();
            this.txtaccuser = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccpass = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsecureid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccnote = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtcustid = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton2 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.contextDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.faDatePicker = new FarsiLibrary.Win.Controls.FaMonthViewStrip();
            this.txtstore = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnCheque = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elContainer2 = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.btnAbort = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnClose = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnEdit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton5 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnDelete = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.elButton3 = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnSave = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnNew = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.familyTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter();
            this.baseaccTableAdapter = new FamilyAccount.AccountDataSetTableAdapters.baseaccTableAdapter();
            this.expandPanel = new DevComponents.DotNetBar.ExpandablePanel();
            this.BackSearch = new Klik.Windows.Forms.v1.EntryLib.ELContainer();
            this.txtenddate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.elEntryBoxButton1 = new Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton();
            this.txtstartdate = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstoremax = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtstoremin = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnInsBankid = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtbankS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtbaidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtaccidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtmemidS = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.btnReset = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnFilter = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.lblsum = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).BeginInit();
            this.elContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).BeginInit();
            this.elRichPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.accDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseaccBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOptbank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAccCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).BeginInit();
            this.backContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtavailrate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblStore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpAccInternet)).BeginInit();
            this.grpAccInternet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccuser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecureid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcustid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccdate)).BeginInit();
            this.contextDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtstore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCheque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).BeginInit();
            this.elContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.expandPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).BeginInit();
            this.BackSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsBankid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).BeginInit();
            this.SuspendLayout();
            // 
            // elContainer1
            // 
            this.elContainer1.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.elContainer1.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.elContainer1.Controls.Add(this.elRichPanel2);
            this.elContainer1.Controls.Add(this.btnOptbank);
            this.elContainer1.Controls.Add(this.btnAccCard);
            this.elContainer1.Controls.Add(this.backContainer);
            this.elContainer1.Controls.Add(this.btnCheque);
            this.elContainer1.Location = new System.Drawing.Point(7, 33);
            this.elContainer1.Name = "elContainer1";
            this.elContainer1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer1.Size = new System.Drawing.Size(785, 481);
            this.elContainer1.TabIndex = 0;
            this.elContainer1.Tag = "0";
            // 
            // elRichPanel2
            // 
            this.elRichPanel2.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.ContainerStyle.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            this.elRichPanel2.Controls.Add(this.lblsum);
            this.elRichPanel2.Controls.Add(this.label1);
            this.elRichPanel2.Controls.Add(this.accDataGrid);
            this.elRichPanel2.Expanded = true;
            this.elRichPanel2.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.elRichPanel2.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.elRichPanel2.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.FooterStyle.Height = 24;
            this.elRichPanel2.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.elRichPanel2.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.elRichPanel2.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elRichPanel2.Location = new System.Drawing.Point(7, 229);
            this.elRichPanel2.Name = "elRichPanel2";
            this.elRichPanel2.Padding = new System.Windows.Forms.Padding(1, 16, 1, 24);
            this.elRichPanel2.Size = new System.Drawing.Size(771, 245);
            this.elRichPanel2.TabIndex = 7;
            this.elRichPanel2.Tag = "0";
            // 
            // accDataGrid
            // 
            this.accDataGrid.AllowUserToAddRows = false;
            this.accDataGrid.AllowUserToDeleteRows = false;
            this.accDataGrid.AllowUserToResizeColumns = false;
            this.accDataGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.accDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.accDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.accDataGrid.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.accDataGrid.BackgroundStyle.SolidColor = System.Drawing.SystemColors.Window;
            this.accDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.accDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.accDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.accDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.memid,
            this.accid,
            this.custid,
            this.accdate,
            this.bankid,
            this.store,
            this.baid,
            this.accnote,
            this.availrate,
            this.accuser,
            this.accpass,
            this.secureid});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.accDataGrid.DefaultCellStyle = dataGridViewCellStyle10;
            this.accDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.accDataGrid.GridColor = System.Drawing.Color.LightGray;
            this.accDataGrid.Location = new System.Drawing.Point(1, 16);
            this.accDataGrid.MultiSelect = false;
            this.accDataGrid.Name = "accDataGrid";
            this.accDataGrid.ReadOnly = true;
            this.accDataGrid.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.accDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.accDataGrid.RowHeadersVisible = false;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.accDataGrid.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.accDataGrid.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.accDataGrid.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.accDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.accDataGrid.ShowCellErrors = false;
            this.accDataGrid.ShowCellToolTips = false;
            this.accDataGrid.ShowEditingIcon = false;
            this.accDataGrid.ShowRowErrors = false;
            this.accDataGrid.Size = new System.Drawing.Size(769, 205);
            this.accDataGrid.TabIndex = 5;
            this.accDataGrid.VisualStyle = Klik.Windows.Forms.v1.EntryLib.DataGridViewVisualStyles.Office2003;
            this.accDataGrid.MouseClick += new System.Windows.Forms.MouseEventHandler(this.accDataGrid_MouseClick);
            this.accDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.accDataGrid_CellClick);
            this.accDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.accDataGrid_KeyDown);
            // 
            // Select
            // 
            this.Select.HeaderText = "";
            this.Select.Name = "Select";
            this.Select.ReadOnly = true;
            this.Select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Select.Text = "انتخاب";
            this.Select.UseColumnTextForButtonValue = true;
            // 
            // memid
            // 
            this.memid.DataPropertyName = "memid";
            this.memid.DataSource = this.familyBindingSource;
            this.memid.DisplayMember = "name";
            this.memid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.memid.HeaderText = "نام صاحب حساب";
            this.memid.Name = "memid";
            this.memid.ReadOnly = true;
            this.memid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.memid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.memid.ValueMember = "memid";
            // 
            // familyBindingSource
            // 
            this.familyBindingSource.DataMember = "family";
            this.familyBindingSource.DataSource = this.accountDataSet;
            // 
            // accountDataSet
            // 
            this.accountDataSet.DataSetName = "AccountDataSet";
            this.accountDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // accid
            // 
            this.accid.DataPropertyName = "accid";
            this.accid.HeaderText = "شماره حساب";
            this.accid.Name = "accid";
            this.accid.ReadOnly = true;
            // 
            // custid
            // 
            this.custid.DataPropertyName = "custid";
            this.custid.HeaderText = "شماره مشتری";
            this.custid.Name = "custid";
            this.custid.ReadOnly = true;
            this.custid.Visible = false;
            // 
            // accdate
            // 
            this.accdate.DataPropertyName = "accdate";
            this.accdate.HeaderText = "تاریخ افتتاح حساب";
            this.accdate.Name = "accdate";
            this.accdate.ReadOnly = true;
            // 
            // bankid
            // 
            this.bankid.DataPropertyName = "bankid";
            this.bankid.HeaderText = "بانک";
            this.bankid.Name = "bankid";
            this.bankid.ReadOnly = true;
            this.bankid.Visible = false;
            // 
            // store
            // 
            this.store.DataPropertyName = "store";
            dataGridViewCellStyle9.Format = "C0";
            dataGridViewCellStyle9.NullValue = null;
            this.store.DefaultCellStyle = dataGridViewCellStyle9;
            this.store.HeaderText = "موجودی";
            this.store.Name = "store";
            this.store.ReadOnly = true;
            // 
            // baid
            // 
            this.baid.DataPropertyName = "baid";
            this.baid.DataSource = this.baseaccBindingSource;
            this.baid.DisplayMember = "accname";
            this.baid.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.baid.HeaderText = "نوع حساب";
            this.baid.Name = "baid";
            this.baid.ReadOnly = true;
            this.baid.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.baid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.baid.ValueMember = "baid";
            // 
            // baseaccBindingSource
            // 
            this.baseaccBindingSource.DataMember = "baseacc";
            this.baseaccBindingSource.DataSource = this.accountDataSet;
            // 
            // accnote
            // 
            this.accnote.DataPropertyName = "accnote";
            this.accnote.HeaderText = "شرح حساب";
            this.accnote.Name = "accnote";
            this.accnote.ReadOnly = true;
            this.accnote.Visible = false;
            // 
            // availrate
            // 
            this.availrate.DataPropertyName = "availrate";
            this.availrate.HeaderText = "نرخ سود سپرده";
            this.availrate.Name = "availrate";
            this.availrate.ReadOnly = true;
            this.availrate.Visible = false;
            // 
            // accuser
            // 
            this.accuser.DataPropertyName = "accuser";
            this.accuser.HeaderText = "نام کاربری";
            this.accuser.Name = "accuser";
            this.accuser.ReadOnly = true;
            this.accuser.Visible = false;
            // 
            // accpass
            // 
            this.accpass.DataPropertyName = "accpass";
            this.accpass.HeaderText = "کلمه عبور";
            this.accpass.Name = "accpass";
            this.accpass.ReadOnly = true;
            this.accpass.Visible = false;
            // 
            // secureid
            // 
            this.secureid.DataPropertyName = "secureid";
            this.secureid.HeaderText = "رمز امنیتی";
            this.secureid.Name = "secureid";
            this.secureid.ReadOnly = true;
            this.secureid.Visible = false;
            // 
            // btnOptbank
            // 
            this.btnOptbank.BackgroundImageStyle.Alpha = 100;
            this.btnOptbank.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.btnOptbank.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOptbank.BackgroundImageStyle.ImageSize = new System.Drawing.Size(45, 45);
            this.btnOptbank.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOptbank.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnOptbank.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnOptbank.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOptbank.Location = new System.Drawing.Point(7, 126);
            this.btnOptbank.Name = "btnOptbank";
            this.btnOptbank.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnOptbank.Size = new System.Drawing.Size(113, 53);
            this.btnOptbank.TabIndex = 5;
            this.btnOptbank.Tag = "0";
            this.btnOptbank.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOptbank.TextStyle.Text = "تراکنش بانکی";
            this.btnOptbank.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOptbank.Click += new System.EventHandler(this.btnOptbank_Click);
            // 
            // btnAccCard
            // 
            this.btnAccCard.BackgroundImageStyle.Alpha = 100;
            this.btnAccCard.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.btnAccCard.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAccCard.BackgroundImageStyle.ImageSize = new System.Drawing.Size(45, 45);
            this.btnAccCard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccCard.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAccCard.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAccCard.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAccCard.Location = new System.Drawing.Point(7, 67);
            this.btnAccCard.Name = "btnAccCard";
            this.btnAccCard.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnAccCard.Size = new System.Drawing.Size(113, 53);
            this.btnAccCard.TabIndex = 4;
            this.btnAccCard.Tag = "0";
            this.btnAccCard.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccCard.TextStyle.Text = "کارت اعتباری";
            this.btnAccCard.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAccCard.Click += new System.EventHandler(this.btnAccCard_Click);
            // 
            // backContainer
            // 
            this.backContainer.Controls.Add(this.btnIns2);
            this.backContainer.Controls.Add(this.btnIns3);
            this.backContainer.Controls.Add(this.btnIns1);
            this.backContainer.Controls.Add(this.txtavailrate);
            this.backContainer.Controls.Add(this.lblStore);
            this.backContainer.Controls.Add(this.txtbankid);
            this.backContainer.Controls.Add(this.txtbaid);
            this.backContainer.Controls.Add(this.txtmemid);
            this.backContainer.Controls.Add(this.txtaccid);
            this.backContainer.Controls.Add(this.grpAccInternet);
            this.backContainer.Controls.Add(this.txtaccnote);
            this.backContainer.Controls.Add(this.txtcustid);
            this.backContainer.Controls.Add(this.txtaccdate);
            this.backContainer.Controls.Add(this.txtstore);
            this.backContainer.Location = new System.Drawing.Point(126, 8);
            this.backContainer.Name = "backContainer";
            this.backContainer.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.backContainer.Size = new System.Drawing.Size(652, 217);
            this.backContainer.TabIndex = 1;
            this.backContainer.Tag = "0";
            // 
            // btnIns2
            // 
            this.btnIns2.BackgroundImageStyle.Alpha = 100;
            this.btnIns2.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.btnIns2.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns2.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns2.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns2.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns2.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns2.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.Location = new System.Drawing.Point(280, 64);
            this.btnIns2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns2.Name = "btnIns2";
            this.btnIns2.Size = new System.Drawing.Size(28, 27);
            this.btnIns2.TabIndex = 6;
            this.btnIns2.Tag = "0";
            this.btnIns2.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns2.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns2.Click += new System.EventHandler(this.btnIns2_Click);
            // 
            // btnIns3
            // 
            this.btnIns3.BackgroundImageStyle.Alpha = 100;
            this.btnIns3.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image3")));
            this.btnIns3.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns3.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns3.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns3.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns3.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns3.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns3.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns3.Location = new System.Drawing.Point(20, 64);
            this.btnIns3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns3.Name = "btnIns3";
            this.btnIns3.Size = new System.Drawing.Size(28, 27);
            this.btnIns3.TabIndex = 8;
            this.btnIns3.Tag = "0";
            this.btnIns3.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns3.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns3.Click += new System.EventHandler(this.btnIns3_Click);
            // 
            // btnIns1
            // 
            this.btnIns1.BackgroundImageStyle.Alpha = 100;
            this.btnIns1.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image4")));
            this.btnIns1.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnIns1.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns1.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnIns1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIns1.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnIns1.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnIns1.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.Location = new System.Drawing.Point(330, 8);
            this.btnIns1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnIns1.Name = "btnIns1";
            this.btnIns1.Size = new System.Drawing.Size(28, 27);
            this.btnIns1.TabIndex = 1;
            this.btnIns1.Tag = "0";
            this.btnIns1.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIns1.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIns1.Click += new System.EventHandler(this.btnIns1_Click);
            // 
            // txtavailrate
            // 
            this.txtavailrate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtavailrate.CaptionStyle.CaptionSize = 110;
            this.txtavailrate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtavailrate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtavailrate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtavailrate.CaptionStyle.TextStyle.Text = "نرخ دریافت سود";
            this.txtavailrate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtavailrate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtavailrate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtavailrate.Location = new System.Drawing.Point(75, 92);
            this.txtavailrate.Name = "txtavailrate";
            this.txtavailrate.Size = new System.Drawing.Size(184, 27);
            this.txtavailrate.TabIndex = 10;
            this.txtavailrate.Tag = "0";
            this.txtavailrate.ValidationStyle.AcceptsTab = true;
            this.txtavailrate.ValidationStyle.NumericValidationStyle.DecimalDigits = 2;
            this.txtavailrate.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtavailrate.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Percent;
            this.txtavailrate.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtavailrate.ValidationStyle.PasswordChar = '\0';
            this.txtavailrate.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtavailrate.Value = 0;
            this.txtavailrate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // lblStore
            // 
            this.lblStore.BackgroundStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblStore.BackgroundStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblStore.BackgroundStyle.SolidColor = System.Drawing.Color.Transparent;
            this.lblStore.BorderStyle.GradientEndColor = System.Drawing.Color.Transparent;
            this.lblStore.BorderStyle.GradientStartColor = System.Drawing.Color.Transparent;
            this.lblStore.BorderStyle.SolidColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientEndColor = System.Drawing.Color.Transparent;
            paintStyle2.GradientStartColor = System.Drawing.Color.Transparent;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.Transparent;
            this.lblStore.FlashStyle = paintStyle2;
            this.lblStore.Location = new System.Drawing.Point(8, 121);
            this.lblStore.Name = "lblStore";
            this.lblStore.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlue;
            this.lblStore.Size = new System.Drawing.Size(635, 27);
            this.lblStore.TabIndex = 11;
            this.lblStore.TabStop = false;
            this.lblStore.Tag = "0";
            this.lblStore.TextStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblStore.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStore.TextStyle.ForeColor = System.Drawing.Color.Blue;
            this.lblStore.TransparentStyle.BackColor = System.Drawing.Color.Transparent;
            this.lblStore.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // txtbankid
            // 
            this.txtbankid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbankid.CaptionStyle.CaptionSize = 100;
            this.txtbankid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbankid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbankid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbankid.CaptionStyle.TextStyle.Text = "بانک";
            this.txtbankid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbankid.Location = new System.Drawing.Point(309, 64);
            this.txtbankid.Name = "txtbankid";
            this.txtbankid.Size = new System.Drawing.Size(334, 27);
            this.txtbankid.TabIndex = 5;
            this.txtbankid.Tag = "1";
            this.txtbankid.ValidationStyle.AcceptsTab = true;
            this.txtbankid.ValidationStyle.PasswordChar = '\0';
            this.txtbankid.ValidationStyle.ReadOnly = true;
            this.txtbankid.Value = "";
            this.txtbankid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // txtbaid
            // 
            this.txtbaid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbaid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbaid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbaid.CaptionStyle.CaptionSize = 105;
            this.txtbaid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbaid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbaid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbaid.CaptionStyle.TextStyle.Text = "نوع حساب";
            this.txtbaid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbaid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbaid.Location = new System.Drawing.Point(49, 64);
            this.txtbaid.Name = "txtbaid";
            this.txtbaid.Size = new System.Drawing.Size(210, 27);
            this.txtbaid.TabIndex = 7;
            this.txtbaid.Tag = "1";
            this.txtbaid.ValidationStyle.AcceptsTab = true;
            this.txtbaid.ValidationStyle.PasswordChar = '\0';
            this.txtbaid.ValidationStyle.ReadOnly = true;
            this.txtbaid.Value = "";
            this.txtbaid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            this.txtbaid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // txtmemid
            // 
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtmemid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemid.CaptionStyle.CaptionSize = 100;
            this.txtmemid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemid.CaptionStyle.TextStyle.Text = "نام صاحب حساب";
            this.txtmemid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemid.Location = new System.Drawing.Point(359, 8);
            this.txtmemid.Name = "txtmemid";
            this.txtmemid.Size = new System.Drawing.Size(284, 27);
            this.txtmemid.TabIndex = 0;
            this.txtmemid.Tag = "1";
            this.txtmemid.ValidationStyle.AcceptsTab = true;
            this.txtmemid.ValidationStyle.PasswordChar = '\0';
            this.txtmemid.ValidationStyle.ReadOnly = true;
            this.txtmemid.Value = "";
            this.txtmemid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            this.txtmemid.Enter += new System.EventHandler(this.txtmemid_Enter);
            // 
            // txtaccid
            // 
            this.txtaccid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccid.CaptionStyle.CaptionSize = 110;
            this.txtaccid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccid.Location = new System.Drawing.Point(23, 8);
            this.txtaccid.Name = "txtaccid";
            this.txtaccid.Size = new System.Drawing.Size(236, 27);
            this.txtaccid.TabIndex = 2;
            this.txtaccid.Tag = "1";
            this.txtaccid.ValidationStyle.AcceptsTab = true;
            this.txtaccid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccid.ValidationStyle.PasswordChar = '\0';
            this.txtaccid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtaccid.Value = 0;
            this.txtaccid.Leave += new System.EventHandler(this.txtaccid_Leave);
            this.txtaccid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // grpAccInternet
            // 
            this.grpAccInternet.BackgroundStyle.GradientAngle = 45F;
            this.grpAccInternet.CaptionStyle.Align = System.Drawing.ContentAlignment.BottomLeft;
            this.grpAccInternet.CaptionStyle.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpAccInternet.CaptionStyle.BackgroundStyle.SolidColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpAccInternet.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.grpAccInternet.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.grpAccInternet.CaptionStyle.PositionIndent = new System.Drawing.Point(0, 0);
            this.grpAccInternet.CaptionStyle.Size = new System.Drawing.Size(110, 31);
            this.grpAccInternet.CaptionStyle.TextStyle.BackColor = System.Drawing.SystemColors.ControlText;
            this.grpAccInternet.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAccInternet.CaptionStyle.TextStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.grpAccInternet.CaptionStyle.TextStyle.Text = "حساب اینترنتی";
            this.grpAccInternet.Controls.Add(this.txtaccuser);
            this.grpAccInternet.Controls.Add(this.txtaccpass);
            this.grpAccInternet.Controls.Add(this.txtsecureid);
            this.grpAccInternet.Location = new System.Drawing.Point(8, 178);
            this.grpAccInternet.Name = "grpAccInternet";
            this.grpAccInternet.Padding = new System.Windows.Forms.Padding(4, 34, 4, 3);
            this.grpAccInternet.Size = new System.Drawing.Size(635, 31);
            this.grpAccInternet.TabIndex = 13;
            this.grpAccInternet.Tag = "0";
            // 
            // txtaccuser
            // 
            this.txtaccuser.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccuser.CaptionStyle.CaptionSize = 70;
            this.txtaccuser.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccuser.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccuser.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccuser.CaptionStyle.TextStyle.Text = "نام کاربری";
            this.txtaccuser.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccuser.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccuser.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccuser.Location = new System.Drawing.Point(347, 2);
            this.txtaccuser.Name = "txtaccuser";
            this.txtaccuser.Size = new System.Drawing.Size(166, 27);
            this.txtaccuser.TabIndex = 0;
            this.txtaccuser.Tag = "0";
            this.txtaccuser.ValidationStyle.AcceptsTab = true;
            this.txtaccuser.ValidationStyle.PasswordChar = '\0';
            this.txtaccuser.Value = "";
            this.txtaccuser.Leave += new System.EventHandler(this.txtaccuser_Leave);
            this.txtaccuser.Enter += new System.EventHandler(this.txtaccuser_Enter);
            // 
            // txtaccpass
            // 
            this.txtaccpass.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccpass.CaptionStyle.CaptionSize = 70;
            this.txtaccpass.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccpass.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccpass.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccpass.CaptionStyle.TextStyle.Text = "کلمه عبور";
            this.txtaccpass.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccpass.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccpass.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccpass.Location = new System.Drawing.Point(175, 2);
            this.txtaccpass.Name = "txtaccpass";
            this.txtaccpass.Size = new System.Drawing.Size(166, 27);
            this.txtaccpass.TabIndex = 1;
            this.txtaccpass.Tag = "0";
            this.txtaccpass.ValidationStyle.AcceptsTab = true;
            this.txtaccpass.ValidationStyle.PasswordChar = '\0';
            this.txtaccpass.ValidationStyle.UseSystemPasswordChar = true;
            this.txtaccpass.Value = "";
            this.txtaccpass.Leave += new System.EventHandler(this.txtaccuser_Leave);
            this.txtaccpass.Enter += new System.EventHandler(this.txtaccuser_Enter);
            // 
            // txtsecureid
            // 
            this.txtsecureid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsecureid.CaptionStyle.CaptionSize = 70;
            this.txtsecureid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsecureid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsecureid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsecureid.CaptionStyle.TextStyle.Text = "رمز امنیتی";
            this.txtsecureid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsecureid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsecureid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsecureid.Location = new System.Drawing.Point(3, 2);
            this.txtsecureid.Name = "txtsecureid";
            this.txtsecureid.Size = new System.Drawing.Size(166, 27);
            this.txtsecureid.TabIndex = 2;
            this.txtsecureid.Tag = "0";
            this.txtsecureid.ValidationStyle.AcceptsTab = true;
            this.txtsecureid.ValidationStyle.PasswordChar = '\0';
            this.txtsecureid.ValidationStyle.UseSystemPasswordChar = true;
            this.txtsecureid.Value = "";
            this.txtsecureid.Leave += new System.EventHandler(this.txtaccuser_Leave);
            this.txtsecureid.Enter += new System.EventHandler(this.txtaccuser_Enter);
            // 
            // txtaccnote
            // 
            this.txtaccnote.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccnote.CaptionStyle.CaptionSize = 105;
            this.txtaccnote.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccnote.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccnote.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccnote.CaptionStyle.TextStyle.Text = "توضیحات";
            this.txtaccnote.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccnote.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccnote.Location = new System.Drawing.Point(8, 150);
            this.txtaccnote.Name = "txtaccnote";
            this.txtaccnote.Size = new System.Drawing.Size(635, 27);
            this.txtaccnote.TabIndex = 12;
            this.txtaccnote.Tag = "0";
            this.txtaccnote.ValidationStyle.AcceptsTab = true;
            this.txtaccnote.ValidationStyle.PasswordChar = '\0';
            this.txtaccnote.Value = "";
            this.txtaccnote.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // txtcustid
            // 
            this.txtcustid.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtcustid.CaptionStyle.CaptionSize = 105;
            this.txtcustid.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtcustid.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtcustid.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustid.CaptionStyle.TextStyle.Text = "شماره مشتری";
            this.txtcustid.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustid.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtcustid.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcustid.Location = new System.Drawing.Point(424, 36);
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(220, 27);
            this.txtcustid.TabIndex = 3;
            this.txtcustid.Tag = "0";
            this.txtcustid.ValidationStyle.AcceptsTab = true;
            this.txtcustid.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtcustid.ValidationStyle.PasswordChar = '\0';
            this.txtcustid.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtcustid.Value = 0;
            this.txtcustid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // txtaccdate
            // 
            this.txtaccdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtaccdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccdate.CaptionStyle.CaptionSize = 110;
            this.txtaccdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccdate.CaptionStyle.TextStyle.Text = "تاریخ افتتاح حساب";
            this.txtaccdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccdate.Location = new System.Drawing.Point(49, 36);
            this.txtaccdate.Name = "txtaccdate";
            this.txtaccdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtaccdate.Size = new System.Drawing.Size(210, 27);
            this.txtaccdate.TabIndex = 4;
            this.txtaccdate.Tag = "1";
            this.txtaccdate.ValidationStyle.AcceptsTab = true;
            this.txtaccdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtaccdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtaccdate.ValidationStyle.PasswordChar = '\0';
            this.txtaccdate.Value = "";
            this.txtaccdate.Leave += new System.EventHandler(this.txtaccdate_Leave);
            this.txtaccdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // elEntryBoxButton2
            // 
            this.elEntryBoxButton2.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton2.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton2.DropDownContextMenuStrip = this.contextDate;
            // 
            // contextDate
            // 
            this.contextDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.faDatePicker});
            this.contextDate.Name = "contextDate";
            this.contextDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.contextDate.Size = new System.Drawing.Size(227, 173);
            // 
            // faDatePicker
            // 
            this.faDatePicker.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.faDatePicker.Name = "faDatePicker";
            this.faDatePicker.Size = new System.Drawing.Size(166, 166);
            this.faDatePicker.DoubleClick += new System.EventHandler(this.faDatePicker_DoubleClick);
            // 
            // txtstore
            // 
            this.txtstore.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstore.CaptionStyle.CaptionSize = 105;
            this.txtstore.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstore.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstore.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstore.CaptionStyle.TextStyle.Text = "موجودی";
            this.txtstore.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstore.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstore.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstore.Location = new System.Drawing.Point(402, 92);
            this.txtstore.Name = "txtstore";
            this.txtstore.Size = new System.Drawing.Size(242, 27);
            this.txtstore.TabIndex = 9;
            this.txtstore.Tag = "1";
            this.txtstore.ValidationStyle.AcceptsTab = true;
            this.txtstore.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtstore.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtstore.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtstore.ValidationStyle.PasswordChar = '\0';
            this.txtstore.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtstore.Value = 0;
            this.txtstore.TextChanged += new System.EventHandler(this.txtstore_TextChanged);
            this.txtstore.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstore_KeyPress);
            // 
            // btnCheque
            // 
            this.btnCheque.BackgroundImageStyle.Alpha = 100;
            this.btnCheque.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image5")));
            this.btnCheque.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheque.BackgroundImageStyle.ImageSize = new System.Drawing.Size(45, 45);
            this.btnCheque.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheque.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnCheque.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnCheque.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCheque.Location = new System.Drawing.Point(7, 8);
            this.btnCheque.Name = "btnCheque";
            this.btnCheque.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicBlack;
            this.btnCheque.Size = new System.Drawing.Size(113, 53);
            this.btnCheque.TabIndex = 3;
            this.btnCheque.Tag = "0";
            this.btnCheque.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheque.TextStyle.Text = "دسته چک";
            this.btnCheque.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCheque.Click += new System.EventHandler(this.btnCheque_Click);
            // 
            // elContainer2
            // 
            this.elContainer2.Controls.Add(this.btnAbort);
            this.elContainer2.Controls.Add(this.btnClose);
            this.elContainer2.Controls.Add(this.btnEdit);
            this.elContainer2.Controls.Add(this.elButton5);
            this.elContainer2.Controls.Add(this.btnDelete);
            this.elContainer2.Controls.Add(this.elButton3);
            this.elContainer2.Controls.Add(this.btnSave);
            this.elContainer2.Controls.Add(this.btnNew);
            this.elContainer2.Location = new System.Drawing.Point(156, 521);
            this.elContainer2.Name = "elContainer2";
            this.elContainer2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.elContainer2.Size = new System.Drawing.Size(489, 41);
            this.elContainer2.TabIndex = 2;
            this.elContainer2.Tag = "0";
            this.elContainer2.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // btnAbort
            // 
            this.btnAbort.BackgroundImageStyle.Alpha = 100;
            this.btnAbort.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image6")));
            this.btnAbort.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbort.BackgroundImageStyle.ImageSize = new System.Drawing.Size(23, 23);
            this.btnAbort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbort.Enabled = false;
            this.btnAbort.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnAbort.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnAbort.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbort.Location = new System.Drawing.Point(91, 6);
            this.btnAbort.Name = "btnAbort";
            this.btnAbort.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnAbort.Size = new System.Drawing.Size(69, 27);
            this.btnAbort.TabIndex = 4;
            this.btnAbort.Tag = "Abort";
            this.btnAbort.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbort.TextStyle.Text = "انصراف";
            this.btnAbort.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAbort.Click += new System.EventHandler(this.btnAbort_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImageStyle.Alpha = 100;
            this.btnClose.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image7")));
            this.btnClose.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnClose.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnClose.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClose.Location = new System.Drawing.Point(12, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnClose.Size = new System.Drawing.Size(69, 27);
            this.btnClose.TabIndex = 5;
            this.btnClose.Tag = "Close";
            this.btnClose.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.TextStyle.Text = "بازگشت";
            this.btnClose.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImageStyle.Alpha = 100;
            this.btnEdit.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image8")));
            this.btnEdit.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Enabled = false;
            this.btnEdit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnEdit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnEdit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEdit.Location = new System.Drawing.Point(250, 6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnEdit.Size = new System.Drawing.Size(69, 27);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Tag = "Edit";
            this.btnEdit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.TextStyle.Text = "ویرایش";
            this.btnEdit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // elButton5
            // 
            this.elButton5.Location = new System.Drawing.Point(0, 0);
            this.elButton5.Name = "elButton5";
            this.elButton5.Size = new System.Drawing.Size(0, 0);
            this.elButton5.TabIndex = 5;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageStyle.Alpha = 100;
            this.btnDelete.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image9")));
            this.btnDelete.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnDelete.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnDelete.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDelete.Location = new System.Drawing.Point(171, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnDelete.Size = new System.Drawing.Size(69, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Tag = "Delete";
            this.btnDelete.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.TextStyle.Text = "حذف";
            this.btnDelete.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // elButton3
            // 
            this.elButton3.Location = new System.Drawing.Point(0, 0);
            this.elButton3.Name = "elButton3";
            this.elButton3.Size = new System.Drawing.Size(0, 0);
            this.elButton3.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImageStyle.Alpha = 100;
            this.btnSave.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image10")));
            this.btnSave.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Enabled = false;
            this.btnSave.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnSave.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnSave.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Location = new System.Drawing.Point(330, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnSave.Size = new System.Drawing.Size(69, 27);
            this.btnSave.TabIndex = 1;
            this.btnSave.Tag = "Save";
            this.btnSave.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.TextStyle.Text = "ثبت";
            this.btnSave.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackgroundImageStyle.Alpha = 100;
            this.btnNew.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image11")));
            this.btnNew.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnNew.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnNew.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNew.Location = new System.Drawing.Point(409, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnNew.Size = new System.Drawing.Size(69, 27);
            this.btnNew.TabIndex = 0;
            this.btnNew.Tag = "New";
            this.btnNew.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.TextStyle.Text = "جدید";
            this.btnNew.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.DrawToolStrip = false;
            this.kFormManager1.MainContainer = this;
            // 
            // familyTableAdapter
            // 
            this.familyTableAdapter.ClearBeforeFill = true;
            // 
            // baseaccTableAdapter
            // 
            this.baseaccTableAdapter.ClearBeforeFill = true;
            // 
            // expandPanel
            // 
            this.expandPanel.CanvasColor = System.Drawing.SystemColors.Control;
            this.expandPanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.expandPanel.Controls.Add(this.BackSearch);
            this.expandPanel.Controls.Add(this.btnReset);
            this.expandPanel.Controls.Add(this.btnFilter);
            this.expandPanel.Expanded = false;
            this.expandPanel.ExpandedBounds = new System.Drawing.Rectangle(7, 8, 785, 250);
            this.expandPanel.Location = new System.Drawing.Point(7, 8);
            this.expandPanel.Name = "expandPanel";
            this.expandPanel.Size = new System.Drawing.Size(785, 26);
            this.expandPanel.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.expandPanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.expandPanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.expandPanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.expandPanel.Style.GradientAngle = 90;
            this.expandPanel.TabIndex = 5;
            this.expandPanel.TitleStyle.Alignment = System.Drawing.StringAlignment.Far;
            this.expandPanel.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.expandPanel.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.expandPanel.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.expandPanel.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.expandPanel.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.expandPanel.TitleStyle.GradientAngle = 90;
            this.expandPanel.TitleText = "جستجو";
            this.expandPanel.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.expandPanel_ExpandedChanged);
            // 
            // BackSearch
            // 
            this.BackSearch.Controls.Add(this.txtenddate);
            this.BackSearch.Controls.Add(this.txtstartdate);
            this.BackSearch.Controls.Add(this.txtstoremax);
            this.BackSearch.Controls.Add(this.txtstoremin);
            this.BackSearch.Controls.Add(this.btnInsBankid);
            this.BackSearch.Controls.Add(this.txtbankS);
            this.BackSearch.Controls.Add(this.txtbaidS);
            this.BackSearch.Controls.Add(this.txtaccidS);
            this.BackSearch.Controls.Add(this.txtmemidS);
            this.BackSearch.Location = new System.Drawing.Point(8, 32);
            this.BackSearch.Name = "BackSearch";
            this.BackSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BackSearch.Size = new System.Drawing.Size(770, 178);
            this.BackSearch.TabIndex = 6;
            // 
            // txtenddate
            // 
            this.txtenddate.ButtonStyle.Buttons.Add(this.elEntryBoxButton1);
            this.txtenddate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtenddate.CaptionStyle.CaptionSize = 105;
            this.txtenddate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtenddate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtenddate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtenddate.CaptionStyle.TextStyle.Text = "تاریخ پایان";
            this.txtenddate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtenddate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtenddate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtenddate.Location = new System.Drawing.Point(166, 118);
            this.txtenddate.Name = "txtenddate";
            this.txtenddate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtenddate.Size = new System.Drawing.Size(201, 27);
            this.txtenddate.TabIndex = 8;
            this.txtenddate.Tag = "1";
            this.txtenddate.ValidationStyle.AcceptsTab = true;
            this.txtenddate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtenddate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtenddate.ValidationStyle.PasswordChar = '\0';
            this.txtenddate.Value = "";
            this.txtenddate.Leave += new System.EventHandler(this.txtenddate_Leave);
            this.txtenddate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // elEntryBoxButton1
            // 
            this.elEntryBoxButton1.BackgroundStyle.GradientAngle = 45F;
            this.elEntryBoxButton1.ButtonType = Klik.Windows.Forms.v1.EntryLib.EntryBoxButtonTypes.DropDown;
            this.elEntryBoxButton1.DropDownContextMenuStrip = this.contextDate;
            // 
            // txtstartdate
            // 
            this.txtstartdate.ButtonStyle.Buttons.Add(this.elEntryBoxButton2);
            this.txtstartdate.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstartdate.CaptionStyle.CaptionSize = 105;
            this.txtstartdate.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstartdate.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstartdate.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtstartdate.CaptionStyle.TextStyle.Text = "تاریخ شروع";
            this.txtstartdate.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstartdate.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstartdate.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstartdate.Location = new System.Drawing.Point(560, 118);
            this.txtstartdate.Name = "txtstartdate";
            this.txtstartdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtstartdate.Size = new System.Drawing.Size(204, 27);
            this.txtstartdate.TabIndex = 7;
            this.txtstartdate.Tag = "1";
            this.txtstartdate.ValidationStyle.AcceptsTab = true;
            this.txtstartdate.ValidationStyle.DateTimeValidationStyle.DateSeparator = "/";
            this.txtstartdate.ValidationStyle.MaskValidationStyle.AllowPrompt = true;
            this.txtstartdate.ValidationStyle.PasswordChar = '\0';
            this.txtstartdate.Value = "";
            this.txtstartdate.Leave += new System.EventHandler(this.txtstartdate_Leave);
            this.txtstartdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // txtstoremax
            // 
            this.txtstoremax.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstoremax.CaptionStyle.CaptionSize = 105;
            this.txtstoremax.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstoremax.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstoremax.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtstoremax.CaptionStyle.TextStyle.Text = "موجودی حداکثر";
            this.txtstoremax.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremax.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstoremax.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstoremax.Location = new System.Drawing.Point(123, 90);
            this.txtstoremax.Name = "txtstoremax";
            this.txtstoremax.Size = new System.Drawing.Size(244, 27);
            this.txtstoremax.TabIndex = 6;
            this.txtstoremax.Tag = "1";
            this.txtstoremax.ValidationStyle.AcceptsTab = true;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtstoremax.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtstoremax.ValidationStyle.PasswordChar = '\0';
            this.txtstoremax.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtstoremax.Value = 0;
            this.txtstoremax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstore_KeyPress);
            // 
            // txtstoremin
            // 
            this.txtstoremin.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtstoremin.CaptionStyle.CaptionSize = 105;
            this.txtstoremin.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtstoremin.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtstoremin.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtstoremin.CaptionStyle.TextStyle.Text = "موجودی حداقل";
            this.txtstoremin.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstoremin.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtstoremin.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtstoremin.Location = new System.Drawing.Point(520, 90);
            this.txtstoremin.Name = "txtstoremin";
            this.txtstoremin.Size = new System.Drawing.Size(244, 27);
            this.txtstoremin.TabIndex = 5;
            this.txtstoremin.Tag = "1";
            this.txtstoremin.ValidationStyle.AcceptsTab = true;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.EditType = Klik.Windows.Forms.v1.EntryLib.EditTypes.Formatted;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.FormatType = Klik.Windows.Forms.v1.EntryLib.NumericFormatTypes.Currency;
            this.txtstoremin.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtstoremin.ValidationStyle.PasswordChar = '\0';
            this.txtstoremin.ValidationStyle.ValidationType = Klik.Windows.Forms.v1.EntryLib.ValidationTypes.Numeric;
            this.txtstoremin.Value = 0;
            this.txtstoremin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstore_KeyPress);
            // 
            // btnInsBankid
            // 
            this.btnInsBankid.BackgroundImageStyle.Alpha = 100;
            this.btnInsBankid.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image12")));
            this.btnInsBankid.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnInsBankid.BorderStyle.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsBankid.BorderStyle.BorderShape.TopRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.btnInsBankid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInsBankid.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnInsBankid.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnInsBankid.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.Location = new System.Drawing.Point(401, 34);
            this.btnInsBankid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInsBankid.Name = "btnInsBankid";
            this.btnInsBankid.Size = new System.Drawing.Size(28, 27);
            this.btnInsBankid.TabIndex = 3;
            this.btnInsBankid.Tag = "0";
            this.btnInsBankid.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsBankid.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnInsBankid.Click += new System.EventHandler(this.btnIns2_Click);
            // 
            // txtbankS
            // 
            this.txtbankS.CaptionStyle.BorderStyle.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankS.CaptionStyle.BorderStyle.BorderShape.TopLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.txtbankS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbankS.CaptionStyle.CaptionSize = 100;
            this.txtbankS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbankS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbankS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbankS.CaptionStyle.TextStyle.Text = "مشخصات بانک";
            this.txtbankS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbankS.Location = new System.Drawing.Point(430, 34);
            this.txtbankS.Name = "txtbankS";
            this.txtbankS.Size = new System.Drawing.Size(334, 27);
            this.txtbankS.TabIndex = 2;
            this.txtbankS.Tag = "1";
            this.txtbankS.ValidationStyle.AcceptsTab = true;
            this.txtbankS.ValidationStyle.PasswordChar = '\0';
            this.txtbankS.ValidationStyle.ReadOnly = true;
            this.txtbankS.Value = "";
            this.txtbankS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            this.txtbankS.Enter += new System.EventHandler(this.txtaccuser_Enter);
            // 
            // txtbaidS
            // 
            this.txtbaidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtbaidS.CaptionStyle.CaptionSize = 105;
            this.txtbaidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtbaidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtbaidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtbaidS.CaptionStyle.TextStyle.Text = "نوع حساب";
            this.txtbaidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbaidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtbaidS.Location = new System.Drawing.Point(549, 62);
            this.txtbaidS.Name = "txtbaidS";
            this.txtbaidS.Size = new System.Drawing.Size(215, 27);
            this.txtbaidS.TabIndex = 4;
            this.txtbaidS.Tag = "1";
            this.txtbaidS.ValidationStyle.AcceptsTab = true;
            this.txtbaidS.ValidationStyle.PasswordChar = '\0';
            this.txtbaidS.Value = "";
            this.txtbaidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // txtaccidS
            // 
            this.txtaccidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtaccidS.CaptionStyle.CaptionSize = 105;
            this.txtaccidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtaccidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtaccidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtaccidS.CaptionStyle.TextStyle.Text = "شماره حساب";
            this.txtaccidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtaccidS.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtaccidS.Location = new System.Drawing.Point(123, 6);
            this.txtaccidS.Name = "txtaccidS";
            this.txtaccidS.Size = new System.Drawing.Size(244, 27);
            this.txtaccidS.TabIndex = 1;
            this.txtaccidS.Tag = "1";
            this.txtaccidS.ValidationStyle.AcceptsTab = true;
            this.txtaccidS.ValidationStyle.NumericValidationStyle.NumericType = Klik.Windows.Forms.v1.EntryLib.NumericTypes.Double;
            this.txtaccidS.ValidationStyle.PasswordChar = '\0';
            this.txtaccidS.Value = "";
            this.txtaccidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // txtmemidS
            // 
            this.txtmemidS.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtmemidS.CaptionStyle.CaptionSize = 105;
            this.txtmemidS.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtmemidS.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtmemidS.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtmemidS.CaptionStyle.TextStyle.Text = "نام صاحب حساب";
            this.txtmemidS.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmemidS.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtmemidS.Location = new System.Drawing.Point(480, 6);
            this.txtmemidS.Name = "txtmemidS";
            this.txtmemidS.Size = new System.Drawing.Size(284, 27);
            this.txtmemidS.TabIndex = 0;
            this.txtmemidS.Tag = "1";
            this.txtmemidS.ValidationStyle.AcceptsTab = true;
            this.txtmemidS.ValidationStyle.PasswordChar = '\0';
            this.txtmemidS.Value = "";
            this.txtmemidS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbomemid_KeyPress);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImageStyle.Alpha = 100;
            this.btnReset.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image13")));
            this.btnReset.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnReset.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnReset.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.Location = new System.Drawing.Point(82, 216);
            this.btnReset.Name = "btnReset";
            this.btnReset.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnReset.Size = new System.Drawing.Size(69, 27);
            this.btnReset.TabIndex = 0;
            this.btnReset.Tag = "Close";
            this.btnReset.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.TextStyle.Text = "ریست";
            this.btnReset.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.BackgroundImageStyle.Alpha = 100;
            this.btnFilter.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image14")));
            this.btnFilter.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilter.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnFilter.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnFilter.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFilter.Location = new System.Drawing.Point(7, 216);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnFilter.Size = new System.Drawing.Size(69, 27);
            this.btnFilter.TabIndex = 1;
            this.btnFilter.Tag = "Close";
            this.btnFilter.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.TextStyle.Text = "فیلتر";
            this.btnFilter.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // lblsum
            // 
            this.lblsum.AutoSize = true;
            this.lblsum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblsum.ForeColor = System.Drawing.Color.Blue;
            this.lblsum.Location = new System.Drawing.Point(11, 226);
            this.lblsum.Name = "lblsum";
            this.lblsum.Size = new System.Drawing.Size(0, 15);
            this.lblsum.TabIndex = 8;
            this.lblsum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(142, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "جمع کل:";
            // 
            // FrmAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 569);
            this.ControlBox = false;
            this.Controls.Add(this.expandPanel);
            this.Controls.Add(this.elContainer1);
            this.Controls.Add(this.elContainer2);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmAccount";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "حسابهای بانکی";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmAccount_Load);
            ((System.ComponentModel.ISupportInitialize)(this.elContainer1)).EndInit();
            this.elContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.elRichPanel2)).EndInit();
            this.elRichPanel2.ResumeLayout(false);
            this.elRichPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.accDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.familyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseaccBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOptbank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAccCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backContainer)).EndInit();
            this.backContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIns2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIns1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtavailrate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblStore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpAccInternet)).EndInit();
            this.grpAccInternet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtaccuser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecureid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcustid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccdate)).EndInit();
            this.contextDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtstore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCheque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elContainer2)).EndInit();
            this.elContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnAbort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.expandPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BackSearch)).EndInit();
            this.BackSearch.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtenddate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstartdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtstoremin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnInsBankid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbankS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbaidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtaccidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmemidS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnReset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnFilter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer1;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnCheque;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtcustid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtavailrate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstore;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccdate;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer backContainer;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccnote;
        private System.Windows.Forms.ContextMenuStrip contextDate;
        private FarsiLibrary.Win.Controls.FaMonthViewStrip faDatePicker;
        private Klik.Windows.Forms.v1.EntryLib.ELGroupBox grpAccInternet;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccuser;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccpass;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsecureid;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer elContainer2;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnAbort;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnClose;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnEdit;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton5;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnDelete;
        private Klik.Windows.Forms.v1.EntryLib.ELButton elButton3;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnSave;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnNew;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnAccCard;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnOptbank;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton2;
        private Klik.Windows.Forms.v1.EntryLib.ELDataGridView accDataGrid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbaid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbankid;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lblStore;
        private AccountDataSet accountDataSet;
        private System.Windows.Forms.BindingSource familyBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.familyTableAdapter familyTableAdapter;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns3;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnIns1;
        private System.Windows.Forms.BindingSource baseaccBindingSource;
        private FamilyAccount.AccountDataSetTableAdapters.baseaccTableAdapter baseaccTableAdapter;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel elRichPanel2;
        private DevComponents.DotNetBar.ExpandablePanel expandPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELContainer BackSearch;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnReset;
        public Klik.Windows.Forms.v1.EntryLib.ELButton btnFilter;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstoremax;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstoremin;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnInsBankid;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbankS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtbaidS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtaccidS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtmemidS;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtenddate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtstartdate;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBoxButton elEntryBoxButton1;
        private System.Windows.Forms.DataGridViewButtonColumn Select;
        private System.Windows.Forms.DataGridViewComboBoxColumn memid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accid;
        private System.Windows.Forms.DataGridViewTextBoxColumn custid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bankid;
        private System.Windows.Forms.DataGridViewTextBoxColumn store;
        private System.Windows.Forms.DataGridViewComboBoxColumn baid;
        private System.Windows.Forms.DataGridViewTextBoxColumn accnote;
        private System.Windows.Forms.DataGridViewTextBoxColumn availrate;
        private System.Windows.Forms.DataGridViewTextBoxColumn accuser;
        private System.Windows.Forms.DataGridViewTextBoxColumn accpass;
        private System.Windows.Forms.DataGridViewTextBoxColumn secureid;
        private System.Windows.Forms.Label lblsum;
        private System.Windows.Forms.Label label1;
    }
}