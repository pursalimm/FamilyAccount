﻿namespace FamilyAccount
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            this.LoginPanel = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.linkPassword = new System.Windows.Forms.LinkLabel();
            this.elDivider1 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.elDivider2 = new Klik.Windows.Forms.v1.EntryLib.ELDivider();
            this.btnExit = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.lblMesLogin = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.btnLogin = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtUsername = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtPassword = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.getPassword = new Klik.Windows.Forms.v1.EntryLib.ELRichPanel();
            this.btnCancel = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.btnRestorePass = new Klik.Windows.Forms.v1.EntryLib.ELButton();
            this.txtquesanswer = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.txtsecureques = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.kFormManager1 = new Klik.Windows.Forms.v1.Common.KFormManager(this.components);
            this.ModalForgot = new Klik.Windows.Forms.v1.EntryLib.ELModalBox(this.components);
            this.SetBackup = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.LoginPanel)).BeginInit();
            this.LoginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMesLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUsername)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.getPassword)).BeginInit();
            this.getPassword.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRestorePass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquesanswer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecureques)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // LoginPanel
            // 
            this.LoginPanel.ContainerStyle.BackgroundImageStyle.Alpha = 100;
            this.LoginPanel.ContainerStyle.BackgroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.LoginPanel.ContainerStyle.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LoginPanel.ContainerStyle.BackgroundImageStyle.ImageEffect = Klik.Windows.Forms.v1.Common.ImageEffect.Mirror;
            this.LoginPanel.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.LoginPanel.ContainerStyle.BorderStyle.SmoothingMode = Klik.Windows.Forms.v1.Common.SmoothingModes.AntiAlias;
            this.LoginPanel.Controls.Add(this.linkPassword);
            this.LoginPanel.Controls.Add(this.elDivider1);
            this.LoginPanel.Controls.Add(this.elDivider2);
            this.LoginPanel.Controls.Add(this.btnExit);
            this.LoginPanel.Controls.Add(this.lblMesLogin);
            this.LoginPanel.Controls.Add(this.btnLogin);
            this.LoginPanel.Controls.Add(this.txtUsername);
            this.LoginPanel.Controls.Add(this.txtPassword);
            this.LoginPanel.Expanded = true;
            this.LoginPanel.FooterStyle.BackgroundStyle.GradientAngle = 0F;
            this.LoginPanel.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.LoginPanel.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.LoginPanel.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.LoginPanel.FooterStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LoginPanel.FooterStyle.Height = 20;
            this.LoginPanel.FooterStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.LoginPanel.FooterStyle.TextStyle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.LoginPanel.FooterStyle.TextStyle.Text = " ...اطلاعات کاربری خود را وارد نمائید";
            this.LoginPanel.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.LoginPanel.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.LoginPanel.HeaderStyle.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LoginPanel.HeaderStyle.Height = 24;
            this.LoginPanel.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.LoginPanel.HeaderStyle.TextStyle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.LoginPanel.HeaderStyle.TextStyle.Text = "ورود به سیستم";
            this.LoginPanel.HeaderStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LoginPanel.Location = new System.Drawing.Point(9, 9);
            this.LoginPanel.Name = "LoginPanel";
            this.LoginPanel.Padding = new System.Windows.Forms.Padding(1, 24, 1, 20);
            this.LoginPanel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.LoginPanel.Size = new System.Drawing.Size(434, 220);
            this.LoginPanel.TabIndex = 0;
            // 
            // linkPassword
            // 
            this.linkPassword.AutoSize = true;
            this.linkPassword.Location = new System.Drawing.Point(4, 203);
            this.linkPassword.Name = "linkPassword";
            this.linkPassword.Size = new System.Drawing.Size(164, 14);
            this.linkPassword.TabIndex = 5;
            this.linkPassword.TabStop = true;
            this.linkPassword.Text = "رمز عبور خود را فراموش کرده ام";
            this.linkPassword.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkPassword_LinkClicked);
            // 
            // elDivider1
            // 
            this.elDivider1.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.Center;
            this.elDivider1.Location = new System.Drawing.Point(128, 97);
            this.elDivider1.Name = "elDivider1";
            this.elDivider1.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicSilver;
            this.elDivider1.Size = new System.Drawing.Size(294, 3);
            this.elDivider1.TabIndex = 7;
            // 
            // elDivider2
            // 
            this.elDivider2.FadeStyle = Klik.Windows.Forms.v1.EntryLib.DividerFadeStyles.Center;
            this.elDivider2.Location = new System.Drawing.Point(128, 70);
            this.elDivider2.Name = "elDivider2";
            this.elDivider2.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ClassicSilver;
            this.elDivider2.Size = new System.Drawing.Size(294, 3);
            this.elDivider2.TabIndex = 6;
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnExit.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnExit.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExit.Location = new System.Drawing.Point(186, 150);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(81, 27);
            this.btnExit.TabIndex = 3;
            this.btnExit.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.TextStyle.Text = "خروج";
            this.btnExit.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            this.btnExit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // lblMesLogin
            // 
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lblMesLogin.FlashStyle = paintStyle1;
            this.lblMesLogin.Location = new System.Drawing.Point(128, 74);
            this.lblMesLogin.Name = "lblMesLogin";
            this.lblMesLogin.Size = new System.Drawing.Size(294, 22);
            this.lblMesLogin.TabIndex = 1;
            this.lblMesLogin.TabStop = false;
            this.lblMesLogin.TextStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesLogin.TextStyle.ForeColor = System.Drawing.Color.Maroon;
            this.lblMesLogin.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLogin
            // 
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnLogin.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnLogin.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.Location = new System.Drawing.Point(273, 150);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(81, 27);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.TextStyle.Text = "ورود";
            this.btnLogin.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            this.btnLogin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // txtUsername
            // 
            this.txtUsername.ButtonStyle.ButtonSize = new System.Drawing.Size(10, 10);
            this.txtUsername.CaptionStyle.CaptionSize = 60;
            this.txtUsername.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtUsername.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtUsername.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtUsername.CaptionStyle.TextStyle.Text = "نام کاربری";
            this.txtUsername.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtUsername.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUsername.Location = new System.Drawing.Point(128, 38);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtUsername.Size = new System.Drawing.Size(294, 26);
            this.txtUsername.TabIndex = 0;
            this.txtUsername.ValidationStyle.PasswordChar = '\0';
            this.txtUsername.Value = "";
            this.txtUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // txtPassword
            // 
            this.txtPassword.ButtonStyle.ButtonSize = new System.Drawing.Size(10, 10);
            this.txtPassword.CaptionStyle.CaptionSize = 60;
            this.txtPassword.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtPassword.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtPassword.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPassword.CaptionStyle.TextStyle.Text = "کلمه عبور";
            this.txtPassword.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPassword.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPassword.Location = new System.Drawing.Point(128, 105);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPassword.Size = new System.Drawing.Size(294, 26);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.ValidationStyle.PasswordChar = '*';
            this.txtPassword.ValidationStyle.UseSystemPasswordChar = true;
            this.txtPassword.Value = "";
            this.txtPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // getPassword
            // 
            this.getPassword.ContainerStyle.BackgroundStyle.GradientAngle = 45F;
            this.getPassword.Controls.Add(this.btnCancel);
            this.getPassword.Controls.Add(this.btnRestorePass);
            this.getPassword.Controls.Add(this.txtquesanswer);
            this.getPassword.Controls.Add(this.txtsecureques);
            this.getPassword.Expanded = true;
            this.getPassword.FooterStyle.BackgroundStyle.GradientAngle = 45F;
            this.getPassword.FooterStyle.FlashStyle.GradientAngle = 0F;
            this.getPassword.FooterStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.getPassword.FooterStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.getPassword.FooterStyle.Height = 18;
            this.getPassword.FooterStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getPassword.FooterStyle.TextStyle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.getPassword.FooterStyle.TextStyle.Text = "جواب امنیتی سئوال فوق را جهت دریافت رمز عبور وارد نمائید";
            this.getPassword.FooterStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.getPassword.HeaderStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.getPassword.HeaderStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.getPassword.HeaderStyle.Height = 24;
            this.getPassword.HeaderStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getPassword.HeaderStyle.TextStyle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.getPassword.HeaderStyle.TextStyle.Text = "بازیابی رمز عبور";
            this.getPassword.HeaderStyle.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.getPassword.Location = new System.Drawing.Point(69, 263);
            this.getPassword.Name = "getPassword";
            this.getPassword.Padding = new System.Windows.Forms.Padding(1, 24, 1, 18);
            this.getPassword.Size = new System.Drawing.Size(317, 135);
            this.getPassword.TabIndex = 4;
            this.getPassword.Tag = "0";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImageStyle.Alpha = 100;
            this.btnCancel.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnCancel.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnCancel.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCancel.Location = new System.Drawing.Point(97, 89);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnCancel.Size = new System.Drawing.Size(57, 27);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Tag = "0";
            this.btnCancel.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.TextStyle.Text = "انصراف";
            this.btnCancel.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRestorePass
            // 
            this.btnRestorePass.BackgroundImageStyle.Alpha = 100;
            this.btnRestorePass.BackgroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRestorePass.BackgroundImageStyle.ImageSize = new System.Drawing.Size(25, 25);
            this.btnRestorePass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestorePass.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.btnRestorePass.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.btnRestorePass.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRestorePass.Location = new System.Drawing.Point(160, 89);
            this.btnRestorePass.Name = "btnRestorePass";
            this.btnRestorePass.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.btnRestorePass.Size = new System.Drawing.Size(57, 27);
            this.btnRestorePass.TabIndex = 5;
            this.btnRestorePass.Tag = "0";
            this.btnRestorePass.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRestorePass.TextStyle.Text = "تائید";
            this.btnRestorePass.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRestorePass.Click += new System.EventHandler(this.btnRestorePass_Click);
            // 
            // txtquesanswer
            // 
            this.txtquesanswer.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtquesanswer.CaptionStyle.CaptionSize = 85;
            this.txtquesanswer.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtquesanswer.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtquesanswer.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtquesanswer.CaptionStyle.TextStyle.Text = "جواب سئوال";
            this.txtquesanswer.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquesanswer.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtquesanswer.Location = new System.Drawing.Point(97, 56);
            this.txtquesanswer.Name = "txtquesanswer";
            this.txtquesanswer.Size = new System.Drawing.Size(211, 27);
            this.txtquesanswer.TabIndex = 4;
            this.txtquesanswer.Tag = "0";
            this.txtquesanswer.ValidationStyle.AcceptsTab = true;
            this.txtquesanswer.ValidationStyle.PasswordChar = '\0';
            this.txtquesanswer.Value = "";
            this.txtquesanswer.Leave += new System.EventHandler(this.txtquesanswer_Leave);
            this.txtquesanswer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            this.txtquesanswer.Enter += new System.EventHandler(this.txtquesanswer_Enter);
            // 
            // txtsecureques
            // 
            this.txtsecureques.CaptionStyle.BorderStyle.EdgeRadius = 20;
            this.txtsecureques.CaptionStyle.CaptionSize = 85;
            this.txtsecureques.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txtsecureques.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txtsecureques.CaptionStyle.TextStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtsecureques.CaptionStyle.TextStyle.Text = "سئوال امنیتی";
            this.txtsecureques.EditBoxStyle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsecureques.EditBoxStyle.ForeColor = System.Drawing.Color.Blue;
            this.txtsecureques.Enabled = false;
            this.txtsecureques.Location = new System.Drawing.Point(4, 27);
            this.txtsecureques.Name = "txtsecureques";
            this.txtsecureques.Size = new System.Drawing.Size(304, 27);
            this.txtsecureques.TabIndex = 3;
            this.txtsecureques.Tag = "0";
            this.txtsecureques.ValidationStyle.AcceptsTab = true;
            this.txtsecureques.ValidationStyle.PasswordChar = '\0';
            this.txtsecureques.Value = "";
            this.txtsecureques.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsername_KeyPress);
            // 
            // kFormManager1
            // 
            this.kFormManager1.BorderShape.BottomLeft = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.BorderShape.BottomRight = Klik.Windows.Forms.v1.Common.BorderShapes.Rectangle;
            this.kFormManager1.FormOffice2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernSilver;
            this.kFormManager1.MainContainer = this;
            // 
            // ModalForgot
            // 
            this.ModalForgot.CloseOnClick = false;
            // 
            // SetBackup
            // 
            this.SetBackup.Filter = "Backup files (*.bak) |*.bak|All files(*.*) |*.*";
            this.SetBackup.Title = "Restore Database";
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 240);
            this.ControlBox = false;
            this.Controls.Add(this.getPassword);
            this.Controls.Add(this.LoginPanel);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLogin";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ورود به سیستم";
            ((System.ComponentModel.ISupportInitialize)(this.LoginPanel)).EndInit();
            this.LoginPanel.ResumeLayout(false);
            this.LoginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elDivider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMesLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLogin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUsername)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.getPassword)).EndInit();
            this.getPassword.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRestorePass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtquesanswer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsecureques)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kFormManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public Klik.Windows.Forms.v1.EntryLib.ELRichPanel LoginPanel;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider1;
        private Klik.Windows.Forms.v1.EntryLib.ELDivider elDivider2;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnExit;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lblMesLogin;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnLogin;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtUsername;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtPassword;
        private System.Windows.Forms.LinkLabel linkPassword;
        private Klik.Windows.Forms.v1.EntryLib.ELRichPanel getPassword;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnCancel;
        private Klik.Windows.Forms.v1.EntryLib.ELButton btnRestorePass;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtquesanswer;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txtsecureques;
        private Klik.Windows.Forms.v1.Common.KFormManager kFormManager1;
        private Klik.Windows.Forms.v1.EntryLib.ELModalBox ModalForgot;
        private System.Windows.Forms.OpenFileDialog SetBackup;
    }
}