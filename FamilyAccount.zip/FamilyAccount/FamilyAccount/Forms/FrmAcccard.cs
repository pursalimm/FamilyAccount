﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FarsiLibrary.Utils;
using System.Data.SqlClient;
using System.Threading;

namespace FamilyAccount
{
    public partial class FrmAcccard : Form
    {
        string idSel = "";
        string selectedkeymem = "";
        string accountID = string.Empty;
        ClassDB ado = new ClassDB();
        SqlCommand cmd = new SqlCommand();
        public DataGridViewRow dgvr;
        public FrmAcccard(string accID)
        {
            InitializeComponent();
            accountID = accID;
        }

        private void txtcardid_Enter(object sender, EventArgs e)
        {
            ado.SetEnglishLanguage();
        }

        private void txtcardid_Leave(object sender, EventArgs e)
        {
            ado.SetFarsiLanguage();
        }

        private void txtfirstpass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                ProcessTabKey(true);
        }

        private void FrmAcccard_Load(object sender, EventArgs e)
        {
            familyTableAdapter.Fill(accountDataSet.family);
            txtaccid.Text = accountID;
            GridRefresh();
            ado.SetFarsiLanguage();
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = false;
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = true;
            backContainer.Enabled = true;
            ado.ClearControl(backContainer);
            txtaccid.Text = accountID;
            txtaccid.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "insert into acc_card values(@accid,@memid,@cardid,@settlenum,@cvv2,@firstpass,@secondpass)";
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@cardid", SqlDbType.NVarChar).Value = txtcardid.Text;
            cmd.Parameters.Add("@settlenum", SqlDbType.NVarChar).Value = txtsettlenum.Text;
            cmd.Parameters.Add("@cvv2", SqlDbType.NVarChar).Value = ado.EncryptText(txtcvv2.Text);
            cmd.Parameters.Add("@firstpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtfirstpass.Text);
            cmd.Parameters.Add("@secondpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtsecondpass.Text);
            if(ado.insert(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (ado.ValidateControl(backContainer)) return;
            cmd.Parameters.Clear();
            cmd.CommandText = "update acc_card set accid=@accid,memid=@memid,cardid=@cardid,settlenum=@settlenum,cvv2=@cvv2,firstpass=@firstpass,secondpass=@secondpass where cid=@cid";
            cmd.Parameters.Add("@cid", SqlDbType.Int).Value = idSel;
            cmd.Parameters.Add("@accid", SqlDbType.NVarChar).Value = txtaccid.Text;
            cmd.Parameters.Add("@memid", SqlDbType.Int).Value = selectedkeymem;
            cmd.Parameters.Add("@cardid", SqlDbType.NVarChar).Value = txtcardid.Text;
            cmd.Parameters.Add("@settlenum", SqlDbType.NVarChar).Value = txtsettlenum.Text;
            cmd.Parameters.Add("@cvv2", SqlDbType.NVarChar).Value = ado.EncryptText(txtcvv2.Text);
            cmd.Parameters.Add("@firstpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtfirstpass.Text);
            cmd.Parameters.Add("@secondpass", SqlDbType.NVarChar).Value = ado.EncryptText(txtsecondpass.Text);
            if(ado.update(cmd, CommandType.Text, cmd.CommandText))
                ado.ClearControl(backContainer);
            GridRefresh();
            btnAbort_Click(sender, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd.Parameters.Clear();
            cmd.CommandText = "delete from acc_card where cid=@cid";
            cmd.Parameters.Add("@cid", SqlDbType.Int).Value = idSel;
            if (MessageBox.Show("آیا جهت حذف اطلاعات مطمئن هستید", "حذف اطلاعات", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading) == DialogResult.OK)
            {
                if (ado.delete(cmd, CommandType.Text, cmd.CommandText))
                    ado.ClearControl(backContainer);
                GridRefresh();
                btnAbort_Click(sender, e);
            }
        }

        private void GridRefresh()
        {
            DataSet ds = ado.select("select * from acc_card where accid='" + accountID + "'");
            acccardDataGrid.DataSource = ds.Tables[0];
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            btnNew.Enabled = true;
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            btnAbort.Enabled = false;
            backContainer.Enabled = false;
            ado.ClearControl(backContainer);
            txtaccid.Text = accountID;
        }

        private void acccardDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (acccardDataGrid.RowCount > 0)
            {
                if (acccardDataGrid.CurrentCell.Value.ToString().Trim() == "انتخاب")
                {
                    btnNew.Enabled = false;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnAbort.Enabled = true;
                    backContainer.Enabled = true;
                }
                else
                {
                    btnNew.Enabled = true;
                    btnSave.Enabled = false;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnAbort.Enabled = false;
                    backContainer.Enabled = false;
                }
            }
        }

        private void SelectedData()
        {
            idSel = acccardDataGrid["cid", acccardDataGrid.CurrentRow.Index].Value.ToString();
            txtaccid.Text = acccardDataGrid["accid", acccardDataGrid.CurrentRow.Index].Value.ToString();
            selectedkeymem = acccardDataGrid["memid", acccardDataGrid.CurrentRow.Index].Value.ToString();
            txtmemid.Text = acccardDataGrid["memid", acccardDataGrid.CurrentRow.Index].FormattedValue.ToString();
            txtcardid.Text = acccardDataGrid["cardid", acccardDataGrid.CurrentRow.Index].Value.ToString();
            txtsettlenum.Text = acccardDataGrid["settlenum", acccardDataGrid.CurrentRow.Index].Value.ToString();
            txtcvv2.Text = ado.DecryptText(acccardDataGrid["cvv2", acccardDataGrid.CurrentRow.Index].Value.ToString());
            txtfirstpass.Text = ado.DecryptText(acccardDataGrid["firstpass", acccardDataGrid.CurrentRow.Index].Value.ToString());
            txtsecondpass.Text = ado.DecryptText(acccardDataGrid["secondpass", acccardDataGrid.CurrentRow.Index].Value.ToString());
        }

        private void acccardDataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && acccardDataGrid.RowCount > 0)
            {
                SelectedData();
                if (acccardDataGrid.CurrentRow.Index == 0)
                    acccardDataGrid[0, 0].Selected = true;
                else
                    acccardDataGrid[0, acccardDataGrid.CurrentRow.Index].Selected = true;
                e.Handled = true;
            }
        }

        private void acccardDataGrid_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && acccardDataGrid.RowCount > 0)
                SelectedData();
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            DataSet ds = ado.select("select memid,name from family");
            if (ds.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("هیچ گونه اطلاعاتی تا کنون جهت انتخاب ثبت نشده است", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }
            FrmSelectRow fsr = new FrmSelectRow("select memid,name from family");
            fsr.ShowDialog();
            dgvr = fsr.dgvRow;
            if (dgvr != null)
            {
                selectedkeymem = dgvr.Cells[0].Value.ToString();
                txtmemid.Text = dgvr.Cells[1].Value.ToString();
            }
            ProcessTabKey(true);
        }

        private void txtmemid_Enter(object sender, EventArgs e)
        {
            ProcessTabKey(true);
        }
    }
}
